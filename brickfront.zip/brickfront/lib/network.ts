import PeerModule, { type DataConnection } from 'peerjs';
const Peer =
  (PeerModule as unknown as { Peer?: typeof PeerModule }).Peer ?? PeerModule;
import { sanitizeInput, type Input, type State } from './simulation';
import { validRules, allowedWeapon, WEAPONS } from './weapons';
import {
  createPrivateRoom,
  resolveInvite,
  validateConnection,
  ROOM_CAPACITY,
  ROOM_PROTOCOL,
  type RoomConnection,
} from './room-discovery';
export { validCode } from './room-discovery';
export type RoomInfo = {
  code: string;
  role: 'host' | 'guest' | '';
  status: string;
  count: number;
  error: string;
};

export class Room {
  connection: RoomConnection | null = null;
  peer: PeerModule | null = null;
  connections = new Map<string, DataConnection>();
  info: RoomInfo = { code: '', role: '', status: '', count: 1, error: '' };
  hostConnection: DataConnection | null = null;
  timer: ReturnType<typeof setTimeout> | null = null;
  inputTimes = new Map<string, number>();
  constructor(
    public onInfo: (i: RoomInfo) => void,
    public onJoin: (id: string) => string,
    public onLeave: (id: string) => void,
    public onInput: (id: string, input: Input) => void,
    public onState: (state: State, id: string) => void,
  ) {}
  notify() {
    this.onInfo({ ...this.info });
  }
  async host() {
    this.close();
    const connection = createPrivateRoom();
    this.connection = connection;
    const { code } = connection;
    this.info = {
      code,
      role: 'host',
      status: 'Connecting room…',
      count: 1,
      error: '',
    };
    this.notify();
    const peer = new Peer(connection.peerId, { debug: 0 });
    this.peer = peer;
    peer.on('open', () => {
      this.info.status = 'Room open';
      this.notify();
    });
    peer.on('error', (e) =>
      this.fail(
        e.type === 'unavailable-id'
          ? 'That room name is busy. Create another room.'
          : 'Room service unavailable. Check your connection and try again.',
      ),
    );
    peer.on('disconnected', () => {
      this.info.status =
        'Signaling disconnected. Existing players can continue.';
      this.notify();
    });
    peer.on('connection', (conn) => {
      if (this.connections.size >= ROOM_CAPACITY - 1) {
        conn.on('open', () => {
          conn.send({ type: 'error', message: 'Room is full.' });
          setTimeout(() => conn.close(), 500);
        });
        return;
      }
      const id = conn.peer;
      this.connections.set(id, conn);
      const actorId = this.onJoin(id);
      this.inputTimes.set(id, performance.now());
      conn.on('open', () => {
        conn.send({ type: 'welcome', id: actorId, protocol: ROOM_PROTOCOL });
        this.info.count = this.connections.size + 1;
        this.notify();
      });
      conn.on('data', (data) => {
        if (!data || typeof data !== 'object') return;
        const m = data as Record<string, unknown>;
        if (m.type !== 'input') return;
        const input = sanitizeInput(m.input);
        if (input) {
          this.inputTimes.set(id, performance.now());
          this.onInput(id, input);
        }
      });
      conn.on('close', () => this.remove(id));
      conn.on('error', () => this.remove(id));
    });
    this.timer = setTimeout(() => {
      if (!peer.open)
        this.fail('Room connection timed out. Try again or play solo.');
    }, 15000);
  }
  join(raw: string) {
    try {
      return this.joinConnection(resolveInvite(raw));
    } catch {
      this.fail('Enter the 6-character room code.');
      return false;
    }
  }
  /** A public directory can pass a compatible listing here without changing gameplay. */
  joinConnection(connection: RoomConnection) {
    if (!validateConnection(connection)) {
      this.fail('This room uses an incompatible connection.');
      return false;
    }
    this.close();
    this.connection = { ...connection };
    const { code } = connection;
    this.info = {
      code,
      role: 'guest',
      status: 'Joining room…',
      count: 1,
      error: '',
    };
    this.notify();
    const peer = new Peer({ debug: 0 });
    this.peer = peer;
    let actorId = '';
    peer.on('open', () => {
      const conn = peer.connect(connection.peerId, {
        reliable: false,
        serialization: 'json',
      });
      this.hostConnection = conn;
      conn.on('data', (raw) => {
        if (!raw || typeof raw !== 'object') return;
        const m = raw as Record<string, unknown>;
        if (m.type === 'welcome' && m.protocol !== ROOM_PROTOCOL) {
          this.fail('Room version changed. Refresh the game and rejoin.');
          conn.close();
          return;
        }
        if (m.type === 'welcome' && typeof m.id === 'string') {
          actorId = m.id;
          this.info.status = 'Connected';
          this.notify();
          if (this.timer) clearTimeout(this.timer);
        }
        if (m.type === 'state' && actorId && isState(m.state)) {
          this.info.count = m.state.actors.filter((a) => !a.bot).length;
          this.onState(m.state, actorId);
        }
        if (m.type === 'error') this.fail(String(m.message).slice(0, 120));
      });
      conn.on('close', () =>
        this.fail(
          'The host left the room. Return to the lobby to start another match.',
        ),
      );
      conn.on('error', () =>
        this.fail('Connection lost. Return to the lobby and rejoin.'),
      );
    });
    peer.on('error', (e) =>
      this.fail(
        e.type === 'peer-unavailable'
          ? 'Room not found. Check the code and make sure the host is online.'
          : 'Could not connect. This network may block peer connections. Try another network.',
      ),
    );
    this.timer = setTimeout(() => {
      if (!actorId)
        this.fail(
          'Could not reach the host. Check the room code, or try another network.',
        );
    }, 18000);
    return true;
  }
  send(input: Input) {
    if (this.hostConnection?.open)
      this.hostConnection.send({ type: 'input', input });
  }
  broadcast(state: State) {
    for (const [id, conn] of this.connections) {
      if (conn.open) conn.send({ type: 'state', state });
      if (performance.now() - (this.inputTimes.get(id) || 0) > 600) {
        const stop = sanitizeInput({
          forward: 0,
          strafe: 0,
          yaw: state.actors.find((a) => a.id === id)?.yaw || 0,
          pitch: 0,
        });
        if (stop) this.onInput(id, stop);
      }
    }
  }
  remove(id: string) {
    if (!this.connections.has(id)) return;
    this.connections.delete(id);
    this.inputTimes.delete(id);
    this.onLeave(id);
    this.info.count = this.connections.size + 1;
    this.notify();
  }
  fail(message: string) {
    this.info.error = message;
    this.info.status = 'Connection unavailable';
    this.notify();
  }
  close() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    for (const conn of this.connections.values()) conn.close();
    this.connections.clear();
    this.peer?.destroy();
    this.peer = null;
    this.hostConnection = null;
    this.connection = null;
    this.info = { code: '', role: '', status: '', count: 1, error: '' };
  }
}
export function isState(value: unknown): value is State {
  if (!value || typeof value !== 'object') return false;
  const s = value as State;
  return (
    s.protocol === ROOM_PROTOCOL &&
    validRules(s.rules) &&
    Array.isArray(s.pickups) &&
    s.pickups.length <= 64 &&
    s.pickups.every(
      (p) =>
        Number.isInteger(p.id) &&
        Number.isInteger(p.weapon) &&
        !!WEAPONS[p.weapon] &&
        allowedWeapon(p.weapon, s.rules) &&
        Number.isFinite(p.pos?.x) &&
        Number.isFinite(p.pos?.y) &&
        Number.isFinite(p.pos?.z) &&
        Number.isFinite(p.cooldown),
    ) &&
    (s.map === 'baghdad' || s.map === 'foundry') &&
    Number.isFinite(s.time) &&
    Array.isArray(s.actors) &&
    s.actors.length <= 16 &&
    s.actors.every(
      (a) =>
        Array.isArray(a.inventory) &&
        a.inventory.length === 3 &&
        a.inventory.every(
          (w, slot) =>
            w === null ||
            (Number.isInteger(w) &&
              !!WEAPONS[w] &&
              WEAPONS[w].slot === slot &&
              allowedWeapon(w, s.rules)),
        ) &&
        a.inventory.includes(a.weapon) &&
        typeof a.id === 'string' &&
        a.id.length < 100 &&
        Number.isFinite(a.pos?.x) &&
        Number.isFinite(a.pos?.y) &&
        Number.isFinite(a.pos?.z) &&
        Number.isFinite(a.hp) &&
        Number.isFinite(a.yaw) &&
        Array.isArray(a.limbs) &&
        Array.isArray(a.ammo),
    ) &&
    Array.isArray(s.vehicles) &&
    s.vehicles.length <= 4 &&
    Array.isArray(s.projectiles) &&
    s.projectiles.length <= 100 &&
    Array.isArray(s.events) &&
    s.events.length <= 100 &&
    Array.isArray(s.patches) &&
    Array.isArray(s.score)
  );
}
