import {
  createWorld,
  v,
  distance,
  clamp,
  move,
  blocked,
  rayBox,
  wallDistance,
  type Vec,
  type MapId,
  type World,
} from './world';
import {
  WEAPONS,
  SELECTABLE,
  allowedWeapon,
  allowedGrenades,
  startingInventory,
  weaponMuzzle,
  MUZZLE_FLASH_DURATION,
  DEFAULT_RULES,
  validRules,
  type MatchRules,
} from './weapons';
import { createBotMemory, perceive, type BotMemory } from './perception';
import { ROOM_PROTOCOL } from './room-discovery';
export { WEAPONS, SELECTABLE } from './weapons';
export type Input = {
  forward: number;
  strafe: number;
  yaw: number;
  pitch: number;
  shoot: boolean;
  ads: boolean;
  sprint: boolean;
  jump: boolean;
  reload: boolean;
  use: boolean;
  turret: boolean;
  patch: boolean;
  grenade: boolean;
  pickup: boolean;
  weapon: number;
};
export const emptyInput = (): Input => ({
  forward: 0,
  strafe: 0,
  yaw: 0,
  pitch: 0,
  shoot: false,
  ads: false,
  sprint: false,
  jump: false,
  reload: false,
  use: false,
  turret: false,
  patch: false,
  grenade: false,
  pickup: false,
  weapon: -1,
});
export type Actor = {
  id: string;
  name: string;
  team: number;
  bot: boolean;
  pos: Vec;
  yaw: number;
  pitch: number;
  hp: number;
  bleed: number;
  limbs: boolean[];
  weapon: number;
  preferredWeapon: number;
  inventory: (number | null)[];
  ammo: number[];
  reload: number;
  cooldown: number;
  grenades: number;
  kits: number;
  kills: number;
  deaths: number;
  dead: number;
  vy: number;
  vehicle: string;
  seat: string;
  lastHit: number;
  lastHitFrom: Vec | null;
  killer: string;
  protect: number;
  ads: boolean;
  firing: number;
  walk: number;
};
export type Vehicle = {
  id: string;
  pos: Vec;
  yaw: number;
  team: number;
  fixed: boolean;
  hp: number;
  driver: string;
  gunner: string;
  turretYaw: number;
  turretPitch: number;
  dead: number;
  speed: number;
};
export type Projectile = {
  id: number;
  owner: string;
  pos: Vec;
  vel: Vec;
  life: number;
  grenade: boolean;
};
export type GameEvent = {
  id: number;
  t: number;
  type:
    | 'shot'
    | 'hit'
    | 'bleed'
    | 'death'
    | 'explosion'
    | 'patch'
    | 'limb'
    | 'pickup';
  pos: Vec;
  end?: Vec;
  actor: string;
  target?: string;
  weapon?: number;
  part?: number;
};
export type Pickup = {
  id: number;
  weapon: number;
  pos: Vec;
  cooldown: number;
  dropped: boolean;
  expires: number;
};
export type State = {
  protocol: number;
  rules: MatchRules;
  pickups: Pickup[];
  map: MapId;
  time: number;
  remaining: number;
  score: number[];
  actors: Actor[];
  vehicles: Vehicle[];
  projectiles: Projectile[];
  patches: number[];
  events: GameEvent[];
  winner: number;
};
export type HistoryFrame = {
  time: number;
  actors: Actor[];
  vehicles: Vehicle[];
  events: GameEvent[];
};
export function lookDirection(yaw: number, pitch: number): Vec {
  return v(
    -Math.sin(yaw) * Math.cos(pitch),
    Math.sin(pitch),
    -Math.cos(yaw) * Math.cos(pitch),
  );
}
export function eye(a: Actor): Vec {
  return v(
    a.pos.x,
    a.pos.y +
      (a.seat === 'turret'
        ? 2.55
        : a.seat === 'driver'
          ? 1.63
          : !a.limbs[2] && !a.limbs[3]
            ? 0.85
            : 1.68),
    a.pos.z,
  );
}
export function nearbyPickup(
  world: World,
  pickups: Pickup[],
  rules: MatchRules,
  a: Actor,
): Pickup | undefined {
  return pickups
    .filter(
      (p) =>
        p.cooldown === 0 &&
        allowedWeapon(p.weapon, rules) &&
        distance(a.pos, p.pos) < 2.1,
    )
    .filter((p) => {
      const origin = eye(a),
        end = v(p.pos.x, p.pos.y + 0.65, p.pos.z),
        dist = distance(origin, end);
      if (dist < 0.001) return true;
      const dir = v(
        (end.x - origin.x) / dist,
        (end.y - origin.y) / dist,
        (end.z - origin.z) / dist,
      );
      return wallDistance(world, origin, dir) >= dist - 0.05;
    })
    .sort((p, q) => distance(a.pos, p.pos) - distance(a.pos, q.pos))[0];
}
export function sanitizeInput(value: unknown): Input | null {
  if (!value || typeof value !== 'object') return null;
  const a = value as Record<string, unknown>;
  for (const key of ['forward', 'strafe', 'yaw', 'pitch'])
    if (typeof a[key] !== 'number' || !Number.isFinite(a[key])) return null;
  const out = emptyInput();
  out.forward = clamp(a.forward as number, -1, 1);
  out.strafe = clamp(a.strafe as number, -1, 1);
  out.yaw = (a.yaw as number) % (Math.PI * 2);
  out.pitch = clamp(a.pitch as number, -1.4, 1.4);
  for (const key of [
    'shoot',
    'ads',
    'sprint',
    'jump',
    'reload',
    'use',
    'turret',
    'patch',
    'grenade',
    'pickup',
  ] as const)
    out[key] = a[key] === true;
  if (Number.isInteger(a.weapon) && SELECTABLE.includes(a.weapon as number))
    out.weapon = a.weapon as number;
  return out;
}
export class Simulation {
  world: World;
  state: State;
  inputs = new Map<string, Input>();
  seq = 0;
  random: () => number;
  brains = new Map<string, BotMemory>();
  aiPaths = new Map<string, { path: Vec[]; until: number }>();
  constructor(
    map: MapId,
    random: () => number = Math.random,
    rules: MatchRules = DEFAULT_RULES,
  ) {
    this.world = createWorld(map);
    this.random = random;
    this.state = {
      protocol: ROOM_PROTOCOL,
      rules: { ...(validRules(rules) ? rules : DEFAULT_RULES) },
      pickups: [],
      map,
      time: 0,
      remaining: 360,
      score: [0, 0],
      actors: [],
      vehicles: [
        this.vehicle('green', v(-2, 0, 31), 0),
        this.vehicle('rust', v(3, 0, -31), 1),
        this.vehicle('wreck', v(2, 0, -4), -1, true),
      ],
      projectiles: [],
      patches: [0, 0, 0, 0],
      events: [],
      winner: -1,
    };
    this.createPickups();
  }
  vehicle(id: string, pos: Vec, team: number, fixed = false): Vehicle {
    return {
      id,
      pos,
      yaw: team === 1 ? Math.PI : 0,
      team,
      fixed,
      hp: fixed ? 500 : 300,
      driver: '',
      gunner: '',
      turretYaw: 0,
      turretPitch: 0,
      dead: 0,
      speed: 0,
    };
  }
  addPlayer(
    id: string,
    name: string,
    team: number,
    bot = false,
    weapon = 0,
  ): Actor {
    const a: Actor = {
      id,
      name: name.slice(0, 20),
      team,
      bot,
      pos: v(),
      yaw: team ? Math.PI : 0,
      pitch: 0,
      hp: 100,
      bleed: 0,
      limbs: [true, true, true, true],
      weapon,
      preferredWeapon: weapon,
      inventory: startingInventory(this.state.rules, weapon),
      ammo: WEAPONS.map((w) => w.mag),
      reload: 0,
      cooldown: 0,
      grenades: 3,
      kits: 1,
      kills: 0,
      deaths: 0,
      dead: 0,
      vy: 0,
      vehicle: '',
      seat: '',
      lastHit: -10,
      lastHitFrom: null,
      killer: '',
      protect: 2,
      ads: false,
      firing: 0,
      walk: 0,
    };
    this.state.actors.push(a);
    this.spawn(a);
    return a;
  }
  fillBots() {
    const names = [
      'Cinder',
      'Sprocket',
      'Rivet',
      'Clutch',
      'Studs',
      'Axle',
      'Blockhead',
      'Patch',
    ];
    for (let team = 0; team < 2; team++)
      while (this.state.actors.filter((a) => a.team === team).length < 4) {
        const n = this.state.actors.length;
        this.addPlayer(
          'bot-' + this.seq++,
          names[n % names.length],
          team,
          true,
          n % 3,
        );
      }
  }
  removePlayer(id: string) {
    const a = this.state.actors.find((a) => a.id === id);
    if (a) this.dismount(a);
    this.state.actors = this.state.actors.filter((a) => a.id !== id);
    this.inputs.delete(id);
    this.brains.delete(id);
    this.aiPaths.delete(id);
  }
  spawn(a: Actor) {
    const options = this.world.spawns[a.team];
    a.pos = { ...options[Math.floor(this.random() * options.length)] };
    a.yaw = a.team ? Math.PI : 0;
    a.pitch = 0;
    a.hp = 100;
    a.bleed = 0;
    a.dead = 0;
    a.limbs = [true, true, true, true];
    a.inventory = startingInventory(this.state.rules, a.preferredWeapon);
    a.weapon = a.inventory.includes(a.preferredWeapon)
      ? a.preferredWeapon
      : a.inventory.find((id): id is number => id !== null)!;
    a.lastHit = -10;
    a.lastHitFrom = null;
    a.firing = 0;
    a.cooldown = 0;
    a.ads = false;
    this.brains.delete(a.id);
    this.aiPaths.delete(a.id);
    a.ammo = WEAPONS.map((w) => w.mag);
    a.kits = 1;
    a.grenades = allowedGrenades(this.state.rules) ? 3 : 0;
    a.reload = 0;
    a.protect = 2;
    a.vy = 0;
    a.vehicle = '';
    a.seat = '';
  }
  event(
    type: GameEvent['type'],
    pos: Vec,
    actor: string,
    extra: Partial<GameEvent> = {},
  ) {
    this.state.events.push({
      id: ++this.seq,
      t: this.state.time,
      type,
      pos: { ...pos },
      actor,
      ...extra,
    });
    if (this.state.events.length > 90) this.state.events.shift();
  }
  setInput(id: string, input: Input) {
    this.inputs.set(id, input);
  }
  tick(dt: number) {
    dt = clamp(dt, 0, 0.1);
    const s = this.state;
    if (s.winner !== -1) return;
    s.time += dt;
    s.remaining = Math.max(0, s.remaining - dt);
    for (const p of s.pickups) p.cooldown = Math.max(0, p.cooldown - dt);
    s.pickups = s.pickups.filter((p) => !p.dropped || p.expires > s.time);
    for (let i = 0; i < s.patches.length; i++)
      s.patches[i] = Math.max(0, s.patches[i] - dt);
    for (const car of s.vehicles) {
      if (car.dead > 0) {
        car.dead -= dt;
        if (car.dead <= 0) {
          Object.assign(
            car,
            this.vehicle(
              car.id,
              car.id === 'green'
                ? v(-2, 0, 31)
                : car.id === 'rust'
                  ? v(3, 0, -31)
                  : v(2, 0, -4),
              car.team,
              car.fixed,
            ),
          );
        }
      }
    }
    for (const a of s.actors) {
      if (a.dead > 0) {
        a.dead -= dt;
        if (a.dead <= 0) this.spawn(a);
        continue;
      }
      a.protect = Math.max(0, a.protect - dt);
      a.cooldown = Math.max(0, a.cooldown - dt);
      a.firing = Math.max(0, a.firing - dt);
      if (a.reload > 0) {
        a.reload -= dt;
        if (a.reload <= 0)
          a.ammo[a.seat === 'turret' ? 3 : a.weapon] =
            WEAPONS[a.seat === 'turret' ? 3 : a.weapon].mag;
      }
      if (a.bleed > 0) {
        a.hp -= a.bleed * dt;
        if (a.hp <= 0) {
          this.kill(a, a.killer);
          continue;
        }
        if (Math.floor(s.time * 3) !== Math.floor((s.time - dt) * 3))
          this.event('bleed', v(a.pos.x, a.pos.y + 0.7, a.pos.z), a.killer, {
            target: a.id,
          });
      }
      const input = a.bot
        ? this.ai(a, dt)
        : this.inputs.get(a.id) || emptyInput();
      this.act(a, input, dt);
      if (!a.bot)
        for (const key of [
          'use',
          'turret',
          'patch',
          'grenade',
          'jump',
          'reload',
          'pickup',
        ] as const)
          input[key] = false;
      for (let i = 0; i < this.world.patches.length; i++)
        if (
          s.patches[i] === 0 &&
          distance(a.pos, this.world.patches[i]) < 1.45 &&
          (a.hp < 100 || a.bleed > 0 || a.kits < 2)
        ) {
          this.heal(a);
          a.kits = Math.min(2, a.kits + 1);
          s.patches[i] = 18;
        }
    }
    for (const p of [...s.projectiles]) {
      const old = { ...p.pos },
        speed = Math.hypot(p.vel.x, p.vel.y, p.vel.z),
        len = speed * dt;
      if (len <= 0) continue;
      const d = v(p.vel.x / speed, p.vel.y / speed, p.vel.z / speed);
      let hit = wallDistance(this.world, old, d),
        direct = '';
      const owner = s.actors.find((a) => a.id === p.owner);
      for (const a of s.actors)
        if (a.id !== p.owner && a.dead <= 0 && a.team !== owner?.team) {
          const t = rayBox(
            old,
            d,
            v(a.pos.x - 0.45, a.pos.y, a.pos.z - 0.45),
            v(a.pos.x + 0.45, a.pos.y + 2, a.pos.z + 0.45),
          );
          if (t < hit) {
            hit = t;
            direct = a.id;
          }
        }
      for (const c of s.vehicles)
        if (!c.dead && owner?.vehicle !== c.id) {
          const t = rayBox(
            old,
            d,
            v(c.pos.x - 1.25, 0, c.pos.z - 2.1),
            v(c.pos.x + 1.25, 2.1, c.pos.z + 2.1),
          );
          if (t < hit) {
            hit = t;
            direct = '';
          }
        }
      p.pos.x += p.vel.x * dt;
      p.pos.y += p.vel.y * dt;
      p.pos.z += p.vel.z * dt;
      if (p.grenade) p.vel.y -= 9 * dt;
      p.life -= dt;
      if (
        hit <= len ||
        p.pos.y < 0.1 ||
        p.life <= 0 ||
        Math.abs(p.pos.x) > 36 ||
        Math.abs(p.pos.z) > 36
      ) {
        if (hit <= len)
          p.pos = v(old.x + d.x * hit, old.y + d.y * hit, old.z + d.z * hit);
        else direct = '';
        this.explode(
          p.pos,
          p.owner,
          p.grenade ? 85 : 140,
          p.grenade ? 4 : 6,
          p.grenade ? '' : direct,
          p.grenade ? 0 : 2,
        );
        s.projectiles = s.projectiles.filter((q) => q.id !== p.id);
      }
    }
    if (s.remaining === 0 || s.score.some((n) => n >= 50))
      s.winner =
        s.score[0] === s.score[1] ? 2 : s.score[0] > s.score[1] ? 0 : 1;
  }
  act(a: Actor, i: Input, dt: number) {
    a.yaw = i.yaw;
    a.pitch = i.pitch;
    a.ads = i.ads;
    const car = this.state.vehicles.find((v) => v.id === a.vehicle);
    if (i.use || i.turret) {
      if (a.vehicle) this.dismount(a);
      else this.mount(a, i.turret ? 'turret' : 'driver');
    }
    if (i.patch && a.kits > 0 && (a.bleed || a.hp < 100)) {
      a.kits--;
      this.heal(a);
    }
    if (i.pickup && !a.vehicle) this.pickup(a);
    if (
      i.weapon >= 0 &&
      i.weapon !== a.weapon &&
      !a.vehicle &&
      a.inventory.includes(i.weapon) &&
      allowedWeapon(i.weapon, this.state.rules)
    ) {
      a.weapon = i.weapon;
      a.reload = 0;
    }
    if (car && a.vehicle) {
      if (a.seat === 'driver') {
        car.speed += (i.forward * 12 - car.speed) * Math.min(1, dt * 2);
        car.yaw -=
          i.strafe *
          dt *
          1.7 *
          (Math.abs(car.speed) > 1 ? Math.sign(car.speed) : 0);
        const before = { ...car.pos };
        move(
          this.world,
          car.pos,
          -Math.sin(car.yaw) * car.speed * dt,
          -Math.cos(car.yaw) * car.speed * dt,
          2.05,
        );
        if (distance(before, car.pos) < Math.abs(car.speed * dt) * 0.3)
          car.speed *= 0.5;
        a.yaw = car.yaw + i.yaw * 0.15;
        for (const other of this.state.actors)
          if (
            other.dead <= 0 &&
            !other.vehicle &&
            other.team !== a.team &&
            distance(other.pos, car.pos) < 2 &&
            Math.abs(car.speed) > 4
          )
            this.damage(other, Math.abs(car.speed) * 7 * dt, a.id, 2);
      } else {
        car.turretYaw = a.yaw;
        car.turretPitch = a.pitch;
      }
      for (const rider of this.state.actors)
        if (rider.vehicle === car.id) rider.pos = { ...car.pos };
    } else {
      const legs = Number(a.limbs[2]) + Number(a.limbs[3]);
      const speed =
        (i.sprint && !i.shoot ? 7.5 : 4.4) *
        (i.ads ? 0.65 : 1) *
        (legs === 2 ? 1 : legs === 1 ? 0.57 : 0.22);
      let f = i.forward,
        r = i.strafe;
      const norm = Math.max(1, Math.hypot(f, r));
      f /= norm;
      r /= norm;
      move(
        this.world,
        a.pos,
        (-Math.sin(a.yaw) * f + Math.cos(a.yaw) * r) * speed * dt,
        (-Math.cos(a.yaw) * f - Math.sin(a.yaw) * r) * speed * dt,
      );
      if (i.jump && a.pos.y <= 0 && legs > 0) a.vy = 6;
      a.vy -= 17 * dt;
      a.pos.y = Math.max(0, a.pos.y + a.vy * dt);
      if (a.pos.y === 0) a.vy = 0;
      a.walk += Math.hypot(f, r) * dt * speed;
    }
    if (i.reload) this.reload(a);
    if (i.shoot && a.seat !== 'driver') this.fire(a);
    if (
      i.grenade &&
      allowedGrenades(this.state.rules) &&
      a.weapon === 1 &&
      a.grenades > 0 &&
      a.cooldown === 0 &&
      a.seat !== 'driver'
    ) {
      a.grenades--;
      a.cooldown = 0.8;
      this.launch(a, true);
    }
  }
  reload(a: Actor) {
    const wi = a.seat === 'turret' ? 3 : a.weapon;
    if (a.reload <= 0 && a.ammo[wi] < WEAPONS[wi].mag)
      a.reload = WEAPONS[wi].reload;
  }
  trace(a: Actor, o: Vec, d: Vec) {
    let dist = wallDistance(this.world, o, d),
      target: Actor | undefined,
      part = -1,
      car: Vehicle | undefined;
    for (const c of this.state.vehicles)
      if (!c.dead && c.id !== a.vehicle) {
        const t = rayBox(
          o,
          d,
          v(c.pos.x - 1.15, 0, c.pos.z - 2.15),
          v(c.pos.x + 1.15, 2.1, c.pos.z + 2.15),
        );
        if (t < dist) {
          dist = t;
          car = c;
        }
      }
    for (const other of this.state.actors) {
      if (
        other.id === a.id ||
        other.dead > 0 ||
        other.team === a.team ||
        other.seat === 'driver'
      )
        continue;
      const p = other.pos,
        low = !other.limbs[2] && !other.limbs[3] ? 0.6 : 0;
      const pieces = [
        [-0.24, 1.47 - low, -0.24, 0.24, 1.98 - low, 0.24, -2],
        [-0.34, 0.76 - low, -0.24, 0.34, 1.46 - low, 0.24, -1],
        [-0.6, 0.81 - low, -0.24, -0.34, 1.42 - low, 0.24, 0],
        [0.34, 0.81 - low, -0.24, 0.6, 1.42 - low, 0.24, 1],
        [-0.34, 0, -0.24, -0.02, 0.75, 0.24, 2],
        [0.02, 0, -0.24, 0.34, 0.75, 0.24, 3],
      ];
      for (const [x, y, z, X, Y, Z, partId] of pieces) {
        if (partId >= 0 && !other.limbs[partId]) continue;
        const hit = rayBox(
          o,
          d,
          v(p.x + x, p.y + y, p.z + z),
          v(p.x + X, p.y + Y, p.z + Z),
        );
        if (hit < dist) {
          dist = hit;
          target = other;
          part = partId;
          car = undefined;
        }
      }
    }
    return {
      dist,
      target,
      part,
      car,
      end: v(o.x + d.x * dist, o.y + d.y * dist, o.z + d.z * dist),
    };
  }
  muzzle(a: Actor) {
    return weaponMuzzle(
      a,
      this.state.vehicles.find((c) => c.id === a.vehicle)?.yaw || 0,
    );
  }
  fire(a: Actor) {
    const wi = a.seat === 'turret' ? 3 : a.weapon,
      w = WEAPONS[wi];
    if (
      !w ||
      !allowedWeapon(wi, this.state.rules) ||
      (a.seat !== 'turret' && !a.inventory.includes(wi)) ||
      a.seat === 'driver' ||
      a.dead > 0 ||
      a.cooldown > 0 ||
      a.reload > 0
    )
      return;
    if (a.ammo[wi] <= 0) {
      this.reload(a);
      return;
    }
    a.ammo[wi]--;
    a.cooldown = w.interval;
    a.firing = MUZZLE_FLASH_DURATION;
    a.protect = 0;
    if (w.rocket) {
      this.launch(a, false);
      return;
    }
    const spread =
      w.spread *
      (a.ads ? 0.3 : 1) *
      (a.bot ? 2 : 1) *
      (a.limbs[0] && a.limbs[1] ? 1 : 2.2);
    const aim = lookDirection(
        a.yaw + (this.random() - 0.5) * spread,
        a.pitch + (this.random() - 0.5) * spread,
      ),
      eyes = eye(a),
      aimHit = this.trace(a, eyes, aim);
    let origin = this.muzzle(a);
    const toMuzzle = distance(eyes, origin),
      safe = v(
        (origin.x - eyes.x) / toMuzzle,
        (origin.y - eyes.y) / toMuzzle,
        (origin.z - eyes.z) / toMuzzle,
      );
    const obstruction = wallDistance(this.world, eyes, safe);
    if (obstruction < toMuzzle) {
      this.event('shot', origin, a.id, {
        end: v(
          eyes.x + safe.x * obstruction,
          eyes.y + safe.y * obstruction,
          eyes.z + safe.z * obstruction,
        ),
        weapon: wi,
      });
      return;
    }
    const dist = distance(origin, aimHit.end),
      d = v(
        (aimHit.end.x - origin.x) / dist,
        (aimHit.end.y - origin.y) / dist,
        (aimHit.end.z - origin.z) / dist,
      ),
      hit = this.trace(a, origin, d);
    this.event('shot', origin, a.id, { end: hit.end, weapon: wi });
    if (hit.target)
      this.damage(
        hit.target,
        w.damage * (hit.part === -2 ? w.headshot : hit.part >= 0 ? 0.85 : 1),
        a.id,
        hit.part,
      );
    if (hit.car) this.damageVehicle(hit.car, w.damage * 0.4, a.id);
  }
  launch(a: Actor, grenade: boolean) {
    const aim = lookDirection(a.yaw, a.pitch),
      eyes = eye(a),
      target = this.trace(a, eyes, aim).end,
      o = this.muzzle(a),
      distanceToAim = distance(o, target);
    const d = v(
      (target.x - o.x) / distanceToAim,
      (target.y - o.y) / distanceToAim,
      (target.z - o.z) / distanceToAim,
    );
    a.firing = MUZZLE_FLASH_DURATION;
    a.protect = 0;
    this.event('shot', o, a.id, { weapon: a.weapon });
    const between = distance(eyes, o),
      toward = v(
        (o.x - eyes.x) / between,
        (o.y - eyes.y) / between,
        (o.z - eyes.z) / between,
      ),
      obstruction = wallDistance(this.world, eyes, toward);
    if (obstruction < between) {
      this.explode(
        v(
          eyes.x + toward.x * obstruction,
          eyes.y + toward.y * obstruction,
          eyes.z + toward.z * obstruction,
        ),
        a.id,
        grenade ? 85 : 140,
        grenade ? 4 : 6,
        '',
        grenade ? 0 : 2,
      );
      return;
    }
    this.state.projectiles.push({
      id: ++this.seq,
      owner: a.id,
      pos: { ...o },
      vel: v(
        d.x * (grenade ? 22 : 33),
        d.y * (grenade ? 22 : 33) + (grenade ? 2 : 0),
        d.z * (grenade ? 22 : 33),
      ),
      life: grenade ? 2.5 : 4,
      grenade,
    });
  }
  damage(
    a: Actor,
    amount: number,
    attacker: string,
    part = -1,
    explosive = false,
    from?: Vec,
  ) {
    if (a.dead > 0 || a.protect > 0) return;
    const source = this.state.actors.find((p) => p.id === attacker);
    if (source && source.id !== a.id && source.team === a.team) return;
    a.hp -= amount;
    a.lastHit = this.state.time;
    a.lastHitFrom = from ? { ...from } : source ? { ...source.pos } : null;
    a.killer = attacker;
    a.bleed = Math.min(2.5, a.bleed + amount * 0.009);
    this.event('hit', v(a.pos.x, a.pos.y + 1, a.pos.z), attacker, {
      target: a.id,
    });
    if (
      part >= 0 &&
      amount >= 18 &&
      a.limbs[part] &&
      (explosive || amount >= 28 || this.random() < 0.22)
    ) {
      a.limbs[part] = false;
      a.bleed = Math.min(2.5, a.bleed + 0.6);
      this.event('limb', v(a.pos.x, a.pos.y + 0.8, a.pos.z), attacker, {
        target: a.id,
        part,
      });
    }
    if (a.hp <= 0) this.kill(a, attacker);
  }
  kill(a: Actor, killer: string) {
    if (a.dead > 0) return;
    a.hp = 0;
    this.dropWeapon(a.weapon, a.pos, a.ammo[a.weapon]);
    a.dead = 5;
    a.deaths++;
    a.killer = killer;
    this.dismount(a);
    const source = this.state.actors.find((b) => b.id === killer);
    if (source && source.team !== a.team) {
      source.kills++;
      this.state.score[source.team]++;
    }
    this.event('death', v(a.pos.x, a.pos.y + 1, a.pos.z), killer, {
      target: a.id,
      weapon: source?.seat === 'turret' ? 3 : source?.weapon,
    });
  }
  heal(a: Actor) {
    a.hp = Math.min(100, a.hp + 60);
    a.bleed = 0;
    this.event('patch', a.pos, a.id);
  }
  explode(
    p: Vec,
    owner: string,
    damage: number,
    radius: number,
    directId = '',
    lethalRadius = 0,
  ) {
    this.event('explosion', p, owner);
    for (const a of this.state.actors) {
      if (a.dead > 0) continue;
      if (a.id === directId) {
        this.damage(a, 220, owner, -1, true, p);
        continue;
      }
      const q = v(a.pos.x, a.pos.y + 1, a.pos.z),
        dist = distance(p, q);
      if (dist > radius) continue;
      if (dist > 0.001) {
        const dir = v(
          (q.x - p.x) / dist,
          (q.y - p.y) / dist,
          (q.z - p.z) / dist,
        );
        if (
          wallDistance(
            this.world,
            v(p.x + dir.x * 0.03, p.y + dir.y * 0.03, p.z + dir.z * 0.03),
            dir,
          ) <
          dist - 0.15
        )
          continue;
      }
      const amount =
        dist <= lethalRadius
          ? damage
          : damage * (1 - (dist - lethalRadius) / (radius - lethalRadius));
      this.damage(a, amount, owner, Math.floor(this.random() * 4), true, p);
    }
    for (const car of this.state.vehicles)
      if (!car.dead && distance(car.pos, p) < radius + 2)
        this.damageVehicle(
          car,
          damage * 2 * (1 - Math.max(0, distance(car.pos, p) - 2) / radius),
          owner,
        );
  }
  damageVehicle(car: Vehicle, amount: number, attacker: string) {
    if (car.dead > 0) return;
    car.hp -= amount;
    if (car.hp > 0) return;
    car.hp = 0;
    car.dead = 30;
    car.speed = 0;
    this.event('explosion', v(car.pos.x, 1, car.pos.z), attacker);
    for (const a of this.state.actors)
      if (a.vehicle === car.id) {
        this.dismount(a);
        a.protect = 0;
        this.damage(a, 200, attacker, -1, true);
      }
    car.driver = '';
    car.gunner = '';
  }
  mount(a: Actor, seat: string) {
    if (
      a.dead > 0 ||
      (seat === 'turret' && !allowedWeapon(3, this.state.rules))
    )
      return;
    const car = this.state.vehicles
      .filter(
        (c) =>
          !c.dead &&
          distance(a.pos, c.pos) < 3.9 &&
          (c.team === -1 || c.team === a.team),
      )
      .sort((x, y) => distance(a.pos, x.pos) - distance(a.pos, y.pos))[0];
    if (!car) return;
    if (seat === 'driver' && (car.fixed || car.driver)) return;
    if (seat === 'turret' && car.gunner) return;
    a.vehicle = car.id;
    a.seat = seat;
    if (seat === 'driver') car.driver = a.id;
    else car.gunner = a.id;
    a.pos = { ...car.pos };
    a.reload = 0;
  }
  dismount(a: Actor) {
    const car = this.state.vehicles.find((c) => c.id === a.vehicle);
    if (car) {
      if (car.driver === a.id) {
        car.driver = '';
        car.speed = 0;
      }
      if (car.gunner === a.id) car.gunner = '';
      const points = [
        v(car.pos.x + 3, 0, car.pos.z),
        v(car.pos.x - 3, 0, car.pos.z),
        v(car.pos.x, 0, car.pos.z + 3),
        v(car.pos.x, 0, car.pos.z - 3),
      ];
      a.pos = points.find((p) => !blocked(this.world, p)) || { ...car.pos };
    }
    a.vehicle = '';
    a.seat = '';
  }
  createPickups() {
    const pads: [[number, number], number][] = [
      [[-4, 22], 2],
      [[4, -22], 2],
      [[-15, 12], 7],
      [[15, -12], 8],
      [[-15, -17], 4],
      [[15, 17], 5],
      [[-4, 30], 9],
      [[4, -30], 6],
      [[0, 20], 1],
      [[0, -14], 0],
    ];
    this.state.pickups = pads
      .filter(([, weapon]) => allowedWeapon(weapon, this.state.rules))
      .map(([[x, z], weapon]) => ({
        id: ++this.seq,
        weapon,
        pos: v(x, 0, z),
        cooldown: 0,
        dropped: false,
        expires: Infinity,
      }));
    // JSON transport must not carry Infinity.
    for (const p of this.state.pickups) p.expires = 0;
  }
  nearestPickup(a: Actor): Pickup | undefined {
    return nearbyPickup(this.world, this.state.pickups, this.state.rules, a);
  }
  dropWeapon(weapon: number, pos: Vec, _ammo: number) {
    if (
      !SELECTABLE.includes(weapon) ||
      !allowedWeapon(weapon, this.state.rules)
    )
      return;
    if (this.state.pickups.length >= 48) {
      const oldest = this.state.pickups.find((p) => p.dropped);
      if (oldest)
        this.state.pickups = this.state.pickups.filter(
          (p) => p.id !== oldest.id,
        );
    }
    this.state.pickups.push({
      id: ++this.seq,
      weapon,
      pos: { ...pos },
      cooldown: 0.6,
      dropped: true,
      expires: this.state.time + 35,
    });
  }
  pickup(a: Actor) {
    if (a.dead > 0 || a.vehicle) return false;
    const pickup = this.nearestPickup(a);
    if (!pickup) return false;
    const slot = WEAPONS[pickup.weapon].slot,
      old = a.inventory[slot];
    if (old !== null && old !== pickup.weapon)
      this.dropWeapon(old, a.pos, a.ammo[old]);
    a.inventory[slot] = pickup.weapon;
    a.weapon = pickup.weapon;
    a.ammo[pickup.weapon] = WEAPONS[pickup.weapon].mag;
    a.reload = 0;
    a.cooldown = 0.25;
    if (pickup.dropped)
      this.state.pickups = this.state.pickups.filter((p) => p.id !== pickup.id);
    else pickup.cooldown = 20;
    this.event('pickup', pickup.pos, a.id, { weapon: pickup.weapon });
    return true;
  }
  ai(a: Actor, dt: number): Input {
    const i = emptyInput();
    i.yaw = a.yaw;
    i.pitch = a.pitch;
    i.patch = a.bleed > 1 || a.hp < 40;
    let brain = this.brains.get(a.id);
    if (!brain) {
      brain = createBotMemory();
      this.brains.set(a.id, brain);
    }
    const target = perceive(
      this.world,
      this.state.vehicles,
      a,
      this.state.actors,
      brain,
      this.state.time,
      this.random,
    );
    let destination: Vec | null = null;
    if (target) {
      const dx = target.point.x - a.pos.x,
        dz = target.point.z - a.pos.z,
        dist = Math.hypot(dx, dz),
        desired = Math.atan2(-dx, -dz) + brain.aimOffset;
      const difference = Math.atan2(
        Math.sin(desired - a.yaw),
        Math.cos(desired - a.yaw),
      );
      i.yaw = a.yaw + clamp(difference, -dt * 2, dt * 2);
      i.pitch = Math.atan2(target.point.y - eye(a).y, dist);
      i.ads = dist > 20;
      if (this.state.time >= brain.readyAt && Math.abs(difference) < 0.1) {
        if (
          this.state.time >= brain.restUntil &&
          this.state.time >= brain.burstEnd
        ) {
          brain.burstEnd = this.state.time + 0.4 + this.random() * 0.3;
          brain.restUntil = brain.burstEnd + 0.35 + this.random() * 0.4;
        }
        i.shoot = this.state.time < brain.burstEnd;
      }
      if (dist > 18) destination = { ...target.position };
      else i.strafe = Math.sin(this.state.time * 0.8 + a.id.length) * 0.4;
    } else {
      if (
        brain.lastSeen &&
        this.state.time - brain.lastSeenAt < 2.2 &&
        distance(a.pos, brain.lastSeen) > 2
      )
        destination = { ...brain.lastSeen };
      else {
        if (
          !brain.patrol ||
          distance(a.pos, brain.patrol) < 2 ||
          this.state.time > brain.patrolUntil
        ) {
          const routes = [
            v(0, 0, -23),
            v(0, 0, 23),
            v(-15, 0, -18),
            v(15, 0, 18),
            v(-15, 0, 15),
            v(15, 0, -15),
            v(-4, 0, -5),
            v(4, 0, 9),
          ];
          brain.patrol = routes[Math.floor(this.random() * routes.length)];
          brain.patrolUntil = this.state.time + 12;
        }
        destination = brain.patrol;
      }
    }
    if (destination) {
      let route = this.aiPaths.get(a.id);
      if (!route || route.until < this.state.time) {
        route = {
          path: this.path(a.pos, destination),
          until: this.state.time + 1.2,
        };
        this.aiPaths.set(a.id, route);
      }
      while (route.path.length && distance(a.pos, route.path[0]) < 1.4)
        route.path.shift();
      const next = route.path[0];
      if (next) {
        const angle = Math.atan2(-(next.x - a.pos.x), -(next.z - a.pos.z));
        if (!target) {
          const diff = Math.atan2(
            Math.sin(angle - a.yaw),
            Math.cos(angle - a.yaw),
          );
          i.yaw = a.yaw + clamp(diff, -dt * 1.7, dt * 1.7);
          i.pitch *= Math.max(0, 1 - dt * 3);
        }
        i.forward = Math.cos(angle - i.yaw);
        i.strafe = -Math.sin(angle - i.yaw);
      }
    }
    return i;
  }
  path(start: Vec, end: Vec): Vec[] {
    const size = 35,
      step = 2,
      toCell = (p: Vec) => [
        clamp(Math.round((p.x + 34) / step), 0, 34),
        clamp(Math.round((p.z + 34) / step), 0, 34),
      ];
    const [sx, sz] = toCell(start),
      [ex, ez] = toCell(end),
      source = sz * size + sx,
      goal = ez * size + ex,
      queue = [source],
      prev = new Map<number, number>([[source, -1]]);
    let found = -1;
    for (let head = 0; head < queue.length; head++) {
      const n = queue[head];
      if (n === goal) {
        found = n;
        break;
      }
      const x = n % size,
        z = Math.floor(n / size);
      for (const [dx, dz] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const X = x + dx,
          Z = z + dz,
          key = Z * size + X;
        if (
          X < 0 ||
          X >= size ||
          Z < 0 ||
          Z >= size ||
          prev.has(key) ||
          blocked(this.world, v(X * step - 34, 0, Z * step - 34), 0.55)
        )
          continue;
        prev.set(key, n);
        queue.push(key);
      }
    }
    if (found < 0) return [];
    const path: Vec[] = [];
    for (let n = found; n !== source && n >= 0; n = prev.get(n) ?? -1)
      path.push(v((n % size) * step - 34, 0, Math.floor(n / size) * step - 34));
    return path.reverse();
  }
  snapshot(): State {
    return structuredClone(this.state);
  }
}
export class ReplayBuffer {
  frames: HistoryFrame[] = [];
  last = -1;
  record(s: State, force = false) {
    if (!force && s.time - this.last < 0.075) return;
    this.last = s.time;
    this.frames.push({
      time: s.time,
      actors: structuredClone(s.actors),
      vehicles: structuredClone(s.vehicles),
      events: structuredClone(s.events.filter((e) => s.time - e.t < 0.15)),
    });
    while (this.frames.length && s.time - this.frames[0].time > 4)
      this.frames.shift();
  }
  clip(deathTime: number) {
    return this.frames
      .filter((f) => f.time >= deathTime - 3.2 && f.time <= deathTime)
      .map((f) => structuredClone(f));
  }
}
export function replayFrame(
  frames: HistoryFrame[],
  elapsed: number,
): HistoryFrame | undefined {
  if (!frames.length) return;
  const t = frames[0].time + elapsed;
  return frames.find((f) => f.time >= t) || frames[frames.length - 1];
}
