import { v, type Vec } from './world';

export type WeaponSlot = 0 | 1 | 2;
export type Weapon = {
  name: string;
  slot: WeaponSlot;
  mag: number;
  damage: number;
  interval: number;
  reload: number;
  spread: number;
  rocket: boolean;
  sniper: boolean;
  headshot: number;
  muzzle: Vec;
};
const rifle = { slot: 0 as const, rocket: false, sniper: false, headshot: 1.5 };
export const WEAPONS: Weapon[] = [
  {
    ...rifle,
    name: 'AK-47',
    mag: 30,
    damage: 16,
    interval: 0.13,
    reload: 2.1,
    spread: 0.018,
    muzzle: v(0, 0.04, -0.9),
  },
  {
    ...rifle,
    name: 'M16 / M203',
    mag: 30,
    damage: 15,
    interval: 0.12,
    reload: 2,
    spread: 0.012,
    muzzle: v(0, 0.04, -0.9),
  },
  {
    ...rifle,
    name: 'M60',
    mag: 100,
    damage: 18,
    interval: 0.15,
    reload: 4.2,
    spread: 0.025,
    muzzle: v(0, 0.04, -1.14),
  },
  {
    ...rifle,
    name: 'M2 .50 CAL',
    mag: 200,
    damage: 24,
    interval: 0.15,
    reload: 4,
    spread: 0.015,
    muzzle: v(0, 0.04, -1.25),
  },
  {
    ...rifle,
    slot: 2,
    name: 'RPG-7',
    mag: 1,
    damage: 220,
    interval: 1,
    reload: 3.4,
    spread: 0.008,
    rocket: true,
    muzzle: v(0, 0.03, -1.1),
  },
  {
    ...rifle,
    slot: 2,
    name: 'M1 BAZOOKA',
    mag: 1,
    damage: 220,
    interval: 1,
    reload: 3,
    spread: 0.008,
    rocket: true,
    muzzle: v(0, 0.03, -1.1),
  },
  {
    ...rifle,
    slot: 1,
    name: 'M1911',
    mag: 8,
    damage: 20,
    interval: 0.32,
    reload: 1.5,
    spread: 0.016,
    muzzle: v(0, 0.04, -0.49),
  },
  {
    ...rifle,
    name: 'M24',
    mag: 5,
    damage: 72,
    interval: 1.25,
    reload: 2.8,
    spread: 0.002,
    sniper: true,
    headshot: 2,
    muzzle: v(0, 0.04, -1.3),
  },
  {
    ...rifle,
    name: 'M82',
    mag: 10,
    damage: 88,
    interval: 1.15,
    reload: 3.3,
    spread: 0.003,
    sniper: true,
    headshot: 2,
    muzzle: v(0, 0.04, -1.46),
  },
  {
    ...rifle,
    slot: 1,
    name: 'M9',
    mag: 15,
    damage: 16,
    interval: 0.23,
    reload: 1.6,
    spread: 0.019,
    muzzle: v(0, 0.04, -0.49),
  },
];
export const SELECTABLE = WEAPONS.map((_, i) => i).filter((i) => i !== 3);
export const VARIANTS = [
  'standard',
  'no-snipers',
  'snipers-only',
  'pistols-only',
  'rockets-only',
] as const;
export type Variant = (typeof VARIANTS)[number];
export type MatchRules = { variant: Variant };
export const RULE_LABELS: Record<Variant, string> = {
  standard: 'Standard',
  'no-snipers': 'No Snipers',
  'snipers-only': 'Snipers Only',
  'pistols-only': 'Pistols Only',
  'rockets-only': 'Rockets Only',
};
export const DEFAULT_RULES: MatchRules = { variant: 'standard' };
export function validRules(value: unknown): value is MatchRules {
  return (
    !!value &&
    typeof value === 'object' &&
    VARIANTS.includes((value as MatchRules).variant)
  );
}
export function allowedWeapon(index: number, rules: MatchRules): boolean {
  const w = WEAPONS[index];
  if (!w) return false;
  if (rules.variant === 'no-snipers') return !w.sniper;
  if (rules.variant === 'snipers-only') return w.sniper;
  if (rules.variant === 'pistols-only') return w.slot === 1;
  if (rules.variant === 'rockets-only') return w.rocket;
  return true;
}
export function allowedGrenades(rules: MatchRules) {
  return rules.variant === 'standard' || rules.variant === 'no-snipers';
}
export function startingInventory(
  rules: MatchRules,
  preferred = 0,
): (number | null)[] {
  const slots: (number | null)[] = [null, null, null];
  for (const id of [0, 6, 4, 7]) {
    const w = WEAPONS[id];
    if (slots[w.slot] === null && allowedWeapon(id, rules)) slots[w.slot] = id;
  }
  if (SELECTABLE.includes(preferred) && allowedWeapon(preferred, rules))
    slots[WEAPONS[preferred].slot] = preferred;
  return slots;
}
export const HELD_WEAPON = { x: 0.32, y: 1.25, z: -0.36, scale: 0.95 };
export const TURRET_WEAPON = { x: 0, y: 2.4, z: 0.1, scale: 1.4 };
export const FIRST_PERSON_WEAPON = { x: 0.29, y: -0.31, z: -0.4, scale: 0.82 };
export const MUZZLE_FLASH_DURATION = 0.105;
/** The render rig and the simulation use the same barrel socket and scale. */
export function weaponMuzzle(
  a: {
    pos: Vec;
    yaw: number;
    pitch: number;
    weapon: number;
    seat: string;
    limbs: boolean[];
  },
  vehicleYaw = 0,
): Vec {
  const mounted = a.seat === 'turret',
    pose = mounted ? TURRET_WEAPON : HELD_WEAPON,
    local = WEAPONS[mounted ? 3 : a.weapon].muzzle;
  const cp = Math.cos(a.pitch),
    sp = Math.sin(a.pitch),
    cy = Math.cos(a.yaw),
    sy = Math.sin(a.yaw);
  const x = local.x * pose.scale,
    y = (local.y * cp - local.z * sp) * pose.scale,
    z = (local.y * sp + local.z * cp) * pose.scale;
  const offsetYaw = mounted ? vehicleYaw : a.yaw;
  const ox = pose.x * Math.cos(offsetYaw) + pose.z * Math.sin(offsetYaw),
    oz = -pose.x * Math.sin(offsetYaw) + pose.z * Math.cos(offsetYaw);
  return v(
    a.pos.x + ox + x * cy + z * sy,
    a.pos.y + pose.y + y + (!mounted && !a.limbs[2] && !a.limbs[3] ? -0.6 : 0),
    a.pos.z + oz - x * sy + z * cy,
  );
}
export function hitFeedback(
  a: {
    pos: Vec;
    yaw: number;
    lastHit: number;
    lastHitFrom: Vec | null;
    hp: number;
  },
  now: number,
) {
  const elapsed = now - a.lastHit;
  const opacity =
    elapsed >= 0 && elapsed < 0.85 ? Math.min(0.9, (0.85 - elapsed) * 1.5) : 0;
  const from = a.lastHitFrom;
  const bearing = from
    ? Math.atan2(from.x - a.pos.x, -(from.z - a.pos.z)) + a.yaw
    : 0;
  return {
    opacity,
    angle: (bearing * 180) / Math.PI,
    lowHealth: a.hp > 0 && a.hp < 30,
  };
}
