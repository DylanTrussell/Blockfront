export class AudioFX {
  context:AudioContext|null=null;muted=false;noise:AudioBuffer|null=null;
  unlock(){try{this.context??=new AudioContext();void this.context.resume();if(!this.noise){this.noise=this.context.createBuffer(1,this.context.sampleRate,this.context.sampleRate);const data=this.noise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;}}catch{}}
  play(kind:string,distance=0,weapon=0){const c=this.context;if(!c||this.muted||c.state!=='running'||distance>55)return;const gain=c.createGain(),volume=(kind==='explosion'?.6:kind==='shot'?.18:.08)/(1+distance*.12);gain.connect(c.destination);const now=c.currentTime;
    if(kind==='shot'||kind==='explosion'){if(!this.noise)return;const src=c.createBufferSource();src.buffer=this.noise;const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=kind==='explosion'?330:weapon===3?850:1700;src.connect(filter);filter.connect(gain);const duration=kind==='explosion'?.7:.13;gain.gain.setValueAtTime(volume,now);gain.gain.exponentialRampToValueAtTime(.001,now+duration);src.start();src.stop(now+duration);}
    else {const o=c.createOscillator();o.type='sine';o.frequency.setValueAtTime(kind==='patch'?600:1100,now);o.frequency.exponentialRampToValueAtTime(kind==='patch'?1100:500,now+.1);gain.gain.setValueAtTime(volume,now);gain.gain.exponentialRampToValueAtTime(.001,now+.12);o.connect(gain);o.start();o.stop(now+.15);}
  }
  dispose(){void this.context?.close();}
}
