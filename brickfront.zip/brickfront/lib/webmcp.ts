import { SELECTABLE, VARIANTS, allowedWeapon, type Variant } from './weapons';
type Config = {
  map: 'baghdad' | 'foundry';
  mode: 'solo' | 'online' | 'split';
  weapon: number;
  variant: Variant;
};
export function registerMatchTools(
  read: () => Config,
  configure: (c: Config) => void,
) {
  const context = (
    document as unknown as {
      modelContext?: {
        registerTool: (
          tool: unknown,
          options: { signal: AbortSignal },
        ) => void | Promise<void>;
      };
    }
  ).modelContext;
  if (!context?.registerTool) return () => {};
  const lifecycle = new AbortController();
  const tools = [
    {
      name: 'read_match_configuration',
      title: 'Read match configuration',
      description:
        'Read the selected battlefield, mode, room rules and starting weapon.',
      inputSchema: {
        type: 'object',
        properties: {},
        additionalProperties: false,
      },
      annotations: { readOnlyHint: true, untrustedContentHint: false },
      execute: () => read(),
    },
    {
      name: 'configure_match',
      title: 'Configure a match',
      description:
        'Select the battlefield, play mode and starting weapon in the visible lobby. Does not start or join a match.',
      inputSchema: {
        type: 'object',
        properties: {
          map: { type: 'string', enum: ['baghdad', 'foundry'] },
          mode: { type: 'string', enum: ['solo', 'online', 'split'] },
          weapon: { type: 'integer', enum: SELECTABLE },
          variant: { type: 'string', enum: VARIANTS },
        },
        required: ['map', 'mode', 'weapon', 'variant'],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute: async (input: unknown) => {
        const c = input as Config;
        if (
          !c ||
          !['baghdad', 'foundry'].includes(c.map) ||
          !['solo', 'online', 'split'].includes(c.mode) ||
          !SELECTABLE.includes(c.weapon) ||
          !VARIANTS.includes(c.variant) ||
          !allowedWeapon(c.weapon, { variant: c.variant })
        )
          throw Error('Invalid match configuration');
        configure(c);
        await new Promise<void>((resolve) =>
          requestAnimationFrame(() => resolve()),
        );
        return read();
      },
    },
  ];
  for (const tool of tools)
    try {
      Promise.resolve(
        context.registerTool(tool, { signal: lifecycle.signal }),
      ).catch(() => {});
    } catch {}
  return () => lifecycle.abort();
}
