import * as T from 'three';
import { createWorld, type MapId } from './world';
import { WEAPONS, HELD_WEAPON, TURRET_WEAPON } from './weapons';
import type { Actor } from './simulation';

const materials = new Map<number, T.MeshStandardMaterial>();
const boxGeo = new T.BoxGeometry(1, 1, 1);
const studGeo = new T.CylinderGeometry(0.17, 0.17, 0.1, 12);
export function material(color: number) {
  if (!materials.has(color))
    materials.set(
      color,
      new T.MeshStandardMaterial({ color, roughness: 0.3, metalness: 0.03 }),
    );
  return materials.get(color)!;
}
export function box(
  parent: T.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  color: number,
) {
  const m = new T.Mesh(boxGeo, material(color));
  m.position.set(x, y, z);
  m.scale.set(w, h, d);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}
export function cyl(
  parent: T.Object3D,
  x: number,
  y: number,
  z: number,
  r: number,
  h: number,
  color: number,
  sides = 12,
) {
  const m = new T.Mesh(new T.CylinderGeometry(r, r, h, sides), material(color));
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}
export function brick(
  parent: T.Object3D,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  color: number,
  studs = true,
) {
  const b = box(parent, x, y, z, w - 0.025, h - 0.02, d - 0.025, color);
  if (studs) {
    const nx = Math.max(1, Math.floor(w / 0.5)),
      nz = Math.max(1, Math.floor(d / 0.5));
    const mesh = new T.InstancedMesh(studGeo, material(color), nx * nz);
    let n = 0;
    const mat = new T.Matrix4();
    for (let i = 0; i < nx; i++)
      for (let j = 0; j < nz; j++)
        mesh.setMatrixAt(
          n++,
          mat.makeTranslation(
            x + (i - (nx - 1) / 2) * 0.5,
            y + h / 2 + 0.03,
            z + (j - (nz - 1) / 2) * 0.5,
          ),
        );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
  }
  return b;
}
export function weaponModel(index: number, firstPerson = false): T.Group {
  const g = new T.Group(),
    w = WEAPONS[index],
    steel = 0x4f5a60,
    dark = 0x222b30,
    highlight = 0x88969b,
    wood = 0x985824;
  const muzzle = w.muzzle;
  if (w.rocket) {
    const tube = cyl(
      g,
      0,
      0.03,
      -0.32,
      0.115,
      1.18,
      index === 4 ? 0x708341 : 0x577457,
    );
    tube.rotation.x = Math.PI / 2;
    const nose = cyl(g, 0, 0.03, -0.99, index === 4 ? 0.155 : 0.12, 0.22, dark);
    nose.rotation.x = Math.PI / 2;
    cyl(g, 0, 0.03, 0.28, 0.15, 0.1, highlight).rotation.x = Math.PI / 2;
    box(g, 0, -0.18, -0.1, 0.11, 0.3, 0.14, wood);
    box(g, 0.14, 0.18, -0.3, 0.07, 0.18, 0.17, steel);
    for (const z of [-0.3, -0.1, 0.1])
      cyl(g, 0, 0.03, z, 0.13, 0.06, wood).rotation.x = Math.PI / 2;
  } else if (w.slot === 1) {
    box(g, 0, 0.055, -0.25, 0.145, 0.15, 0.46, index === 6 ? highlight : steel);
    box(g, 0, -0.045, -0.22, 0.12, 0.07, 0.37, dark);
    box(
      g,
      0,
      -0.17,
      -0.1,
      0.12,
      0.3,
      0.15,
      index === 6 ? wood : dark,
    ).rotation.x = -0.2;
    cyl(g, 0, 0.04, -0.46, 0.035, 0.07, dark).rotation.x = Math.PI / 2;
    box(g, 0, 0.15, -0.43, 0.026, 0.055, 0.035, dark);
    box(g, 0, 0.14, -0.07, 0.09, 0.04, 0.045, dark);
    box(g, 0.07, -0.075, -0.22, 0.025, 0.12, 0.12, steel);
  } else {
    box(g, 0, 0.03, -0.25, 0.18, 0.18, 0.48, steel);
    box(g, 0, 0.02, 0.09, 0.17, 0.17, 0.32, index === 0 ? wood : dark);
    box(g, 0, -0.17, -0.08, 0.1, 0.24, 0.13, dark).rotation.x = -0.2;
    box(
      g,
      0,
      -0.16,
      -0.34,
      index === 2 ? 0.29 : 0.105,
      0.28,
      0.15,
      index === 0 ? dark : 0x606949,
    ).rotation.x = index === 0 ? -0.25 : 0.08;
    box(g, 0, 0.04, -0.55, 0.18, 0.17, 0.33, index === 0 ? wood : dark);
    const start = -0.6,
      end = muzzle.z,
      barrel = cyl(g, 0, 0.04, (start + end) / 2, 0.037, start - end, steel);
    barrel.rotation.x = Math.PI / 2;
    cyl(g, 0, 0.04, muzzle.z + 0.04, 0.05, 0.08, dark).rotation.x = Math.PI / 2;
    box(g, 0, 0.16, -0.35, 0.14, 0.04, 0.5, highlight);
    if (w.sniper) {
      cyl(g, 0, 0.265, -0.39, 0.075, 0.46, dark).rotation.x = Math.PI / 2;
      for (const z of [-0.63, -0.14])
        cyl(g, 0, 0.265, z, 0.095, 0.07, steel).rotation.x = Math.PI / 2;
      cyl(g, 0, 0.265, -0.678, 0.074, 0.013, 0x64bac8).rotation.x = Math.PI / 2;
      for (const x of [-0.1, 0.1])
        box(g, x, -0.1, -0.78, 0.035, 0.29, 0.04, highlight).rotation.z = x * 4;
      if (index === 8) box(g, 0, 0.04, -1.39, 0.16, 0.12, 0.15, dark);
    } else {
      box(g, 0, 0.19, -0.6, 0.035, 0.16, 0.035, highlight);
      box(g, 0, 0.17, -0.16, 0.1, 0.06, 0.1, dark);
    }
    if (index === 1) {
      cyl(g, 0, -0.1, -0.65, 0.075, 0.42, 0x42523b).rotation.x = Math.PI / 2;
    }
    if (index === 2 || index === 3) {
      box(g, 0.2, -0.1, -0.2, 0.24, 0.28, 0.32, 0x82794b);
      for (let j = 0; j < 6; j++)
        box(g, 0.14 + j * 0.028, -0.04, -0.18, 0.02, 0.06, 0.13, 0xc3a358);
    }
  }
  const socket = new T.Group();
  socket.name = 'muzzle';
  socket.position.set(muzzle.x, muzzle.y, muzzle.z);
  g.add(socket);
  const flash = new T.Group();
  flash.name = 'muzzleFlash';
  socket.add(flash);
  flash.visible = false;
  const coreMat = new T.MeshBasicMaterial({
    color: 0xffefb0,
    transparent: true,
    opacity: 0.95,
    blending: T.AdditiveBlending,
    depthWrite: false,
  });
  coreMat.userData.owned = true;
  const flameMat = new T.MeshBasicMaterial({
    color: 0xffa12d,
    transparent: true,
    opacity: 0.85,
    blending: T.AdditiveBlending,
    depthWrite: false,
  });
  flameMat.userData.owned = true;
  const core = new T.Mesh(new T.SphereGeometry(0.1, 8, 6), coreMat);
  core.scale.set(0.75, 0.75, 2.2);
  core.position.z = -0.1;
  flash.add(core);
  for (let n = 0; n < 5; n++) {
    const flame = new T.Mesh(new T.ConeGeometry(0.075, 0.34, 4), flameMat);
    flame.rotation.x = -Math.PI / 2;
    flame.position.set(
      Math.cos(n * 1.257) * 0.065,
      Math.sin(n * 1.257) * 0.065,
      -0.15,
    );
    flame.rotation.z = n * 1.257;
    flash.add(flame);
  }
  if (firstPerson) {
    const right = new T.Group();
    right.name = 'rightHand';
    g.add(right);
    cyl(right, 0.1, -0.22, -0.02, 0.1, 0.18, 0xf5c737).rotation.x = 1.4;
    box(right, 0.18, -0.34, 0.15, 0.24, 0.25, 0.45, 0x65744c);
    if (w.slot !== 1) {
      const left = new T.Group();
      left.name = 'leftHand';
      g.add(left);
      cyl(left, -0.1, -0.17, -0.53, 0.1, 0.16, 0xf5c737).rotation.z = 1.1;
      box(left, -0.23, -0.27, -0.31, 0.22, 0.25, 0.5, 0x65744c).rotation.y =
        -0.45;
    }
    const copies = new Map<T.Material, T.Material>();
    g.traverse((o) => {
      if (o instanceof T.Mesh) {
        o.castShadow = false;
        o.receiveShadow = false;
        o.renderOrder = 1000;
        const original = o.material as T.Material;
        let copy = copies.get(original);
        if (!copy) {
          copy = original.clone();
          copy.depthTest = false;
          copy.depthWrite = false;
          copy.userData.owned = true;
          if ('fog' in copy) copy.fog = false;
          copies.set(original, copy);
        }
        o.material = copy;
      }
    });
  }
  return g;
}
export function setMuzzleFlash(
  model: T.Object3D,
  firing: number,
  time: number,
) {
  const flash = model.getObjectByName('muzzleFlash');
  if (flash) {
    flash.visible = firing > 0;
    flash.scale.setScalar(0.7 + Math.min(1, firing / 0.105) * 0.6);
    flash.rotation.z = Math.floor(time * 80) * 1.3;
  }
}
export function updateSoldier(model: T.Group, a: Actor) {
  model.visible = a.dead <= 0 && !a.vehicle;
  model.position.set(
    a.pos.x,
    a.pos.y + (!a.limbs[2] && !a.limbs[3] ? -0.6 : 0),
    a.pos.z,
  );
  model.rotation.set(0, a.yaw, 0);
  const rig = model.getObjectByName('weaponRig')!;
  if (model.userData.weapon !== a.weapon) {
    for (const child of [...rig.children]) {
      releaseGeometry(child);
      rig.remove(child);
    }
    rig.add(weaponModel(a.weapon));
    model.userData.weapon = a.weapon;
  }
  rig.rotation.x = a.pitch;
  setMuzzleFlash(rig, a.firing, a.walk);
  for (const [idx, name] of [
    'leftArm',
    'rightArm',
    'leftLeg',
    'rightLeg',
  ].entries()) {
    const limb = model.getObjectByName(name)!;
    limb.visible = a.limbs[idx];
    limb.rotation.x =
      idx >= 2
        ? Math.sin(a.walk * 2.2 + (idx % 2 ? Math.PI : 0)) * 0.35
        : 1.03 + a.pitch * 0.5;
    limb.rotation.z = idx === 0 ? 0.6 : idx === 1 ? -0.15 : 0;
  }
}
export function soldierModel(team: number): T.Group {
  const g = new T.Group(),
    color = team === 0 ? 0x607c52 : 0xbd6946,
    dark = team === 0 ? 0x394c3b : 0x593e33;
  brick(g, 0, 1.13, 0, 0.66, 0.64, 0.4, color, false);
  box(g, 0, 1.13, -0.23, 0.48, 0.42, 0.09, dark);
  for (const x of [-0.15, 0.15]) box(g, x, 1.1, -0.29, 0.18, 0.21, 0.07, color);
  cyl(g, 0, 1.65, 0, 0.245, 0.36, 0xf3c43b);
  cyl(g, 0, 1.92, 0, 0.26, 0.17, dark);
  cyl(g, 0, 2.02, 0, 0.12, 0.06, dark);
  for (const x of [-0.085, 0.085]) {
    const eye = box(g, x, 1.7, -0.241, 0.048, 0.046, 0.02, 0x1e211c);
    eye.rotation.y = x * 2;
  }
  box(g, 0, 1.58, -0.246, 0.12, 0.026, 0.02, 0x392c20);
  for (let i = 0; i < 4; i++) {
    const p = new T.Group();
    p.name = ['leftArm', 'rightArm', 'leftLeg', 'rightLeg'][i];
    p.position.set(
      (i % 2 ? 1 : -1) * (i < 2 ? 0.46 : 0.19),
      i < 2 ? 1.36 : 0.72,
      0,
    );
    if (i < 2) {
      box(p, 0, -0.2, 0, 0.22, 0.48, 0.25, color);
      const hand = cyl(p, 0, -0.48, -0.015, 0.12, 0.17, 0xf3c43b);
      hand.rotation.x = Math.PI / 2;
    } else {
      brick(p, 0, -0.29, 0, 0.3, 0.58, 0.33, dark, false);
      box(p, 0, -0.61, -0.05, 0.31, 0.14, 0.46, dark);
    }
    g.add(p);
  }
  const rig = new T.Group();
  rig.name = 'weaponRig';
  rig.position.set(HELD_WEAPON.x, HELD_WEAPON.y, HELD_WEAPON.z);
  rig.scale.setScalar(HELD_WEAPON.scale);
  rig.add(weaponModel(0));
  g.add(rig);
  g.userData.weapon = 0;
  for (const name of ['leftArm', 'rightArm'])
    g.getObjectByName(name)!.rotation.x = 1.03;
  return g;
}
export function humveeModel(team: number, wreck = false): T.Group {
  const g = new T.Group(),
    paint = wreck ? 0x666054 : team === 0 ? 0xa99864 : 0x6b7655;
  brick(g, 0, 0.65, 0, 2.25, 0.45, 4.3, paint);
  box(g, 0, 1.02, 0.8, 2.1, 0.5, 2.3, paint);
  brick(g, 0, 1.2, -1.35, 2.1, 0.5, 1.4, wreck ? 0x2d2b28 : paint);
  brick(g, 0, 2, 0.25, 2.15, 0.18, 2.45, paint);
  for (const x of [-1, 1]) {
    for (const z of [-0.83, 1.34]) box(g, x, 1.65, z, 0.13, 0.7, 0.13, paint);
    box(g, x, 1.43, 0.25, 0.12, 0.55, 2.3, paint);
    for (const z of [-1.3, 1.35]) {
      if (wreck && x === 1 && z === -1.3) continue;
      const wheel = cyl(g, x * 1.17, 0.52, z, 0.54, 0.33, 0x252729, 16);
      wheel.rotation.z = Math.PI / 2;
      wheel.name = 'wheel';
      cyl(g, x * 1.35, 0.52, z, 0.26, 0.02, 0x726c5b).rotation.z = Math.PI / 2;
    }
  }
  box(g, 0, 1.68, -0.83, 1.76, 0.5, 0.025, 0x608182);
  box(g, 0, 0.77, -2.2, 2.3, 0.18, 0.2, 0x34393a);
  for (const x of [-0.77, 0.77])
    box(g, x, 1.05, -2.07, 0.3, 0.21, 0.04, 0xf5dda2);
  for (let i = 0; i < 7; i++)
    box(g, (i - 3) * 0.14, 1.02, -2.09, 0.055, 0.22, 0.03, 0x22262a);
  cyl(g, 0, 2.15, 0.1, 0.48, 0.17, paint);
  const turret = new T.Group();
  turret.name = 'turret';
  turret.position.set(TURRET_WEAPON.x, TURRET_WEAPON.y, TURRET_WEAPON.z);
  const mg = weaponModel(3);
  mg.scale.setScalar(TURRET_WEAPON.scale);
  turret.add(mg);
  g.add(turret);
  if (wreck) {
    box(g, -0.25, 1.52, -1.42, 1.8, 0.12, 1.4, paint).rotation.z = -0.55;
    for (let i = 0; i < 4; i++)
      brick(g, 0.4 + i * 0.2, 0.13, -2.7, 0.5, 0.25, 0.4, 0x444039);
  }
  return g;
}
export function makeMap(id: MapId): T.Group {
  const w = createWorld(id),
    root = new T.Group();
  root.name = 'map';
  box(root, 0, -0.32, 0, 72, 0.64, 72, id === 'baghdad' ? 0xbaa078 : 0x334c59);
  // Thousands of molded studs share a single draw call.
  const studs = new T.InstancedMesh(
    studGeo,
    material(id === 'baghdad' ? 0xbda47e : 0x3f5964),
    72 * 72,
  );
  const mat = new T.Matrix4();
  for (let i = 0; i < 72; i++)
    for (let j = 0; j < 72; j++)
      studs.setMatrixAt(
        i * 72 + j,
        mat.makeTranslation(i - 35.5, 0.025, j - 35.5),
      );
  studs.receiveShadow = true;
  root.add(studs);
  if (id === 'baghdad') {
    box(root, 0, 0.011, 0, 10, 0.025, 70, 0x797366);
    for (let z = -30; z <= 30; z += 7)
      box(root, 0, 0.035, z, 0.14, 0.02, 2.2, 0xd8c898);
    for (const x of [-5.3, 5.3])
      brick(root, x, 0.12, 0, 0.45, 0.25, 69, 0xceba92, false);
  } else {
    for (const x of [-7, 7]) {
      box(root, x, 0.02, 0, 1.3, 0.08, 68, 0x678d95);
      for (let z = -31; z < 33; z += 2)
        box(root, x, 0.08, z, 1.4, 0.06, 0.1, 0xc2ccbd);
    }
    for (const s of [-1, 1]) {
      brick(root, s * 35, 0.7, 0, 0.45, 1.4, 70, 0x34404b, false);
      brick(root, 0, 0.7, s * 35, 70, 1.4, 0.45, 0x34404b, false);
    }
  }
  for (const s of w.solids) {
    box(root, s.x, s.h / 2, s.z, s.w, s.h, s.d, s.color);
    brick(root, s.x, s.h, s.z, s.w + 0.25, 0.24, s.d + 0.25, s.color);
    if (s.kind === 'building') {
      // Exposed brick courses, inset dark windows and roof parapets.
      for (let y = 0.6; y < s.h; y += 0.65)
        for (const z of [-1, 1])
          box(
            root,
            s.x,
            y,
            s.z + z * (s.d / 2 + 0.012),
            s.w,
            0.025,
            0.027,
            0x9c7c50,
          );
      for (let y = 2; y < s.h - 0.7; y += 2.5)
        for (let x = -s.w / 2 + 1.5; x < s.w / 2 - 0.5; x += 2.2)
          for (const z of [-1, 1]) {
            box(
              root,
              s.x + x,
              y,
              s.z + z * (s.d / 2 + 0.04),
              0.9,
              1.3,
              0.08,
              id === 'baghdad' ? 0x3e514c : 0x739b9f,
            );
            box(
              root,
              s.x + x,
              y - 0.65,
              s.z + z * (s.d / 2 + 0.18),
              1.18,
              0.13,
              0.37,
              0xdfc795,
            );
          }
      for (const a of [-1, 1]) {
        brick(
          root,
          s.x + (a * s.w) / 2,
          s.h + 0.44,
          s.z,
          0.3,
          0.7,
          s.d,
          s.color,
        );
        brick(
          root,
          s.x,
          s.h + 0.44,
          s.z + (a * s.d) / 2,
          s.w,
          0.7,
          0.3,
          s.color,
        );
      }
      if (id === 'baghdad') {
        cyl(root, s.x + 1, s.h + 0.85, s.z, 0.65, 1.4, 0x706c56);
        box(root, s.x - 1.2, s.h + 0.4, s.z, 1.4, 0.55, 1.1, 0xcec2a1);
      }
    } else if (s.kind === 'container') {
      for (let z = -s.d / 2 + 0.3; z < s.d / 2; z += 0.5)
        for (const x of [-1, 1])
          box(
            root,
            s.x + x * (s.w / 2 + 0.025),
            s.h / 2,
            s.z + z,
            0.08,
            s.h - 0.2,
            0.07,
            s.color,
          );
    } else if (s.kind === 'reactor') {
      const glow = new T.MeshStandardMaterial({
        color: 0x69e3cf,
        emissive: 0x25cbb6,
        emissiveIntensity: 1.4,
        roughness: 0.22,
      });
      for (let y = 1; y < 7.5; y += 1.4) {
        const ring = new T.Mesh(new T.TorusGeometry(4, 0.12, 8, 32), glow);
        ring.rotation.x = Math.PI / 2;
        ring.position.set(0, y, 0);
        root.add(ring);
      }
      const light = new T.PointLight(0x47ffcc, 40, 20);
      light.position.set(0, 8, 0);
      root.add(light);
    }
  }
  if (id === 'baghdad') {
    for (const [x, z] of [
      [-16, -18],
      [16, 22],
      [-16, 23],
      [16, -24],
    ]) {
      const trunk = cyl(root, x, 2.5, z, 0.22, 5, 0x8b6c40, 8);
      for (let i = 0; i < 7; i++) {
        const leaf = box(root, 0, 0, 0, 0.6, 0.14, 3.8, 0x526b37);
        leaf.position.set(x + Math.sin(i) * 1.3, 5.1, z + Math.cos(i) * 1.3);
        leaf.rotation.set(0.23, i, 0);
      }
      trunk.name = 'palm';
    }
    const dome = new T.Mesh(
      new T.SphereGeometry(4, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2),
      material(0x7faaaa),
    );
    dome.position.set(-25, 10.4, 13);
    root.add(dome);
    cyl(root, -30, 8, 9, 0.8, 16, 0xd6ba85);
    cyl(root, -30, 16.4, 9, 1.1, 0.45, 0xd6ba85);
    for (const [x, z] of [
      [-9, -18],
      [12, 23],
    ]) {
      const burned = humveeModel(0, true);
      burned.position.set(x, 0, z);
      burned.rotation.y = 1.1;
      root.add(burned);
    }
  } else {
    for (const x of [-26, 26]) {
      box(root, x, 8, 24, 0.8, 16, 0.8, 0xc18b3a);
      box(root, x - 5, 15.5, 24, 12, 0.7, 0.7, 0xe8aa42);
      box(root, x - 8, 12, 24, 0.05, 7, 0.05, 0x949c9e);
    }
    for (let i = 0; i < 10; i++) {
      const cloud = new T.Mesh(
        new T.SphereGeometry(6, 8, 6),
        material(0xafc1cd),
      );
      cloud.position.set(
        Math.sin(i * 3) * 70,
        -11 - (i % 3),
        Math.cos(i * 3) * 70,
      );
      cloud.scale.set(2.5, 0.6, 1);
      root.add(cloud);
    }
  }
  return root;
}
export function releaseGeometry(object: T.Object3D) {
  const seen = new Set<T.BufferGeometry>();
  object.traverse((o) => {
    if (o instanceof T.Mesh && o.geometry !== boxGeo && o.geometry !== studGeo)
      seen.add(o.geometry);
    if (o instanceof T.InstancedMesh) o.dispose();
  });
  for (const geo of seen) geo.dispose();
  const owned = new Set<T.Material>();
  object.traverse((o) => {
    if (o instanceof T.Mesh) {
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) if (m.userData.owned) owned.add(m);
    }
  });
  for (const m of owned) m.dispose();
}
