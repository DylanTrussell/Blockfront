import * as T from 'three';
import type { Vec } from './world';
export const TRACER_LIFETIME = 0.105;
export function tracer(from: Vec, to: Vec, progress = 0): T.Line {
  const line = new T.Line(
    new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3()]),
    new T.LineBasicMaterial({
      color: 0xffc16c,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
    }),
  );
  line.userData.from = { ...from };
  line.userData.to = { ...to };
  updateTracer(line, progress);
  return line;
}
export function updateTracer(line: T.Line, progress: number) {
  const from = line.userData.from as Vec,
    to = line.userData.to as Vec,
    dx = to.x - from.x,
    dy = to.y - from.y,
    dz = to.z - from.z,
    length = Math.hypot(dx, dy, dz);
  const head = Math.min(1, Math.max(0, progress)),
    tail = Math.max(0, head - Math.min(2.4, length) / Math.max(length, 0.001));
  const positions = line.geometry.getAttribute('position') as T.BufferAttribute;
  positions.setXYZ(
    0,
    from.x + dx * tail,
    from.y + dy * tail,
    from.z + dz * tail,
  );
  positions.setXYZ(
    1,
    from.x + dx * head,
    from.y + dy * head,
    from.z + dz * head,
  );
  positions.needsUpdate = true;
  line.geometry.computeBoundingSphere();
}
