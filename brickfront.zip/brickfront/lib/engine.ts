import * as T from 'three';
import {
  makeMap,
  humveeModel,
  soldierModel,
  weaponModel,
  box,
  brick,
  material,
  releaseGeometry,
  updateSoldier,
  setMuzzleFlash,
} from './geometry';
import { type MapId, type Vec, v, distance, clamp } from './world';
import {
  Simulation,
  ReplayBuffer,
  replayFrame,
  emptyInput,
  eye,
  SELECTABLE,
  type State,
  type Actor,
  type HistoryFrame,
  type Input,
} from './simulation';
import { Room, type RoomInfo } from './network';
import { AudioFX } from './audio';
import {
  WEAPONS,
  FIRST_PERSON_WEAPON,
  DEFAULT_RULES,
  type MatchRules,
} from './weapons';
import { tracer, updateTracer, TRACER_LIFETIME } from './combat-effects';
export type EngineHUD = {
  state: State;
  ids: string[];
  paused: boolean;
  playing: boolean;
  room: RoomInfo;
  hit: boolean;
  replays: {
    id: string;
    killer: string;
    elapsed: number;
    weapon?: number;
    ads?: boolean;
  }[];
  fps: number;
};
export const viewports = (width: number, height: number, split: boolean) =>
  split
    ? [
        { x: 0, y: 0, w: width / 2, h: height },
        { x: width / 2, y: 0, w: width / 2, h: height },
      ]
    : [{ x: 0, y: 0, w: width, h: height }];
const P1 = {
  forward: 'KeyW',
  back: 'KeyS',
  left: 'KeyA',
  right: 'KeyD',
  jump: 'Space',
  reload: 'KeyR',
  use: 'KeyE',
  turret: 'KeyF',
  patch: 'KeyQ',
  grenade: 'KeyG',
  pickup: 'KeyX',
};
export const P2 = {
  forward: 'ArrowUp',
  back: 'ArrowDown',
  left: 'ArrowLeft',
  right: 'ArrowRight',
  jump: 'KeyP',
  reload: 'KeyO',
  use: 'KeyU',
  turret: 'KeyY',
  patch: 'KeyH',
  grenade: 'KeyN',
  pickup: 'KeyB',
};
export class Engine {
  renderer: T.WebGLRenderer;
  scene = new T.Scene();
  camera = new T.PerspectiveCamera(48, 1, 0.05, 250);
  group = new T.Group();
  demo = new T.Group();
  dynamic = new T.Group();
  frame = 0;
  map: MapId = 'baghdad';
  disposed = false;
  sim = new Simulation('baghdad');
  state: State = this.sim.state;
  playing = false;
  paused = false;
  mode = 'solo';
  ids = ['you'];
  keys = new Set<string>();
  pressed = new Set<string>();
  mouse = { shoot: false, ads: false };
  yaw = [0, Math.PI];
  pitch = [0, 0];
  room: Room;
  audio = new AudioFX();
  actors = new Map<string, T.Group>();
  cars = new Map<string, T.Group>();
  rockets = new Map<number, T.Mesh>();
  patchModels: T.Group[] = [];
  pickupModels = new Map<number, T.Group>();
  gun = new T.Group();
  gunIndex = -1;
  size = { w: 0, h: 0 };
  last = performance.now();
  uiTime = 0;
  netTime = 0;
  accumulator = 0;
  history = new ReplayBuffer();
  replays = new Map<
    string,
    { frames: HistoryFrame[]; start: number; killer: string }
  >();
  lastEvent = 0;
  hitUntil = 0;
  particles: { mesh: T.Mesh; vel: T.Vector3; life: number; spin: number }[] =
    [];
  tracers: { line: T.Line; life: number }[] = [];
  fps = 60;
  onHUD: (h: EngineHUD) => void = () => {};
  onRoom: (i: RoomInfo) => void = () => {};
  onPlaying: (v: boolean) => void = () => {};
  onError: (message: string) => void = () => {};
  touch: Partial<Input> = {};
  abort = new AbortController();
  constructor(public container: HTMLElement) {
    this.renderer = new T.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = T.PCFShadowMap;
    this.renderer.outputColorSpace = T.SRGBColorSpace;
    this.renderer.toneMapping = T.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;
    container.appendChild(this.renderer.domElement);
    this.scene.add(new T.HemisphereLight(0xe0efe7, 0x82724f, 2.6));
    const sun = new T.DirectionalLight(0xffe2a3, 3.6);
    sun.position.set(-20, 40, 25);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, {
      left: -40,
      right: 40,
      top: 40,
      bottom: -40,
      near: 1,
      far: 130,
    });
    sun.shadow.normalBias = 0.06;
    this.scene.add(sun);
    this.scene.add(this.camera);
    this.scene.add(this.dynamic);
    this.scene.add(this.demo);
    this.camera.add(this.gun);
    this.room = new Room(
      (info) => {
        this.onRoom(info);
      },
      (id) => {
        const team = this.sim.state.actors.filter((a) => !a.bot).length % 2;
        const bot = this.sim.state.actors.find((a) => a.bot && a.team === team);
        if (bot) this.sim.removePlayer(bot.id);
        this.sim.addPlayer(
          id,
          'Player ' + (this.sim.state.actors.filter((a) => !a.bot).length + 1),
          team,
        );
        return id;
      },
      (id) => {
        this.sim.removePlayer(id);
        this.sim.fillBots();
      },
      (id, input) => this.sim.setInput(id, input),
      (state, id) => {
        if (state.map !== this.map) this.setMap(state.map);
        this.state = state;
        this.ids = [id];
        const a = state.actors.find((a) => a.id === id);
        if (a && this.history.frames.length === 0) {
          this.yaw[0] = a.yaw;
          this.pitch[0] = a.pitch;
        }
        this.processState();
      },
    );
    this.setMap('baghdad');
    this.bind();
    this.loop();
  }
  setMap(id: MapId) {
    if (this.map === id && this.group.children.length) return;
    this.map = id;
    this.scene.remove(this.group);
    releaseGeometry(this.group);
    this.group = makeMap(id);
    this.scene.add(this.group);
    this.scene.background = new T.Color(id === 'baghdad' ? 0xc3c4ad : 0x7b9eaf);
    this.scene.fog = new T.Fog(id === 'baghdad' ? 0xc3c4ad : 0x7b9eaf, 48, 145);
    releaseGeometry(this.demo);
    this.demo.clear();
    const h = humveeModel(0, true);
    h.position.set(2, 0, -4);
    this.demo.add(h);
    for (let i = 0; i < 3; i++) {
      const s = soldierModel(i === 2 ? 1 : 0);
      s.position.set(4 + i * 1.9, 0, 8 - i * 3);
      s.rotation.y = 0.5;
      this.demo.add(s);
    }
    for (const p of this.patchModels) {
      this.scene.remove(p);
      releaseGeometry(p);
    }
    this.patchModels = [];
    for (const point of new Simulation(id).world.patches) {
      const g = new T.Group();
      brick(g, 0, 0.3, 0, 0.8, 0.5, 0.6, 0x629451);
      box(g, 0, 0.565, 0, 0.45, 0.025, 0.13, 0xeef5ce);
      box(g, 0, 0.566, 0, 0.13, 0.025, 0.4, 0xeef5ce);
      g.position.set(point.x, 0, point.z);
      this.scene.add(g);
      this.patchModels.push(g);
    }
  }
  bind() {
    const opts = { signal: this.abort.signal };
    window.addEventListener(
      'keydown',
      (e) => {
        if (!this.playing) return;
        if (e.code === 'Escape') {
          this.pause();
          return;
        }
        if (this.paused) return;
        if (
          [
            'Space',
            'ArrowUp',
            'ArrowDown',
            'ArrowLeft',
            'ArrowRight',
            'Tab',
          ].includes(e.code)
        )
          e.preventDefault();
        if (!this.keys.has(e.code)) this.pressed.add(e.code);
        this.keys.add(e.code);
        if (e.code.startsWith('Digit')) {
          const n = Number(e.code.slice(5)) - 1;
          const a = this.state.actors.find((a) => a.id === this.ids[0]);
          const weapon = a?.inventory[n];
          if (typeof weapon === 'number') this.touch.weapon = weapon;
        }
      },
      opts,
    );
    window.addEventListener('keyup', (e) => this.keys.delete(e.code), opts);
    window.addEventListener(
      'blur',
      () => {
        this.keys.clear();
        this.pressed.clear();
        this.mouse.shoot = false;
        if (this.playing) this.pause();
      },
      opts,
    );
    document.addEventListener(
      'pointerlockchange',
      () => {
        if (this.playing && !document.pointerLockElement && !this.isTouch())
          this.pause();
      },
      opts,
    );
    window.addEventListener(
      'mousemove',
      (e) => {
        if (!this.playing || this.paused || !document.pointerLockElement)
          return;
        const sens = this.mouse.ads ? 0.0012 : 0.0022;
        this.yaw[0] -= e.movementX * sens;
        this.pitch[0] = clamp(this.pitch[0] - e.movementY * sens, -1.35, 1.35);
      },
      opts,
    );
    this.renderer.domElement.addEventListener(
      'mousedown',
      (e) => {
        if (!this.playing || this.paused) return;
        if (e.button === 0) this.mouse.shoot = true;
        if (e.button === 2) this.mouse.ads = true;
      },
      opts,
    );
    window.addEventListener(
      'mouseup',
      (e) => {
        if (e.button === 0) this.mouse.shoot = false;
        if (e.button === 2) this.mouse.ads = false;
      },
      opts,
    );
    this.renderer.domElement.addEventListener(
      'contextmenu',
      (e) => e.preventDefault(),
      opts,
    );
    this.renderer.domElement.addEventListener(
      'wheel',
      (e) => {
        if (!this.playing || this.paused) return;
        e.preventDefault();
        const a = this.state.actors.find((a) => a.id === this.ids[0]);
        if (a) {
          const inventory = a.inventory.filter((w): w is number => w !== null);
          this.touch.weapon =
            inventory[
              (inventory.indexOf(a.weapon) +
                (e.deltaY > 0 ? 1 : inventory.length - 1)) %
                inventory.length
            ];
        }
      },
      { ...opts, passive: false },
    );
  }
  isTouch() {
    return window.matchMedia('(pointer: coarse)').matches;
  }
  lock() {
    if (!this.isTouch())
      try {
        const result = this.renderer.domElement.requestPointerLock();
        result?.catch(() => {
          this.pause();
          this.onError('Click Resume to capture the mouse.');
        });
      } catch {
        this.pause();
      }
    this.audio.unlock();
  }
  start(
    mode: string,
    weapon: number,
    code = '',
    rules: MatchRules = DEFAULT_RULES,
  ) {
    this.room.close();
    this.mode = mode;
    this.sim = new Simulation(this.map, Math.random, rules);
    this.sim.addPlayer('you', 'You', 0, false, weapon);
    this.ids = ['you'];
    if (mode === 'split') {
      this.sim.addPlayer('player2', 'Player 2', 1, false, weapon);
      this.ids.push('player2');
    }
    this.sim.fillBots();
    this.state = this.sim.state;
    this.lastEvent = 0;
    this.history = new ReplayBuffer();
    this.replays.clear();
    this.yaw = [0, Math.PI];
    this.pitch = [0, 0];
    this.keys.clear();
    this.pressed.clear();
    this.touch = {};
    this.paused = false;
    this.playing = true;
    this.onPlaying(true);
    this.clearFX();
    this.lock();
    if (mode === 'online') {
      if (code) {
        if (!this.room.join(code)) {
          this.leave();
          return;
        }
      } else void this.room.host();
    }
    this.emit();
  }
  pause() {
    if (!this.playing) return;
    this.paused = true;
    this.keys.clear();
    this.pressed.clear();
    this.mouse = { shoot: false, ads: false };
    this.touch = {};
    document.exitPointerLock?.();
    this.emit();
  }
  resume() {
    this.paused = false;
    this.lock();
    this.emit();
  }
  leave() {
    this.playing = false;
    this.paused = false;
    this.room.close();
    document.exitPointerLock?.();
    releaseGeometry(this.dynamic);
    this.dynamic.clear();
    this.actors.clear();
    this.cars.clear();
    this.rockets.clear();
    this.pickupModels.clear();
    this.clearFX();
    this.onPlaying(false);
    this.emit();
  }
  clearFX() {
    for (const p of this.particles) {
      this.scene.remove(p.mesh);
      p.mesh.geometry.dispose();
    }
    this.particles = [];
    for (const t of this.tracers) {
      this.scene.remove(t.line);
      t.line.geometry.dispose();
      (t.line.material as T.Material).dispose();
    }
    this.tracers = [];
  }
  input(index: number, dt: number): Input {
    const a = this.state.actors.find((a) => a.id === this.ids[index]);
    const i = emptyInput();
    i.yaw = this.yaw[index];
    i.pitch = this.pitch[index];
    if (this.paused) return i;
    const k = index === 0 ? P1 : P2;
    i.forward =
      Number(this.keys.has(k.forward)) - Number(this.keys.has(k.back));
    i.strafe = Number(this.keys.has(k.right)) - Number(this.keys.has(k.left));
    i.sprint = this.keys.has(index ? 'ShiftRight' : 'ShiftLeft');
    for (const key of [
      'jump',
      'reload',
      'use',
      'turret',
      'patch',
      'grenade',
      'pickup',
    ] as const)
      i[key] = this.pressed.has(k[key]);
    if (index === 0) {
      i.shoot = this.mouse.shoot;
      i.ads = this.mouse.ads;
      Object.assign(i, this.touch);
    } else {
      this.yaw[1] +=
        (Number(this.keys.has('KeyJ')) - Number(this.keys.has('KeyL'))) *
        dt *
        2;
      this.pitch[1] = clamp(
        this.pitch[1] +
          (Number(this.keys.has('KeyI')) - Number(this.keys.has('KeyK'))) *
            dt *
            1.5,
        -1.3,
        1.3,
      );
      i.yaw = this.yaw[1];
      i.pitch = this.pitch[1];
      i.shoot = this.keys.has('Enter');
      i.ads = this.keys.has('ShiftRight');
      if (this.pressed.has('Backslash') && a) {
        const inventory = a.inventory.filter((w): w is number => w !== null);
        i.weapon =
          inventory[(inventory.indexOf(a.weapon) + 1) % inventory.length];
      }
      const pad = Array.from(navigator.getGamepads?.() || []).find(Boolean);
      if (pad) {
        const axis = (n: number) =>
          Math.abs(pad.axes[n] || 0) > 0.16 ? pad.axes[n] : 0;
        i.forward = -axis(1);
        i.strafe = axis(0);
        this.yaw[1] -= axis(2) * dt * 2.4;
        this.pitch[1] = clamp(this.pitch[1] - axis(3) * dt * 1.8, -1.3, 1.3);
        i.yaw = this.yaw[1];
        i.pitch = this.pitch[1];
        i.shoot = !!pad.buttons[7]?.pressed;
        i.ads = !!pad.buttons[6]?.pressed;
        i.jump = !!pad.buttons[0]?.pressed;
        i.reload = !!pad.buttons[2]?.pressed;
      }
    }
    return i;
  }
  processState() {
    this.history.record(this.state);
    for (const e of this.state.events) {
      if (e.id <= this.lastEvent) continue;
      this.lastEvent = e.id;
      const local = this.state.actors.find((a) => a.id === this.ids[0]);
      if (local && ['shot', 'hit', 'explosion', 'patch'].includes(e.type))
        this.audio.play(e.type, distance(local.pos, e.pos), e.weapon);
      if (e.type === 'bleed') this.burst(e.pos, 0xc52823, 2, 0.12);
      if (e.type === 'hit') {
        this.burst(e.pos, 0xc52823, 5, 0.16);
        if (this.ids.includes(e.actor)) this.hitUntil = performance.now() + 150;
      }
      if (e.type === 'limb') this.burst(e.pos, 0xbc6148, 7, 0.25);
      if (e.type === 'death') {
        const victim = this.state.actors.find((a) => a.id === e.target);
        this.burst(e.pos, victim?.team === 0 ? 0x678151 : 0xb76942, 30, 0.25);
        this.burst(v(e.pos.x, e.pos.y + 0.5, e.pos.z), 0xeac02e, 8, 0.18);
        if (e.target && this.ids.includes(e.target)) {
          this.history.record(this.state, true);
          this.replays.set(e.target, {
            frames: this.history.clip(e.t),
            start: performance.now(),
            killer: e.actor,
          });
        }
      }
      if (e.type === 'explosion') {
        this.burst(e.pos, 0xd99339, 35, 0.3);
        this.burst(e.pos, 0x383a33, 25, 0.23);
      }
      if (e.type === 'shot' && e.end) {
        const line = tracer(e.pos, e.end);
        this.scene.add(line);
        this.tracers.push({ line, life: TRACER_LIFETIME });
      }
    }
  }
  burst(p: Vec, color: number, count: number, size: number) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= 180) {
        const old = this.particles.shift()!;
        this.scene.remove(old.mesh);
        old.mesh.geometry.dispose();
      }
      const mesh = new T.Mesh(
        new T.BoxGeometry(size, size * 0.65, size * 1.3),
        material(color),
      );
      mesh.position.set(p.x, p.y, p.z);
      mesh.castShadow = false;
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        vel: new T.Vector3(
          (Math.random() - 0.5) * 7,
          Math.random() * 6 + 1,
          (Math.random() - 0.5) * 7,
        ),
        life: 2 + Math.random(),
        spin: Math.random() * 9,
      });
    }
  }
  sync(state: State | HistoryFrame) {
    for (const model of this.actors.values()) model.visible = false;
    for (const a of state.actors) {
      let model = this.actors.get(a.id);
      if (!model) {
        model = soldierModel(a.team);
        this.actors.set(a.id, model);
        this.dynamic.add(model);
      }
      updateSoldier(model, a);
    }
    for (const c of state.vehicles) {
      let model = this.cars.get(c.id);
      if (!model) {
        model = humveeModel(c.team, c.fixed);
        this.cars.set(c.id, model);
        this.dynamic.add(model);
      }
      model.visible = c.dead <= 0;
      model.position.set(c.pos.x, 0, c.pos.z);
      model.rotation.y = c.yaw;
      const turret = model.getObjectByName('turret');
      if (turret) {
        turret.rotation.set(c.turretPitch, c.turretYaw - c.yaw, 0, 'YXZ');
        setMuzzleFlash(
          turret,
          state.actors.find((a) => a.id === c.gunner)?.firing || 0,
          state.time,
        );
      }
    }
  }
  syncPickups() {
    const live = new Set(this.state.pickups.map((p) => p.id));
    for (const [id, g] of this.pickupModels)
      if (!live.has(id)) {
        this.dynamic.remove(g);
        releaseGeometry(g);
        this.pickupModels.delete(id);
      }
    for (const p of this.state.pickups) {
      let model = this.pickupModels.get(p.id);
      if (!model) {
        model = new T.Group();
        const color = WEAPONS[p.weapon].sniper
          ? 0x91bacb
          : WEAPONS[p.weapon].rocket
            ? 0xe7aa58
            : 0xc3e47c;
        brick(model, 0, 0.06, 0, 0.8, 0.12, 0.8, color);
        const gun = weaponModel(p.weapon);
        gun.name = 'pickupWeapon';
        gun.position.set(0, 0.8, 0);
        gun.rotation.z = -0.12;
        model.add(gun);
        this.pickupModels.set(p.id, model);
        this.dynamic.add(model);
      }
      model.position.set(p.pos.x, p.pos.y, p.pos.z);
      const gun = model.getObjectByName('pickupWeapon')!;
      gun.visible = p.cooldown === 0;
      gun.rotation.y = this.state.time * 0.65;
      gun.position.y = 0.75 + Math.sin(this.state.time * 2 + p.id) * 0.08;
    }
  }
  renderView(id: string, index: number, dt: number) {
    const replay = this.replays.get(id),
      me = this.state.actors.find((a) => a.id === id);
    let a = me;
    let source: State | HistoryFrame = this.state;
    if (replay && me?.dead && replay.frames.length) {
      const elapsed = (performance.now() - replay.start) / 1000;
      source = replayFrame(replay.frames, Math.min(elapsed, 3.2)) || this.state;
      a =
        source.actors.find((a) => a.id === replay.killer) ||
        source.actors.find((a) => a.id === id);
    } else this.replays.delete(id);
    this.sync(source);
    if (!a) return;
    const own = this.actors.get(a.id);
    if (own) own.visible = false;
    const o = eye(a);
    if (a.seat === 'driver') {
      const car = source.vehicles.find((c) => c.id === a.vehicle);
      if (car) {
        o.x -= Math.sin(car.yaw) * 1.08;
        o.z -= Math.cos(car.yaw) * 1.08;
      }
    }
    this.camera.position.set(
      o.x,
      o.y + (a.dead ? 0 : Math.sin(a.walk * 3) * 0.022),
      o.z,
    );
    this.camera.rotation.set(a.pitch, a.yaw, 0, 'YXZ');
    const fov = a.ads ? (WEAPONS[a.weapon].sniper ? 26 : 48) : 76;
    this.camera.fov += (fov - this.camera.fov) * Math.min(1, dt * 16);
    this.camera.updateProjectionMatrix();
    const wi = a.seat === 'turret' ? 3 : a.weapon;
    if (wi !== this.gunIndex) {
      this.camera.remove(this.gun);
      releaseGeometry(this.gun);
      this.gun = weaponModel(wi, true);
      this.camera.add(this.gun);
      this.gunIndex = wi;
      this.gun.traverse((o) => {
        if (o instanceof T.Mesh) {
          o.castShadow = false;
          o.receiveShadow = false;
        }
      });
    }
    this.gun.visible = a.seat !== 'driver' && !(a.ads && WEAPONS[wi].sniper);
    this.gun.position.set(
      a.ads ? 0 : FIRST_PERSON_WEAPON.x,
      a.ads ? -0.235 : FIRST_PERSON_WEAPON.y,
      FIRST_PERSON_WEAPON.z + Math.sin(a.firing * 35) * 0.045,
    );
    this.gun.scale.setScalar(FIRST_PERSON_WEAPON.scale);
    this.gun.rotation.set(
      a.reload > 0 ? -0.65 : 0,
      0,
      a.reload > 0 ? -0.4 : Math.sin(a.walk * 2) * 0.012,
    );
    setMuzzleFlash(this.gun, a.firing, source.time);
    const left = this.gun.getObjectByName('leftHand'),
      right = this.gun.getObjectByName('rightHand');
    if (left) left.visible = a.limbs[0];
    if (right) right.visible = a.limbs[1];
    if (a.seat === 'turret') {
      const turret = this.cars.get(a.vehicle)?.getObjectByName('turret');
      if (turret) turret.visible = false;
    }
    const replayTracers: T.Line[] = [];
    const currentEffects = [
      ...this.particles.map((p) => p.mesh),
      ...this.tracers.map((t) => t.line),
      ...this.rockets.values(),
      ...this.pickupModels.values(),
    ];
    if (source !== this.state) {
      for (const object of currentEffects) object.visible = false;
      for (const e of source.events) {
        if (e.type === 'shot' && e.end && source.time - e.t < TRACER_LIFETIME) {
          const line = tracer(
            e.pos,
            e.end,
            Math.min(1, (source.time - e.t) / TRACER_LIFETIME),
          );
          this.scene.add(line);
          replayTracers.push(line);
        }
      }
    }
    this.renderer.render(this.scene, this.camera);
    for (const object of currentEffects) object.visible = true;
    for (const line of replayTracers) {
      this.scene.remove(line);
      line.geometry.dispose();
      (line.material as T.Material).dispose();
    }
    for (const car of this.cars.values()) {
      const turret = car.getObjectByName('turret');
      if (turret) turret.visible = true;
    }
  }
  emit() {
    this.onHUD({
      state: this.state,
      ids: [...this.ids],
      paused: this.paused,
      playing: this.playing,
      room: { ...this.room.info },
      hit: performance.now() < this.hitUntil,
      replays: Array.from(this.replays, ([id, r]) => {
        const elapsed = (performance.now() - r.start) / 1000,
          actor = replayFrame(r.frames, Math.min(elapsed, 3.2))?.actors.find(
            (a) => a.id === r.killer,
          );
        return {
          id,
          killer:
            this.state.actors.find((a) => a.id === r.killer)?.name ||
            'Crossfire',
          elapsed,
          weapon: actor?.weapon,
          ads: actor?.ads,
        };
      }),
      fps: Math.round(this.fps),
    });
  }
  loop = () => {
    if (this.disposed) return;
    this.frame = requestAnimationFrame(this.loop);
    const now = performance.now(),
      dt = Math.min((now - this.last) / 1000, 0.1);
    this.last = now;
    this.fps = this.fps * 0.95 + (1 / Math.max(0.001, dt)) * 0.05;
    const width = this.container.clientWidth,
      height = this.container.clientHeight;
    if (width !== this.size.w || height !== this.size.h) {
      this.size = { w: width, h: height };
      this.renderer.setSize(width, height, false);
    }
    this.demo.visible = !this.playing;
    this.dynamic.visible = this.playing;
    for (let j = 0; j < this.patchModels.length; j++) {
      const p = this.patchModels[j];
      p.visible = !this.playing || this.state.patches[j] === 0;
      p.rotation.y = now * 0.0006;
      p.position.y = Math.sin(now * 0.002 + j) * 0.08;
    }
    if (this.playing) {
      const guest = this.room.info.role === 'guest';
      if (!this.paused || this.mode === 'online') {
        const inputs = this.ids.map((_, j) => this.input(j, dt));
        let consumed = guest;
        if (guest) {
          this.room.send(inputs[0]);
        } else {
          this.accumulator += dt;
          let first = true;
          while (this.accumulator >= 1 / 60) {
            consumed = true;
            for (let j = 0; j < this.ids.length; j++) {
              const input = { ...inputs[j] };
              if (!first)
                for (const key of [
                  'use',
                  'turret',
                  'patch',
                  'grenade',
                  'jump',
                  'pickup',
                ] as const)
                  input[key] = false;
              this.sim.setInput(this.ids[j], input);
            }
            this.sim.tick(1 / 60);
            this.accumulator -= 1 / 60;
            first = false;
          }
          this.state = this.sim.state;
          this.processState();
          this.netTime += dt;
          if (this.room.info.role === 'host' && this.netTime > 0.05) {
            this.netTime = 0;
            this.room.broadcast(this.state);
          }
        }
        if (consumed) {
          this.pressed.clear();
          for (const key of [
            'use',
            'turret',
            'patch',
            'grenade',
            'jump',
            'reload',
            'pickup',
          ] as const)
            delete this.touch[key];
          delete this.touch.weapon;
        }
      }
      for (const p of [...this.particles]) {
        p.life -= dt;
        p.vel.y -= 10 * dt;
        p.mesh.position.addScaledVector(p.vel, dt);
        p.mesh.rotation.x += p.spin * dt;
        p.mesh.rotation.z += dt * 2;
        if (p.mesh.position.y < 0.1) {
          p.mesh.position.y = 0.1;
          p.vel.y = Math.abs(p.vel.y) * 0.3;
          p.vel.x *= 0.8;
          p.vel.z *= 0.8;
        }
        if (p.life <= 0) {
          this.scene.remove(p.mesh);
          p.mesh.geometry.dispose();
          this.particles.splice(this.particles.indexOf(p), 1);
        }
      }
      for (const t of [...this.tracers]) {
        t.life -= dt;
        updateTracer(t.line, 1 - t.life / TRACER_LIFETIME);
        if (t.life <= 0) {
          this.scene.remove(t.line);
          t.line.geometry.dispose();
          (t.line.material as T.Material).dispose();
          this.tracers.splice(this.tracers.indexOf(t), 1);
        }
      }
      const live = new Set(this.state.projectiles.map((p) => p.id));
      for (const [id, mesh] of this.rockets)
        if (!live.has(id)) {
          this.dynamic.remove(mesh);
          mesh.geometry.dispose();
          this.rockets.delete(id);
        }
      for (const p of this.state.projectiles) {
        let model = this.rockets.get(p.id);
        if (!model) {
          model = new T.Mesh(
            new T.SphereGeometry(0.12, 8, 6),
            material(0xf8b752),
          );
          this.dynamic.add(model);
          this.rockets.set(p.id, model);
        }
        model.position.set(p.pos.x, p.pos.y, p.pos.z);
      }
      this.syncPickups();
      this.renderer.setScissorTest(true);
      const views = viewports(width, height, this.mode === 'split');
      views.forEach((view, index) => {
        this.renderer.setViewport(view.x, view.y, view.w, view.h);
        this.renderer.setScissor(view.x, view.y, view.w, view.h);
        this.camera.aspect = view.w / view.h;
        this.renderView(this.ids[index], index, dt);
      });
      this.renderer.setScissorTest(false);
      this.uiTime += dt;
      if (this.uiTime > 0.09) {
        this.uiTime = 0;
        this.emit();
      }
      if (this.state.winner !== -1 && !this.paused) {
        this.pause();
      }
    } else {
      this.gun.visible = false;
      this.renderer.setViewport(0, 0, width, height);
      this.camera.aspect = width / height;
      this.camera.fov = 48;
      this.camera.updateProjectionMatrix();
      const t = window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ? 0
        : now * 0.00003;
      this.camera.position.set(26 + Math.sin(t) * 2, 19, 28);
      this.camera.lookAt(0, 1, -5);
      this.renderer.render(this.scene, this.camera);
    }
  };
  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frame);
    this.abort.abort();
    this.room.close();
    this.clearFX();
    this.audio.dispose();
    releaseGeometry(this.scene);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
