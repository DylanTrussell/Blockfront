import {
  type World,
  type Vec,
  v,
  distance,
  wallDistance,
  rayBox,
  clamp,
} from './world';
export type VisibleActor = {
  id: string;
  team: number;
  dead: number;
  pos: Vec;
  yaw: number;
  pitch: number;
  vehicle: string;
  limbs: boolean[];
};
export type VisionVehicle = { id: string; dead: number; pos: Vec };
export const VISION_RANGE = 36;
export const VISION_HALF_ANGLE = (55 * Math.PI) / 180;
export const REACTION_MIN = 0.4;
export const REACTION_MAX = 0.65;
export type Observation = {
  id: string;
  point: Vec;
  position: Vec;
  distance: number;
};
export type BotMemory = {
  target: string;
  lastSeen: Vec | null;
  lastSeenAt: number;
  readyAt: number;
  visible: boolean;
  patrol: Vec | null;
  patrolUntil: number;
  burstEnd: number;
  restUntil: number;
  aimOffset: number;
};
export const createBotMemory = (): BotMemory => ({
  target: '',
  lastSeen: null,
  lastSeenAt: -100,
  readyAt: Infinity,
  visible: false,
  patrol: null,
  patrolUntil: 0,
  burstEnd: 0,
  restUntil: 0,
  aimOffset: 0,
});
export function visionOrigin(a: VisibleActor): Vec {
  return v(
    a.pos.x,
    a.pos.y + (!a.limbs[2] && !a.limbs[3] ? 1.08 : 1.68),
    a.pos.z,
  );
}
/** Candidate positions are consulted only to decide whether the eyes can see them. */
export function observeEnemy(
  world: World,
  vehicles: VisionVehicle[],
  observer: VisibleActor,
  candidate: VisibleActor,
): Observation | null {
  if (
    candidate.id === observer.id ||
    candidate.team === observer.team ||
    candidate.dead > 0
  )
    return null;
  const o = visionOrigin(observer),
    dx = candidate.pos.x - o.x,
    dz = candidate.pos.z - o.z;
  const horizontal = Math.hypot(dx, dz);
  if (horizontal > VISION_RANGE) return null;
  const heading = Math.atan2(-dx, -dz),
    angle = Math.atan2(
      Math.sin(heading - observer.yaw),
      Math.cos(heading - observer.yaw),
    );
  if (Math.abs(angle) > VISION_HALF_ANGLE) return null;
  const low = !candidate.limbs[2] && !candidate.limbs[3] ? 0.6 : 0;
  for (const height of [1.1, 1.65]) {
    const point = v(
        candidate.pos.x,
        candidate.pos.y + height - low,
        candidate.pos.z,
      ),
      dist = distance(o, point);
    if (dist < 0.01) continue;
    const dir = v(
      (point.x - o.x) / dist,
      (point.y - o.y) / dist,
      (point.z - o.z) / dist,
    );
    if (Math.abs(Math.asin(clamp(dir.y, -1, 1)) - observer.pitch) > 0.9)
      continue;
    let obstacle = wallDistance(world, o, dir);
    for (const c of vehicles)
      if (!c.dead && c.id !== observer.vehicle)
        obstacle = Math.min(
          obstacle,
          rayBox(
            o,
            dir,
            v(c.pos.x - 1.15, 0, c.pos.z - 2.15),
            v(c.pos.x + 1.15, 2.1, c.pos.z + 2.15),
          ),
        );
    if (obstacle > dist - 0.12)
      return {
        id: candidate.id,
        point,
        position: { ...candidate.pos },
        distance: dist,
      };
  }
  return null;
}
export function perceive(
  world: World,
  vehicles: VisionVehicle[],
  observer: VisibleActor,
  actors: VisibleActor[],
  memory: BotMemory,
  now: number,
  random: () => number,
): Observation | null {
  const seen = actors
    .map((a) => observeEnemy(world, vehicles, observer, a))
    .filter((a): a is Observation => a !== null)
    .sort((a, b) => a.distance - b.distance);
  const target = seen.find((a) => a.id === memory.target) || seen[0];
  if (!target) {
    memory.visible = false;
    return null;
  }
  if (!memory.visible || memory.target !== target.id) {
    memory.readyAt =
      now + REACTION_MIN + random() * (REACTION_MAX - REACTION_MIN);
    memory.burstEnd = 0;
    memory.restUntil = 0;
    memory.aimOffset = (random() - 0.5) * 0.05;
  }
  memory.visible = true;
  memory.target = target.id;
  memory.lastSeen = { ...target.position };
  memory.lastSeenAt = now;
  return target;
}
