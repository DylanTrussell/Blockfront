export type MapId = 'baghdad' | 'foundry';
export type Vec = { x: number; y: number; z: number };
export type Solid = { x: number; z: number; w: number; d: number; h: number; y?: number; color: number; kind: 'building' | 'cover' | 'container' | 'reactor' };
export type World = { id: MapId; name: string; size: number; solids: Solid[]; patches: Vec[]; spawns: Vec[][] };
export const v = (x = 0, y = 0, z = 0): Vec => ({ x, y, z });
export const distance = (a: Vec, b: Vec) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
export const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
export function createWorld(id: MapId): World {
  const solids: Solid[] = [];
  const add = (x: number, z: number, w: number, d: number, h: number, color: number, kind: Solid['kind'] = 'building') => solids.push({ x, z, w, d, h, color, kind });
  if (id === 'baghdad') {
    for (const s of [-1, 1]) {
      add(s * 23, -23, 10, 12, 8, 0xc7975c); add(s * 23, -6, 10, 12, 6.6, 0xd4b483);
      add(s * 23, 13, 10, 13, 9.5, 0xbb8c57); add(s * 10, 27, 9, 6, 5.5, 0xe0c49a);
      add(s * 10, -27, 9, 6, 7.5, 0xcfab77);
      add(s * 9, 6, 6, 6, 4.5, s < 0 ? 0xbf9a63 : 0xe2c495);
      add(s * 8, -10, 4, 1.4, 1.2, 0xa38b58, 'cover');
      add(s * 11, 17, 4.5, 1.4, 1.25, 0xb19963, 'cover');
      add(s * 27, 28, 4, 3, 1.5, 0x706c4c, 'cover');
    }
    add(2, -19, 3.6, 2.4, 1.4, 0xa39676, 'cover');
    add(0, 14, 3.2, 1.3, 1.15, 0xb69a60, 'cover');
  } else {
    add(0, 0, 6.5, 6.5, 7.5, 0x314754, 'reactor');
    for (const s of [-1, 1]) {
      add(s * 20, -18, 6, 12, 3.2, s > 0 ? 0xdf773a : 0x347882, 'container');
      add(s * 20, 17, 6, 10, 3.2, s > 0 ? 0x407681 : 0xd19d45, 'container');
      add(s * 10, -8, 4.5, 5.5, 2.7, 0x4e6872, 'container');
      add(s * 12, 10, 6, 1.5, 1.1, 0x586770, 'cover');
      add(s * 29, 0, 4, 15, 6, 0x243a47);
      add(s * 7, 26, 5, 2, 1.3, 0xca8c35, 'cover');
      add(s * 6, -26, 5, 2, 1.3, 0xca8c35, 'cover');
    }
  }
  return { id, name: id === 'baghdad' ? 'Baghdad' : 'Sky Foundry', size: 35, solids, patches: [v(-15, 0, 0), v(15, 0, 0), v(0, 0, 23), v(0, 0, -23)], spawns: [[v(-5, 0, 30), v(0, 0, 30), v(5, 0, 30)], [v(-5, 0, -30), v(0, 0, -30), v(5, 0, -30)]] };
}
export function blocked(world: World, p: Vec, radius = .4): boolean {
  return Math.abs(p.x) > world.size - radius || Math.abs(p.z) > world.size - radius || world.solids.some(s => p.y < (s.y || 0) + s.h && p.y + 1.8 > (s.y || 0) && Math.abs(p.x - s.x) < s.w / 2 + radius && Math.abs(p.z - s.z) < s.d / 2 + radius);
}
export function move(world: World, p: Vec, dx: number, dz: number, radius = .4) {
  const n = { ...p, x: p.x + dx }; if (!blocked(world, n, radius)) p.x = n.x;
  n.x = p.x; n.z += dz; if (!blocked(world, n, radius)) p.z = n.z;
}
export function rayBox(o: Vec, d: Vec, min: Vec, max: Vec): number {
  let near = 0, far = Infinity;
  for (const axis of ['x', 'y', 'z'] as const) {
    if (Math.abs(d[axis]) < 1e-8) { if (o[axis] < min[axis] || o[axis] > max[axis]) return Infinity; }
    else { let a = (min[axis] - o[axis]) / d[axis], b = (max[axis] - o[axis]) / d[axis]; if (a > b) [a, b] = [b, a]; near = Math.max(near, a); far = Math.min(far, b); if (near > far) return Infinity; }
  }
  return far < 0 ? Infinity : near;
}
export function wallDistance(world: World, o: Vec, d: Vec) {
  let hit = 150;
  for (const s of world.solids) hit = Math.min(hit, rayBox(o, d, v(s.x - s.w / 2, s.y || 0, s.z - s.d / 2), v(s.x + s.w / 2, (s.y || 0) + s.h, s.z + s.d / 2)));
  return hit;
}
