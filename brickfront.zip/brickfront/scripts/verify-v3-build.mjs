import { spawnSync } from 'node:child_process';
for (const group of [
  'maps',
  'combat',
  'injury',
  'vehicles',
  'bots',
  'replay',
  'network',
  'geometry',
]) {
  const r = spawnSync(
    process.execPath,
    ['--import', 'tsx', 'scripts/verify.ts', group],
    { stdio: 'inherit' },
  );
  if (r.status !== 0) process.exit(r.status || 1);
}
const build = spawnSync('npm', ['run', 'verify:build'], { stdio: 'inherit' });
if (build.status !== 0) process.exit(build.status || 1);
console.log('RELEASE VERIFIED');
