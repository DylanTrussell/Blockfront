import assert from 'node:assert/strict';
import { RTCPeerConnection } from 'werift';
import { WEAPONS } from '../lib/weapons';
import { Simulation, emptyInput } from '../lib/simulation';
Object.assign(globalThis, {
  window: { location: { hostname: 'localhost' } },
  location: { protocol: 'https:', hostname: 'localhost' },
  RTCPeerConnection,
  RTCSessionDescription: class {
    type: string;
    sdp: string;
    constructor(s: { type: string; sdp: string }) {
      this.type = s.type;
      this.sdp = s.sdp;
    }
  },
});
const { Room } = await import('../lib/network');
const sim = new Simulation('baghdad', Math.random, { variant: 'snipers-only' });
const shooter = sim.addPlayer('host', 'Host', 0);
sim.fillBots();
let code = '',
  guestID = '',
  gotInput = false,
  gotState = false,
  gotFire = false,
  gotRules = false;
const failures: string[] = [];
const host = new Room(
  (info) => {
    if (info.status === 'Room open') code = info.code;
    if (info.error) failures.push(info.error);
  },
  (id) => {
    guestID = id;
    sim.addPlayer(id, 'Remote', 1);
    return id;
  },
  (id) => sim.removePlayer(id),
  (id, input) => {
    gotInput = input.forward === 1 && input.weapon === 4;
    sim.setInput(id, input);
  },
  () => {},
);
const guest = new Room(
  (info) => {
    if (info.error) failures.push(info.error);
  },
  () => '',
  () => {},
  () => {},
  (state, id) => {
    const a = state.actors.find((a) => a.id === id);
    if (a) {
      gotState = true;
      gotRules =
        state.rules.variant === 'snipers-only' &&
        a.inventory[0] === 7 &&
        a.inventory[1] === null &&
        a.inventory[2] === null &&
        a.weapon === 7 &&
        state.pickups.length > 0 &&
        state.pickups.every((p) => WEAPONS[p.weapon].sniper);
    }
    gotFire =
      gotFire ||
      state.events.some(
        (e) =>
          e.type === 'shot' &&
          e.actor === 'host' &&
          e.weapon === 7 &&
          Math.abs(e.pos.y - 1.68) > 0.1,
      );
  },
);
let interval: ReturnType<typeof setInterval> | null = null;
try {
  await host.host();
  const deadline = Date.now() + 45000;
  while (!code && Date.now() < deadline && !failures.length)
    await new Promise((r) => setTimeout(r, 100));
  assert.ok(code, failures.join(';') || 'Host signaling timed out');
  console.log('Host registered with public signaling service');
  guest.join(code);
  interval = setInterval(() => {
    shooter.cooldown = 0;
    shooter.reload = 0;
    shooter.ammo[7] = 5;
    sim.fire(shooter);
    host.broadcast(sim.snapshot());
    const input = emptyInput();
    input.forward = 1;
    input.weapon = 4;
    guest.send(input);
    sim.tick(1 / 60);
  }, 50);
  while (
    (!gotInput || !gotState || !gotRules || !gotFire) &&
    Date.now() < deadline &&
    !failures.length
  )
    await new Promise((r) => setTimeout(r, 100));
  assert.ok(gotInput, failures.join(';') || 'Guest controls were not received');
  assert.ok(
    gotState,
    failures.join(';') || 'Guest did not receive authoritative match state',
  );
  assert.ok(guestID);
  assert.ok(
    gotRules,
    'Host preset, inventory and allowed pickups received; unauthorized rocket selection rejected',
  );
  assert.ok(gotFire, 'Barrel-origin sniper shot received');
  console.log(
    'ONLINE VERIFIED: public signaling, WebRTC connection, guest input, host rules, inventory, pickups and barrel-origin shot delivered',
  );
} finally {
  if (interval) clearInterval(interval);
  guest.close();
  host.close();
  setTimeout(
    () => process.exit(gotInput && gotState && gotRules && gotFire ? 0 : 1),
    250,
  );
}
