import assert from 'node:assert/strict';
import * as T from 'three';
import {
  Simulation,
  emptyInput,
  ReplayBuffer,
  eye,
  type Actor,
} from '../lib/simulation';
import {
  WEAPONS,
  VARIANTS,
  allowedWeapon,
  allowedGrenades,
  weaponMuzzle,
  startingInventory,
  hitFeedback,
  type MatchRules,
} from '../lib/weapons';
import {
  soldierModel,
  humveeModel,
  weaponModel,
  updateSoldier,
  setMuzzleFlash,
} from '../lib/geometry';
import {
  observeEnemy,
  perceive,
  createBotMemory,
  REACTION_MIN,
  REACTION_MAX,
} from '../lib/perception';
import { tracer, updateTracer } from '../lib/combat-effects';
import { v, distance, blocked, type Vec } from '../lib/world';
const group = process.argv[2];
function seedRng(seed = 73) {
  return () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
}
function setup(rules: MatchRules = { variant: 'standard' }) {
  const s = new Simulation('baghdad', () => 0.5, rules),
    a = s.addPlayer('one', 'One', 0),
    b = s.addPlayer('two', 'Two', 1);
  s.world.solids = [];
  s.state.vehicles = [];
  a.pos = v();
  b.pos = v(0, 0, -10);
  a.protect = b.protect = 0;
  return { s, a, b };
}
function equip(a: Actor, wi: number) {
  a.weapon = wi;
  a.inventory[WEAPONS[wi].slot] = wi;
  a.ammo[wi] = WEAPONS[wi].mag;
  a.cooldown = a.reload = 0;
}
function close(a: Vec, b: Vec, label = 'position') {
  assert.ok(
    distance(a, b) < 1e-6,
    `${label}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`,
  );
}
if (group === 'presentation') {
  const { s, a, b } = setup();
  const soldier = soldierModel(0);
  for (let wi = 0; wi < WEAPONS.length; wi++)
    for (const yaw of [0, 1.2, -2.5])
      for (const pitch of [-0.7, 0, 0.65])
        for (const legless of [false, true]) {
          equip(a, wi);
          a.pos = v(3, 0, 4);
          a.yaw = yaw;
          a.pitch = pitch;
          a.limbs = [true, true, !legless, !legless];
          a.firing = 0.1;
          updateSoldier(soldier, a);
          soldier.updateMatrixWorld(true);
          close(
            soldier
              .getObjectByName('muzzle')!
              .getWorldPosition(new T.Vector3()),
            weaponMuzzle(a),
            `held ${wi}`,
          );
          assert.equal(soldier.getObjectByName('muzzleFlash')!.visible, true);
          a.firing = 0;
          updateSoldier(soldier, a);
          assert.equal(soldier.getObjectByName('muzzleFlash')!.visible, false);
          const fp = weaponModel(wi, true);
          assert.ok(fp.getObjectByName('rightHand'));
          assert.ok(fp.getObjectByName('muzzleFlash'));
          setMuzzleFlash(fp, 0.05, 3);
          assert.equal(fp.getObjectByName('muzzleFlash')!.visible, true);
        }
  const car = humveeModel(0, true);
  a.seat = 'turret';
  a.pos = v(2, 0, 5);
  a.yaw = -0.8;
  a.pitch = 0.3;
  const carYaw = 0.6;
  car.position.copy(a.pos);
  car.rotation.y = carYaw;
  car
    .getObjectByName('turret')!
    .rotation.set(a.pitch, a.yaw - carYaw, 0, 'YXZ');
  car.updateMatrixWorld(true);
  close(
    car.getObjectByName('muzzle')!.getWorldPosition(new T.Vector3()),
    weaponMuzzle(a, carYaw),
    'turret',
  );
  a.seat = '';
  a.pos = v();
  a.yaw = 0;
  a.pitch = 0;
  a.limbs = [true, true, true, true];
  equip(a, 0);
  s.fire(a);
  const shot = s.state.events.find((e) => e.type === 'shot')!;
  close(shot.pos, weaponMuzzle(a));
  assert.ok(distance(shot.pos, eye(a)) > 1);
  assert.ok(b.hp < 100, 'shot reaches crosshair target from barrel');
  const history = new ReplayBuffer();
  history.record(s.state, true);
  a.weapon = 7;
  a.firing = 0;
  const frame = history.clip(s.state.time)[0];
  assert.equal(frame.actors[0].weapon, 0);
  assert.ok(frame.actors[0].firing > 0);
  updateSoldier(soldier, frame.actors[0]);
  assert.equal(soldier.userData.weapon, 0);
  assert.equal(soldier.getObjectByName('muzzleFlash')!.visible, true);
  close(frame.events.find((e) => e.type === 'shot')!.pos, shot.pos);
  const line = tracer(v(0, 1, 0), v(0, 1, -100));
  for (const progress of [0.01, 0.2, 0.8, 1]) {
    updateTracer(line, progress);
    const p = line.geometry.getAttribute('position');
    assert.ok(
      new T.Vector3()
        .fromBufferAttribute(p, 0)
        .distanceTo(new T.Vector3().fromBufferAttribute(p, 1)) <= 2.40001,
    );
    assert.ok(p.getZ(1) <= 0 && p.getZ(1) >= -100);
  }
}
if (group === 'perception') {
  const { s, a, b } = setup();
  a.bot = true;
  a.yaw = 0;
  b.pos = v(0, 0, -10);
  assert.ok(observeEnemy(s.world, [], a, b), 'positive visible control');
  b.pos = v(0, 0, 10);
  assert.equal(observeEnemy(s.world, [], a, b), null, 'behind');
  b.pos = v(20, 0, -2);
  assert.equal(observeEnemy(s.world, [], a, b), null, 'outside cone');
  b.pos = v(0, 0, -40);
  assert.equal(observeEnemy(s.world, [], a, b), null, 'too far');
  b.pos = v(0, 0, -10);
  s.world.solids.push({
    x: 0,
    z: -5,
    w: 8,
    d: 1,
    h: 4,
    color: 0,
    kind: 'cover',
  });
  assert.equal(observeEnemy(s.world, [], a, b), null, 'solid cover');
  s.world.solids = [];
  assert.equal(
    observeEnemy(s.world, [{ id: 'car', dead: 0, pos: v(0, 0, -5) }], a, b),
    null,
    'vehicle cover',
  );
  const memory = createBotMemory();
  assert.ok(perceive(s.world, [], a, [a, b], memory, 10, () => 0.5));
  assert.ok(
    memory.readyAt >= 10 + REACTION_MIN && memory.readyAt <= 10 + REACTION_MAX,
  );
  const last = { ...memory.lastSeen! };
  b.pos = v(0, 0, 10);
  perceive(s.world, [], a, [a, b], memory, 11, () => 0.5);
  close(memory.lastSeen!, last, 'last seen snapshot');
  assert.equal(memory.visible, false);
  b.pos = v(0, 0, -10);
  perceive(s.world, [], a, [a, b], memory, 12, () => 0.5);
  assert.ok(memory.readyAt > 12, 'reacquisition reaction');
  s.brains.clear();
  s.state.time = 0;
  let input = s.ai(a, 1 / 60);
  assert.equal(input.shoot, false);
  s.state.time = 0.3;
  input = s.ai(a, 1 / 60);
  assert.equal(input.shoot, false);
  s.state.time = 0.7;
  input = s.ai(a, 1 / 60);
  assert.equal(input.shoot, true, 'can fire after seeing and reacting');
  const l = setup(),
    r = setup();
  l.s.random = seedRng();
  r.s.random = seedRng();
  for (const pair of [l, r]) {
    pair.a.bot = true;
    pair.s.world.solids = [
      { x: 0, z: 0, w: 30, d: 2, h: 5, color: 0, kind: 'building' },
    ];
    pair.a.pos = v(0, 0, 7);
    pair.a.yaw = 0;
    pair.b.pos = v(0, 0, -7);
  }
  for (let n = 0; n < 100; n++) {
    l.b.pos = v(-10 + n * 0.1, 0, -7);
    r.b.pos = v(10 - n * 0.08, 0, -12);
    l.s.state.time = r.s.state.time = n / 60;
    const li = l.s.ai(l.a, 1 / 60),
      ri = r.s.ai(r.a, 1 / 60);
    assert.deepEqual(
      li,
      ri,
      'hidden player movement must not change bot controls',
    );
    assert.equal(li.shoot, false);
    l.s.act(l.a, li, 1 / 60);
    r.s.act(r.a, ri, 1 / 60);
  }
}
if (group === 'inventory') {
  const { s, a } = setup();
  assert.deepEqual(a.inventory, [0, 6, 4]);
  for (const wi of [6, 4, 0]) {
    const i = emptyInput();
    i.weapon = wi;
    s.act(a, i, 0);
    assert.equal(a.weapon, wi);
  }
  const invalid = emptyInput();
  invalid.weapon = 8;
  s.act(a, invalid, 0);
  assert.equal(a.weapon, 0, 'unowned weapon denied');
  const pad = {
    id: 900,
    weapon: 8,
    pos: v(0, 0, -1),
    cooldown: 0,
    dropped: false,
    expires: 0,
  };
  s.state.pickups = [pad];
  assert.equal(s.pickup(a), true);
  assert.deepEqual(a.inventory, [8, 6, 4]);
  assert.equal(a.weapon, 8);
  assert.equal(a.ammo[8], WEAPONS[8].mag);
  assert.equal(pad.cooldown, 20);
  assert.ok(s.state.pickups.some((p) => p.dropped && p.weapon === 0));
  assert.equal(s.pickup(a), false, 'no repeated pickup during cooldown');
  s.tick(0.1);
  assert.equal(pad.cooldown, 19.9);
  pad.cooldown = 0;
  a.pos = v(10, 0, 0);
  assert.equal(s.pickup(a), false, 'out of range');
  a.pos = v();
  s.state.pickups = [pad];
  s.world.solids.push({
    x: 0,
    z: -0.5,
    w: 4,
    d: 0.2,
    h: 3,
    color: 0,
    kind: 'cover',
  });
  assert.equal(s.pickup(a), false, 'through wall');
  s.world.solids = [];
  s.state.pickups = [{ ...pad, id: 901, weapon: 9, cooldown: 0 }];
  s.pickup(a);
  assert.deepEqual(a.inventory, [8, 9, 4]);
  s.state.pickups = [{ ...pad, id: 902, weapon: 5, cooldown: 0 }];
  s.pickup(a);
  assert.deepEqual(a.inventory, [8, 9, 5]);
  const action = emptyInput();
  action.pickup = true;
  s.setInput(a.id, action);
  s.tick(1 / 60);
  assert.equal(action.pickup, false, 'consume remote action once');
  const { isState } = await import('../lib/network');
  assert.ok(isState(JSON.parse(JSON.stringify(s.snapshot()))));
  s.spawn(a);
  assert.deepEqual(a.inventory, [0, 6, 4]);
  for (const map of ['baghdad', 'foundry'] as const) {
    const sim = new Simulation(map);
    for (const p of sim.state.pickups) {
      assert.equal(
        blocked(sim.world, p.pos, 0.2),
        false,
        `reachable ${map} ${p.weapon}`,
      );
      assert.ok(
        sim.path(sim.world.spawns[0][0], p.pos).length ||
          distance(sim.world.spawns[0][0], p.pos) < 2,
        `pickup path ${map}`,
      );
    }
  }
}
if (group === 'rules') {
  for (const variant of VARIANTS) {
    const s = new Simulation('baghdad', () => 0.5, { variant });
    s.fillBots();
    for (const a of s.state.actors) {
      assert.ok(a.inventory.includes(a.weapon));
      assert.ok(allowedWeapon(a.weapon, s.state.rules));
      for (const [slot, wi] of a.inventory.entries())
        if (wi !== null) {
          assert.equal(WEAPONS[wi].slot, slot);
          assert.ok(allowedWeapon(wi, s.state.rules));
        }
      assert.equal(a.grenades > 0, allowedGrenades(s.state.rules));
    }
    assert.ok(
      s.state.pickups.every((p) => allowedWeapon(p.weapon, s.state.rules)),
    );
    const a = s.state.actors[0];
    a.bot = false;
    a.protect = 0;
    a.pos = v(0, 0, 5);
    const rejected = WEAPONS.findIndex(
      (_, i) => !allowedWeapon(i, s.state.rules),
    );
    if (rejected >= 0) {
      const i = emptyInput();
      i.weapon = rejected;
      s.act(a, i, 0);
      assert.notEqual(a.weapon, rejected);
      const before = s.state.events.length;
      a.weapon = rejected;
      s.fire(a);
      assert.equal(s.state.events.length, before);
      s.spawn(a);
    }
    const wreck = s.state.vehicles.find((c) => c.fixed)!;
    a.pos = v(wreck.pos.x + 2.5, 0, wreck.pos.z);
    s.mount(a, 'turret');
    assert.equal(a.seat === 'turret', allowedWeapon(3, s.state.rules));
    s.dismount(a);
    if (!allowedGrenades(s.state.rules)) {
      a.weapon = 1;
      a.cooldown = 0;
      a.grenades = 3;
      const i = emptyInput();
      i.grenade = true;
      s.act(a, i, 0);
      assert.equal(s.state.projectiles.length, 0);
    }
  }
  const { isState } = await import('../lib/network');
  const { s } = setup({ variant: 'snipers-only' });
  assert.ok(isState(s.snapshot()));
  const malformed = s.snapshot();
  malformed.actors[0].inventory[2] = 4;
  assert.equal(isState(malformed), false);
  const legacy = s.snapshot();
  legacy.protocol = 1;
  assert.equal(isState(legacy), false);
}
if (group === 'damage') {
  const counts: Record<number, number> = { 0: 7, 1: 7, 2: 6, 6: 5, 9: 7 };
  for (const [key, hits] of Object.entries(counts)) {
    const { s, a, b } = setup();
    equip(a, Number(key));
    a.pitch = Math.atan2(1.1 - eye(a).y, 10);
    for (let n = 0; n < hits; n++) {
      a.cooldown = 0;
      s.fire(a);
      if (n < hits - 1)
        assert.ok(b.hp > 0, `survive ${n + 1} body hits ${key}`);
    }
    assert.equal(b.hp, 0, `body hit count ${key}`);
  }
  for (const wi of [7, 8]) {
    const { s, a, b } = setup();
    equip(a, wi);
    a.pitch = Math.atan2(1.1 - eye(a).y, 10);
    s.fire(a);
    assert.ok(b.hp > 0, 'sniper body survives');
    const next = setup();
    equip(next.a, wi);
    next.s.fire(next.a);
    assert.equal(next.b.hp, 0, 'sniper headshot lethal');
  }
  for (const wi of [4, 5]) {
    const { s, a, b } = setup();
    equip(a, wi);
    const c = s.addPlayer('third', 'Third', 1);
    c.pos = v(1.2, 0, -10);
    c.protect = 0;
    const d = s.addPlayer('falloff', 'Falloff', 1);
    d.pos = v(4.5, 0, -10);
    d.protect = 0;
    const e = s.addPlayer('outside', 'Outside', 1);
    e.pos = v(8, 0, -10);
    e.protect = 0;
    a.pitch = Math.atan2(1.1 - eye(a).y, 10);
    s.fire(a);
    for (let n = 0; n < 30; n++) s.tick(1 / 60);
    assert.equal(b.hp, 0, 'direct rocket kill');
    assert.equal(c.hp, 0, 'same rocket second kill');
    assert.ok(d.hp > 0 && d.hp < 100, 'outer falloff');
    assert.equal(e.hp, 100, 'outside radius');
    assert.equal(a.kills, 2);
  }
  const { s, a, b } = setup();
  b.pos = v(0, 0, -3);
  s.world.solids.push({
    x: 0,
    z: -1.5,
    w: 5,
    d: 0.5,
    h: 4,
    color: 0,
    kind: 'cover',
  });
  s.explode(v(0, 1, 0), a.id, 140, 6, '', 2);
  assert.equal(b.hp, 100, 'blast cover');
  s.world.solids = [];
  s.explode(v(0, 1, 0), a.id, 140, 6, '', 2);
  assert.ok(b.hp < 100, 'positive uncovered blast');
  const hit = setup();
  hit.s.state.time = 10;
  hit.s.damage(hit.a, 16, hit.b.id);
  let feedback = hitFeedback(hit.a, 10.05);
  assert.ok(feedback.opacity > 0.8);
  assert.equal(feedback.angle, 0);
  hit.a.yaw = Math.PI / 2;
  feedback = hitFeedback(hit.a, 10.4);
  assert.equal(feedback.angle, 90);
  assert.ok(feedback.opacity > 0);
  assert.equal(hitFeedback(hit.a, 11).opacity, 0);
  hit.s.state.events = [];
  hit.s.tick(0.1);
  assert.equal(hit.a.lastHit, 10, 'bleed does not reset hit direction');
  assert.ok(hit.s.state.events.every((e) => e.type !== 'hit'));
  hit.a.hp = 20;
  assert.equal(hitFeedback(hit.a, 12).lowHealth, true);
}
assert.ok(
  ['presentation', 'perception', 'inventory', 'rules', 'damage'].includes(
    group,
  ),
);
console.log(group.toUpperCase() + ' VERIFIED');
