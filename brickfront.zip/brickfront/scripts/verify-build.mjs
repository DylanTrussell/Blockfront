import {stat,readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
assert.ok((await stat('dist/server/index.js')).size>100);
const hosting=JSON.parse(await readFile('.openai/hosting.json','utf8'));assert.ok(hosting.project_id);
assert.ok((await stat('dist/client')).isDirectory());
console.log('BUILD VERIFIED');
