'use client';
import { useEffect, useRef, useState } from 'react';
import {
  Box,
  ArrowUpRight,
  Crosshair,
  Users,
  Monitor,
  Building2,
  Factory,
  Volume2,
  VolumeX,
  Keyboard,
  ChevronRight,
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  WEAPONS,
  SELECTABLE,
  RULE_LABELS,
  VARIANTS,
  allowedWeapon,
  startingInventory,
  type Variant,
} from '@/lib/weapons';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { MapId } from '@/lib/world';
import type { Engine, EngineHUD } from '@/lib/engine';
import { HUD } from './hud';
import { registerMatchTools } from '@/lib/webmcp';
import { createInviteURL, resolveInvite } from '@/lib/room-discovery';
const descriptions: Record<number, string> = {
  0: '7.62 assault rifle. Reliable, punchy, unmistakable.',
  1: '5.56 rifle with an underbarrel grenade launcher.',
  2: 'Belt-fed support. Keep their heads down.',
  4: 'A direct hit is lethal. Watch the splash.',
  5: 'American shoulder-fired rocket launcher.',
  6: 'A heavy-hitting .45 sidearm.',
  7: 'Bolt-action precision. Right-click to use the scope.',
  8: 'Heavy semi-automatic sniper. Aim for the head.',
  9: 'High-capacity 9mm sidearm.',
};
export default function Page() {
  const mount = useRef<HTMLDivElement>(null);
  const engine = useRef<Engine | null>(null);
  const [map, setMap] = useState<MapId>('baghdad'),
    [mode, setMode] = useState('solo'),
    [weapon, setWeapon] = useState(0);
  const [variant, setVariant] = useState<Variant>('standard');
  const rules = { variant },
    inventory = startingInventory(rules, weapon);
  const changeVariant = (value: Variant) => {
    setVariant(value);
    if (!allowedWeapon(weapon, { variant: value }))
      setWeapon(
        startingInventory({ variant: value }).find(
          (id): id is number => id !== null,
        )!,
      );
  };
  const configRef = useRef({
    map,
    mode: mode as 'solo' | 'online' | 'split',
    weapon,
    variant,
  });
  configRef.current = {
    map,
    mode: mode as 'solo' | 'online' | 'split',
    weapon,
    variant,
  };
  const [playing, setPlaying] = useState(false),
    [hud, setHUD] = useState<EngineHUD | null>(null),
    [code, setCode] = useState('');
  const [ready, setReady] = useState(false),
    [help, setHelp] = useState(false),
    [muted, setMuted] = useState(false),
    [error, setError] = useState('');
  useEffect(() => {
    let alive = true;
    import('@/lib/engine')
      .then(({ Engine }) => {
        if (alive && mount.current) {
          engine.current = new Engine(mount.current);
          engine.current.onPlaying = setPlaying;
          engine.current.onHUD = (h) => setHUD({ ...h });
          engine.current.onError = setError;
          setReady(true);
        }
      })
      .catch((e) => setError(String(e)));
    return () => {
      alive = false;
      engine.current?.dispose();
    };
  }, []);
  useEffect(() => {
    if (!playing) engine.current?.setMap(map);
  }, [map, ready, playing]);
  useEffect(() => {
    if (engine.current) engine.current.audio.muted = muted;
  }, [muted, ready]);
  useEffect(() => {
    const room = new URLSearchParams(location.search).get('room');
    if (room) {
      setCode(room.toUpperCase().slice(0, 6));
      setMode('online');
    }
  }, []);
  useEffect(
    () =>
      registerMatchTools(
        () => configRef.current,
        (c) => {
          if (engine.current?.playing)
            throw Error('Return to the lobby before configuring a match');
          setMap(c.map);
          setMode(c.mode);
          setWeapon(c.weapon);
          setVariant(c.variant);
          configRef.current = c;
        },
      ),
    [],
  );
  const copyInvite = () => {
    const room = engine.current?.room.connection;
    if (!room) {
      setError('Create a room before copying an invite.');
      return;
    }
    const link = createInviteURL(location.href, room);
    navigator.clipboard
      .writeText(link)
      .then(() => setError('Invite link copied. Share it with your friend.'))
      .catch(() => setError('Room code: ' + engine.current?.room.info.code));
  };
  return (
    <main className={`game-shell ${playing ? 'playing' : ''}`}>
      <div className="arena" ref={mount} />
      {!ready && !error && (
        <div className="loading-engine">ASSEMBLING THE BATTLEFIELD</div>
      )}
      {playing && hud && engine.current && (
        <HUD hud={hud} engine={engine.current} copy={copyInvite} />
      )}
      {!playing && (
        <>
          <div className="menu-shade" />
          <header className="topbar">
            <div className="brand">
              <Box size={25} strokeWidth={2.4} /> BRICKFRONT
            </div>
            <div className="top-actions">
              <span className="build-tag">COMBAT UPDATE · 03</span>
              <button
                aria-label={muted ? 'Unmute audio' : 'Mute audio'}
                onClick={() => setMuted(!muted)}
              >
                {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
              </button>
              <button onClick={() => setHelp(true)}>
                <Keyboard size={18} /> CONTROLS
              </button>
            </div>
          </header>
          <section className="lobby">
            <div className="eyebrow">
              <i className="dot" /> BOOTS ON THE BASEPLATE
            </div>
            <h1>
              BRICK
              <br />
              <span>FRONT.</span>
            </h1>
            <p className="intro">
              Small pieces. Heavy firepower.
              <br />
              Build your last stand.
            </p>
            <div className="section-label">
              <span>01 / Choose your fight</span>
              <span>TEAM DEATHMATCH</span>
            </div>
            <Tabs value={mode} onValueChange={(v) => setMode(String(v))}>
              <TabsList className="mode-list">
                <TabsTrigger className="mode-tab" value="solo">
                  <Crosshair size={14} /> SOLO + AI
                </TabsTrigger>
                <TabsTrigger className="mode-tab" value="online">
                  <Users size={14} /> ONLINE
                </TabsTrigger>
                <TabsTrigger className="mode-tab" value="split">
                  <Monitor size={14} /> 2 PLAYERS
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <p className="mode-description">
              {mode === 'solo'
                ? 'You, your squad, and a whole lot of spare parts.'
                : mode === 'online'
                  ? 'Host a private room. Send the code. Bring your squad.'
                  : 'Side by side. Split-screen rivals on one computer.'}
            </p>
            <div className="section-label">
              <span>02 / Select battlefield</span>
              <span>2 MAPS</span>
            </div>
            <RadioGroup
              className="map-picker"
              value={map}
              onValueChange={(v) => setMap(v as MapId)}
            >
              {(['baghdad', 'foundry'] as const).map((id, i) => (
                <label
                  key={id}
                  className={`map-option ${map === id ? 'selected' : ''}`}
                >
                  <RadioGroupItem
                    value={id}
                    className="map-radio"
                    aria-label={i ? 'Sky Foundry' : 'Baghdad'}
                  />
                  {i ? <Factory size={28} /> : <Building2 size={28} />}
                  <span>
                    <strong>{i ? 'Sky Foundry' : 'Baghdad'}</strong>
                    <small>{i ? 'VERTICAL INDUSTRY' : 'URBAN WARFARE'}</small>
                  </span>
                </label>
              ))}
            </RadioGroup>
            {mode === 'online' && (
              <div className="room-box">
                <input
                  aria-label="Room code"
                  placeholder="6-character room code"
                  value={code}
                  maxLength={6}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                />
                <button
                  disabled={!ready || !code.trim()}
                  onClick={() => {
                    try {
                      resolveInvite(code);
                      setError('');
                      engine.current?.start('online', weapon, code, rules);
                    } catch {
                      setError('Enter the 6-character room code.');
                    }
                  }}
                >
                  JOIN
                </button>
              </div>
            )}
            <button
              className="deploy"
              disabled={!ready}
              onClick={() => {
                setError('');
                engine.current?.start(mode, weapon, '', rules);
              }}
            >
              <span>
                {mode === 'online' ? 'CREATE ROOM' : 'DEPLOY TO BATTLE'}
                <small>{mode === 'online' ? 'INVITE & PLAY' : '4 vs 4'}</small>
              </span>
              <ArrowUpRight size={24} />
            </button>
            {error && <p className="error-box">{error}</p>}
          </section>
          <div className="map-caption">
            <div className="eyebrow" style={{ justifyContent: 'flex-end' }}>
              LIVE BATTLEFIELD PREVIEW <i className="dot" />
            </div>
            <p>
              {map === 'baghdad'
                ? 'THE OLD QUARTER / LATE AFTERNOON'
                : 'PLATFORM 07 / ABOVE THE CLOUDLINE'}
            </p>
            <span className="coord">
              {map === 'baghdad'
                ? 'SECTOR B · BAGHDAD'
                : 'SECTOR S · SKY FOUNDRY'}
            </span>
          </div>
          <section className="loadout">
            <div className="loadout-title">
              <label htmlFor="match-rules">MATCH RULES</label>
              <span>
                {mode === 'online' ? 'HOST SETS THE RULES' : 'CUSTOM GAME'}
              </span>
            </div>
            <Select
              value={variant}
              onValueChange={(v) => {
                if (v) changeVariant(v as Variant);
              }}
            >
              <SelectTrigger id="match-rules" className="rules-select">
                <SelectValue>{RULE_LABELS[variant]}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                {VARIANTS.map((v) => (
                  <SelectItem key={v} value={v}>
                    {RULE_LABELS[v]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="loadout-title" style={{ marginTop: 18 }}>
              <span>CHOOSE YOUR STARTING WEAPON</span>
              <Crosshair size={15} />
            </div>
            <div className="weapons">
              {SELECTABLE.filter((i) => allowedWeapon(i, rules)).map((i) => (
                <button
                  key={i}
                  className={`weapon-button ${weapon === i ? 'selected' : ''}`}
                  onClick={() => setWeapon(i)}
                >
                  {WEAPONS[i].name}
                </button>
              ))}
            </div>
            <p className="weapon-detail">{descriptions[weapon]}</p>
            <div className="starting-slots">
              {inventory.map((id, i) => (
                <span key={i}>
                  <small>{['PRIMARY', 'SIDEARM', 'LAUNCHER'][i]}</small>
                  <b>{id === null ? 'DISABLED' : WEAPONS[id].name}</b>
                </span>
              ))}
            </div>
            <div className="mini-stats">
              <span>
                <b>100</b> HEALTH
              </span>
              <span>
                <b>50</b> TO WIN
              </span>
              <span>
                <b>6:00</b> MATCH
              </span>
            </div>
          </section>
          <footer className="bottom-strip">
            <span>
              <strong>●</strong> ALL BRICKS. NO BLOOD.
            </span>
            <span>
              WASD TO MOVE{' '}
              <ChevronRight size={10} style={{ display: 'inline' }} /> MOUSE TO
              AIM
            </span>
            <span>INDEPENDENT BRICK-BUILT GAME</span>
          </footer>
        </>
      )}
      {playing && error && (
        <button
          className="secondary-button"
          style={{
            position: 'absolute',
            zIndex: 30,
            bottom: 10,
            left: '50%',
            transform: 'translateX(-50%)',
          }}
          onClick={() => setError('')}
        >
          {error} ×
        </button>
      )}
      <Dialog open={help} onOpenChange={setHelp}>
        <DialogContent className="help-dialog">
          <DialogTitle>Know your controls.</DialogTitle>
          <DialogDescription>
            Desktop: keyboard + mouse. Touch controls appear on smaller screens.
          </DialogDescription>
          <div className="help-grid">
            {[
              ['Move', 'W A S D'],
              ['Look / shoot', 'MOUSE / CLICK'],
              ['Aim down sights', 'RIGHT CLICK'],
              ['Sprint / jump', 'SHIFT / SPACE'],
              ['Reload / patch kit', 'R / Q'],
              ['Weapon slots', '1–3 / WHEEL'],
              ['Pick up / swap weapon', 'X'],
              ['M203 grenade', 'G'],
              ['Drive / dismount', 'E'],
              ['Mount .50 cal', 'F'],
              ['Pause / release mouse', 'ESC'],
              ['Player 2 move', 'ARROW KEYS'],
              ['P2 aim / fire', 'I J K L / ENTER'],
              ['P2 reload / use', 'O / U'],
              ['P2 jump / turret', 'P / Y'],
              ['P2 pickup / cycle', 'B / BACKSLASH'],
            ].map(([a, b]) => (
              <p key={a}>
                {a}
                <kbd>{b}</kbd>
              </p>
            ))}
          </div>
          <p>
            Carry a primary, a sidearm, and a launcher in Standard games. Press
            X near a weapon to replace its matching slot. Room rules apply to
            all players, bots, pickups, and mounted guns. Pick up green patch
            kits to stop bleeding and repair health. Losing a leg slows you
            down; losing an arm increases recoil. Vehicles and fixed turrets are
            marked when you get close. Player 2 can also use a gamepad.
          </p>
        </DialogContent>
      </Dialog>
    </main>
  );
}
