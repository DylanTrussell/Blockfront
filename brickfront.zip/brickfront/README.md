# Brickfront

A playable brick-built browser FPS with Baghdad and Sky Foundry, solo AI squads, two-player split-screen, and online private rooms for up to eight people.

## Play

Use a modern desktop browser with WebGL2. WASD move, mouse aim, click fire, right click aim, Shift sprint, Space jump, R reload, Q use patch, 1–3 select primary/sidearm/launcher or wheel cycle carried weapons, X pick up or swap a nearby weapon, G fire M203 grenade. E enters/exits a Humvee. F mounts a turret. Escape pauses and releases the mouse.

Player 2 uses arrow keys to move, IJKL to aim, Enter to fire, P to jump, O to reload, U to drive/exit, Y to mount the gun, H to patch, N for M203, B to pick up a weapon, and backslash to switch weapons. A connected gamepad supports moving, aiming, shooting, reloading and jumping for Player 2.

Select Online and Create Room. Pause to copy the invitation link or read the six-character room code. Your friend opens the same site and joins. The host must keep the tab active; the match ends if the host leaves. Bots fill remaining seats. Team damage is disabled. Matches last six minutes or until a team reaches 50 kills.

## Mechanics

Real weapon names with game-balanced handling: AK-47, M16/M203, M60, RPG-7, M1 Bazooka, M1911 and M9 pistols, M24 and M82 sniper rifles, plus the mounted M2 .50 cal. Standard games give you three slots: primary, sidearm, and launcher. Weapon pickups replace only their corresponding slot and respawn after 20 seconds; eliminated players drop their active weapon for 35 seconds. Room presets include Standard, No Snipers, Snipers Only, Pistols Only, and Rockets Only. The host enforces the preset for players, bots, pickups, grenades, and turrets. Ammunition replenishes on reload. Patch kits restore health and stop bleeding, but severed limbs return on respawn. One missing leg slows movement; both legs enable a crawling last stand. An arm injury increases weapon spread. No real blood is rendered.

Shots originate at the same barrel socket used by the visible weapon model. All weapons have muzzle flashes, including the first-person replay weapon. Short gold tracers replace the old full-length white lines. Bots need an unobstructed view within their field of vision, followed by a 0.4–0.65 second reaction delay. They briefly investigate a last-seen position but receive no hidden movement updates.

Regular rifles need six to seven body hits against full health. Rockets kill on a direct hit, have a lethal two-meter inner blast zone and a six-meter outer damage radius, and can hit multiple opponents; solid world cover blocks splash. Friendly fire remains off. Red damage feedback includes a direction marker and a low-health vignette. Breath audio is deferred.

The Baghdad road wreck has three wheels, an open damaged hood and a usable roof machine gun. Each team has a working Humvee, with a driver seat and a separate gunner seat. Destroyed vehicles return after 30 seconds. Death replays store approximately three seconds of actor and vehicle transforms and shot events and follow the killer's viewpoint.

## Development

- `npm install`
- `npm run dev`
- `npm test`
- `npm run verify:build`
- `node --import tsx scripts/verify-online.ts`
- `node --import tsx scripts/verify-v3.ts presentation` (also perception, inventory, rules, damage)
- `node scripts/verify-v3-build.mjs`

The game runs on Three.js. A deterministic-step simulation owns collisions, damage, AI navigation, vehicles and scoring. Online games use PeerJS/WebRTC with the host as simulation authority. The integration test connects two actual WebRTC endpoints through the public PeerJS signaling service, sends player controls, and verifies receipt of authoritative match state.

## Current limits

This is a playable alpha, with procedural models and stylized maps. Baghdad is inspired by the city, not a geographical reconstruction. The game is independent and has no affiliation with LEGO or Call of Duty. There are no public matchmaking servers, accounts, progression, host migration or competitive anti-cheat. Connections depend on PeerJS signaling and NAT traversal; restrictive networks may fail. Online animation reflects host snapshots and does not yet have competitive lag compensation. Desktop keyboard and mouse are preferred. Touch controls cover the main actions. Local split-screen requires a sufficiently wide screen.

Automated verification covers map reachability and collision, combat and reloads, injuries, Humvee/turret behavior, bot matches, replay history, input validation, geometry and actual WebRTC message delivery. The updated lobby selector was inspected in the browser. Combat visual inspection remains incomplete because the browser automation connection stopped responding while loading the verification scene. Automated model/socket alignment, flash state, replay preservation, and hit-feedback checks passed. This does not replace human playtesting. The optional WebMCP tools were not exercised.

## Future public rooms

Room discovery lives in `lib/room-discovery.ts`, separately from PeerJS transport
in `lib/network.ts` and gameplay in `lib/simulation.ts`. Private invite codes
resolve locally into a versioned `RoomConnection`; no room listing service is
contacted. `Room.joinConnection()` is the shared connection entry point.

A future public room browser can implement `PublicRoomDirectory`, display its
compatible, non-full listings and pass the selected listing to
`Room.joinConnection()`. Hosts opt into publishing a listing and hold a
`PublicRoomLease`, which supports heartbeats and removal. The directory service
must authenticate its host leases, expire stale listings, and validate occupancy.
Private room creation must keep using `createPrivateRoom()` and never publish a
listing. Public discovery adds a service and interface without replacing the
current match transport or simulation. No public directory is enabled today.

## Graphics development order

1. Combat clarity: held weapons, muzzle flashes, hit feedback, and readable silhouettes. This update implements that pass.
2. Prove the match loop: fair AI, movement, damage, pickups, room rules, and reliable multiplayer. Playtest the new balance before locking it down.
3. Polish one representative Baghdad street to the intended visual quality: better brick models, soldier grip and animation, materials, lighting, debris, and effects. Measure performance with eight combatants and split-screen.
4. Extend the proven art style to both maps. Textures alone will not provide the final look.

The existing playable maps serve as the graybox; no separate graybox rebuild is needed.
