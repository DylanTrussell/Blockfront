# Gates: Combat readability and custom rooms

OWNS: lib/**, app/**, scripts/**, README.md, gates/combat-v3.md

Scope: Barrel-origin weapons and muzzle flashes in live combat and killcam, fair visual AI, three inventory slots and pickups, pistols and snipers, enforced host presets, slower weak-gun kills, lethal direct rockets with multi-target splash, clear red hit feedback. Breath audio is explicitly deferred.

- [x] C1: Weapon mounts and shot origins agree; firing poses and flashes survive replay recording.
  CHECK: node --import tsx scripts/verify-v3.ts presentation
  EXPECT: PRESENTATION VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=618f12cf5e15b570e963da6c448962dcd9b4e38a1354b7964d1640ff79fb0775; output-bytes=22
- [x] C2: Bots require field of view, unobstructed vision and reaction time; hidden enemy movement cannot steer their aim or path.
  CHECK: node --import tsx scripts/verify-v3.ts perception
  EXPECT: PERCEPTION VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=be1d824246dbecce454dbdf92784c0fce8a4a637b8eb3e56fb0aeff4a0b55351; output-bytes=20
- [x] C3: Three slots restrict selection; nearby pickups replace only matching slots and synchronize weapon/ammo state.
  CHECK: node --import tsx scripts/verify-v3.ts inventory
  EXPECT: INVENTORY VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=cd580e96b0137c5f522393bc09217b4fb06fc39d836a943da27fb16613f93db2; output-bytes=19
- [x] C4: Every preset controls spawns, pickups, bots, grenades, turrets and input authorization.
  CHECK: node --import tsx scripts/verify-v3.ts rules
  EXPECT: RULES VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=bb62a0ce532d93c1d4a14af255357f6e07a745f643e67e36198b798e641e5ba9; output-bytes=15
- [x] C5: Weak guns require more hits; direct rockets kill and splash damages multiple exposed opponents while respecting cover.
  CHECK: node --import tsx scripts/verify-v3.ts damage
  EXPECT: DAMAGE VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=b1f95ba95ba5f2bf864c208c57d08e8a82961186ce06474277239f2e920a8f85; output-bytes=16
- [x] C6: New rules, inventory, pickups and firing events pass the actual WebRTC host/guest connection.
  CHECK: node --import tsx scripts/verify-online.ts
  EXPECT: ONLINE VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=d042806142fad560762f03439cad70e8d054fa3a997d43169ed9656231b65069; output-bytes=177
- [x] C7: TypeScript and production build pass with existing gameplay regression checks.
  CHECK: node scripts/verify-v3-build.mjs
  EXPECT: RELEASE VERIFIED
  CWD: ..
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=f51d22c706378be31f304b56443cce2b7bd21a0755890aa60d67b4bbfc1830e9; output-bytes=1715
- [ ] C8: Browser inspection confirms held weapons, barrel flashes, killcam weapons, red damage feedback and usable room controls.
  EVIDENCE: Lobby selector and Snipers Only loadout inspected through the in-app browser on 2026-09-04. Combat scene served successfully, but browser connection timed out repeatedly and then reported Browser is not available. Combat screenshots were not obtained.
ABANDON: C8 Combat visual verification needs a browser follow-up; connection unavailable. Model alignment, flash state and replay tests passed under C1.
- [ ] C9: Updated public game deployment succeeds.
  EVIDENCE: pending
