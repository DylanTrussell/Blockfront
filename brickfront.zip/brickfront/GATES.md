# Gates: Brickfront

OWNS: app/**, lib/**, public/**, scripts/**, package.json, package-lock.json, .openai/hosting.json, GATES.md

Scope: A browser brick FPS with Baghdad, Sky Foundry, bots, online rooms, local two-player, six weapons, injuries, vehicles, and killer-view replay.

- [x] G1: Production game compiles with valid TypeScript and Worker output.
  CHECK: npm run verify:build
  EXPECT: BUILD VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=ef7fc9575a2171c1cc3d0e063bd8acabe960bb8543c21dd0b3fc792731c82263; output-bytes=1568
- [x] G2: Both maps have reachable spawns, solid collision, cover and patch pickups.
  CHECK: npx tsx scripts/verify.ts maps
  EXPECT: MAPS VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=27ff7b170250340f9d74d180dc86bdf888318dbf9a3d11aee3349a21adbe1df6; output-bytes=14
- [x] G3: All six weapons, grenade launcher, hits, reloads, team rules and explosive cover work.
  CHECK: npx tsx scripts/verify.ts combat
  EXPECT: COMBAT VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=85fa8bac143ac559a9e1917d3741965e7e87c045b1bc9c3f1627c040c51c34bf; output-bytes=16
- [x] G4: Damage produces bleeding, patch recovery, limb loss, last stand and death events.
  CHECK: npx tsx scripts/verify.ts injury
  EXPECT: INJURY VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=65a770c0a3c9f6a1bc24ac0586db2a325860785d7364651a1681e39fedac87ad; output-bytes=16
- [x] G5: Team Humvees can be driven, turrets mounted and vehicles destroyed; wreck cannot drive.
  CHECK: npx tsx scripts/verify.ts vehicles
  EXPECT: VEHICLES VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=b5dac6965cb9ac305a94f52c91d6cc2765fa0289b3f56c750c33a8b682367d4f; output-bytes=18
- [x] G6: Bots move, engage enemies, score kills and respawn in a timed team match.
  CHECK: npx tsx scripts/verify.ts bots
  EXPECT: BOTS VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=68f9ef353555c21afaa36f5fd0eb7a23df785dbbfab392c0847eee8d7ea17ebd; output-bytes=14
- [x] G7: Local second player has separate inputs and viewport; recorded killcam follows killer's history.
  CHECK: npx tsx scripts/verify.ts replay
  EXPECT: REPLAY VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=08fb4d40ec7293c381d9c98e7e97c1b6f9992c8b8c9cca70efcdf4d5afaad75a; output-bytes=16
- [x] G8: Room protocol accepts only validated inputs, shares state and handles departures.
  CHECK: npx tsx scripts/verify.ts network
  EXPECT: NETWORK VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=bde7baa914d39d91573532742db018b6b5a0473edcf718fa2d691a1914f138e9; output-bytes=17
- [x] G9: Brick character, gun, vehicle and map geometry construct with detachable parts and visible studs.
  CHECK: npx tsx scripts/verify.ts geometry
  EXPECT: GEOMETRY VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=26bed3f25288795eda5f39f472ccbdb35952ef43cc1f34be9a81f25bdf4d7de8; output-bytes=18
- [x] G10: Hosted deployment succeeds and game URL responds.
  EVIDENCE: Sites deployment appgdep_6a9b54940eb08191985d8f5a497e8229 succeeded at 2026-09-04T23:30:50Z; public https://brickfront.dylantrussell.chatgpt.site returned HTTP 200.
- [x] G11: Two clients exchange player inputs and match state over WebRTC using public internet signaling.
  CHECK: npx tsx scripts/verify-online.ts
  EXPECT: ONLINE VERIFIED
  EVIDENCE: exit=0; shell=/bin/sh; cwd=/Users/dylantrussell/Documents/Codex/2026-09-04/i-want-you-to-one-shot/work/brickfront; path=f495f0568506/20 entries; EXPECT=matched; output-sha256=1cc2cb1db4e20f438b8131b07aa94e112eba8594db02b921cd2066c133159ddc; output-bytes=143
