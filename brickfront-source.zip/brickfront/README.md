# Brickfront

A playable brick-built browser FPS with Baghdad and Sky Foundry, solo AI squads, two-player split-screen, and online private rooms for up to eight people.

## Play

Use a modern desktop browser with WebGL2. WASD move, mouse aim, click fire, right click aim, Shift sprint, Space jump, R reload, Q use patch, 1–5 or wheel switch weapons, G fire M203 grenade. E enters/exits a Humvee. F mounts a turret. Escape pauses and releases the mouse.

Player 2 uses arrow keys to move, IJKL to aim, Enter to fire, P to jump, O to reload, U to drive/exit, Y to mount the gun, H to patch, N for M203 and backslash to switch weapons. A connected gamepad supports moving, aiming, shooting, reloading and jumping for Player 2.

Select Online and Create Room. Pause to copy the invitation link or read the six-character room code. Your friend opens the same site and joins. The host must keep the tab active; the match ends if the host leaves. Bots fill remaining seats. Team damage is disabled. Matches last six minutes or until a team reaches 50 kills.

## Mechanics

Real weapon names with game-balanced handling: AK-47, M16/M203, M60, RPG-7, M1 Bazooka, plus the mounted M2 .50 cal. Ammunition replenishes on reload. Patch kits restore health and stop bleeding, but severed limbs return on respawn. One missing leg slows movement; both legs enable a crawling last stand. An arm injury increases weapon spread. No real blood is rendered.

The Baghdad road wreck has three wheels, an open damaged hood and a usable roof machine gun. Each team has a working Humvee, with a driver seat and a separate gunner seat. Destroyed vehicles return after 30 seconds. Death replays store approximately three seconds of actor and vehicle transforms and shot events and follow the killer's viewpoint.

## Development

- `npm install`
- `npm run dev`
- `npm test`
- `npm run verify:build`
- `npx tsx scripts/verify-online.ts`

The game runs on Three.js. A deterministic-step simulation owns collisions, damage, AI navigation, vehicles and scoring. Online games use PeerJS/WebRTC with the host as simulation authority. The integration test connects two actual WebRTC endpoints through the public PeerJS signaling service, sends player controls, and verifies receipt of authoritative match state.

## Current limits

This is a playable alpha, with procedural models and stylized maps. Baghdad is inspired by the city, not a geographical reconstruction. The game is independent and has no affiliation with LEGO or Call of Duty. There are no public matchmaking servers, accounts, progression, host migration or competitive anti-cheat. Connections depend on PeerJS signaling and NAT traversal; restrictive networks may fail. Online animation reflects host snapshots and does not yet have competitive lag compensation. Desktop keyboard and mouse are preferred. Touch controls cover the main actions. Local split-screen requires a sufficiently wide screen.

Automated verification covers map reachability and collision, combat and reloads, injuries, Humvee/turret behavior, bot matches, replay history, input validation, geometry and actual WebRTC message delivery. Human browser playtesting and the optional WebMCP tools were not verified in this session.

## Future public rooms

Room discovery lives in `lib/room-discovery.ts`, separately from PeerJS transport
in `lib/network.ts` and gameplay in `lib/simulation.ts`. Private invite codes
resolve locally into a versioned `RoomConnection`; no room listing service is
contacted. `Room.joinConnection()` is the shared connection entry point.

A future public room browser can implement `PublicRoomDirectory`, display its
compatible, non-full listings and pass the selected listing to
`Room.joinConnection()`. Hosts opt into publishing a listing and hold a
`PublicRoomLease`, which supports heartbeats and removal. The directory service
must authenticate its host leases, expire stale listings, and validate occupancy.
Private room creation must keep using `createPrivateRoom()` and never publish a
listing. Public discovery adds a service and interface without replacing the
current match transport or simulation. No public directory is enabled today.
