import * as T from 'three';
import { createWorld, type MapId } from './world';

const materials = new Map<number, T.MeshStandardMaterial>();
const boxGeo = new T.BoxGeometry(1, 1, 1);
const studGeo = new T.CylinderGeometry(.17, .17, .10, 12);
export function material(color: number) {
  if (!materials.has(color)) materials.set(color, new T.MeshStandardMaterial({ color, roughness: .3, metalness: .03 }));
  return materials.get(color)!;
}
export function box(parent: T.Object3D, x: number, y: number, z: number, w: number, h: number, d: number, color: number) {
  const m = new T.Mesh(boxGeo, material(color)); m.position.set(x, y, z); m.scale.set(w, h, d); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
}
export function cyl(parent: T.Object3D, x: number, y: number, z: number, r: number, h: number, color: number, sides = 12) {
  const m = new T.Mesh(new T.CylinderGeometry(r, r, h, sides), material(color)); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
}
export function brick(parent: T.Object3D, x: number, y: number, z: number, w: number, h: number, d: number, color: number, studs = true) {
  const b = box(parent, x, y, z, w - .025, h - .02, d - .025, color);
  if (studs) {
    const nx = Math.max(1, Math.floor(w / .5)), nz = Math.max(1, Math.floor(d / .5));
    const mesh = new T.InstancedMesh(studGeo, material(color), nx * nz); let n = 0; const mat = new T.Matrix4();
    for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) mesh.setMatrixAt(n++, mat.makeTranslation(x + (i - (nx - 1) / 2) * .5, y + h / 2 + .03, z + (j - (nz - 1) / 2) * .5));
    mesh.castShadow = true; mesh.receiveShadow = true; parent.add(mesh);
  }
  return b;
}
export function weaponModel(index: number, firstPerson = false): T.Group {
  const g = new T.Group(); const steel = 0x292d30, wood = 0x7b4524;
  const heavy = index >= 4; const len = index === 2 ? .92 : .68;
  if (heavy) {
    const tube = cyl(g, 0, .03, -.32, .10, 1.12, index === 4 ? 0x677147 : 0x536545); tube.rotation.x = Math.PI / 2;
    const tip = cyl(g, 0, .03, -.96, index === 4 ? .14 : .10, .24, 0x3a4038); tip.rotation.x = Math.PI / 2;
    box(g, 0, -.17, -.1, .10, .3, .13, steel); box(g, .14, .17, -.3, .08, .14, .15, steel);
  } else {
    box(g, 0, .03, -.25, .15, .16, .48, steel);
    box(g, 0, .02, .08, .14, .15, .28, index === 0 ? wood : 0x3d4140);
    box(g, 0, -.17, -.08, .085, .24, .12, steel).rotation.x = -.22;
    box(g, 0, -.16, -.34, index === 2 ? .25 : .09, .25, .13, index === 0 ? 0x343c39 : 0x35393a).rotation.x = index === 0 ? -.3 : .1;
    box(g, 0, .04, -.53, .17, .16, .27, index === 0 ? wood : steel);
    const barrel = cyl(g, 0, .04, -len, .035, .43, steel); barrel.rotation.x = Math.PI / 2;
    box(g, 0, .19, -.58, .035, .16, .035, steel); box(g, 0, .14, -.16, .11, .065, .1, steel);
    if (index === 1) { const m203 = cyl(g, 0, -.1, -.62, .065, .38, 0x323a32); m203.rotation.x = Math.PI / 2; }
    if (index === 3) { box(g, 0, .01, -.82, .13, .1, .66, steel); box(g, .19, -.1, -.2, .22, .25, .32, 0x666548); }
  }
  if (firstPerson) { cyl(g, .12, -.24, .01, .1, .18, 0xf5c737).rotation.x = 1.4; box(g, .2, -.35, .17, .24, .25, .45, 0x65744c); cyl(g, -.11, -.17, -.53, .09, .16, 0xf5c737).rotation.z = 1.1; box(g, -.23, -.27, -.31, .22, .25, .5, 0x65744c).rotation.y = -.45; }
  return g;
}
export function soldierModel(team: number): T.Group {
  const g = new T.Group(), color = team === 0 ? 0x607c52 : 0xbd6946, dark = team === 0 ? 0x394c3b : 0x593e33;
  brick(g, 0, 1.13, 0, .66, .64, .4, color, false);
  box(g, 0, 1.13, -.23, .48, .42, .09, dark); for (const x of [-.15, .15]) box(g, x, 1.10, -.29, .18, .21, .07, color);
  cyl(g, 0, 1.65, 0, .245, .36, 0xf3c43b); cyl(g, 0, 1.92, 0, .26, .17, dark); cyl(g, 0, 2.02, 0, .12, .06, dark);
  for (const x of [-.085, .085]) { const eye = box(g, x, 1.7, -.241, .048, .046, .02, 0x1e211c); eye.rotation.y = x * 2; }
  box(g, 0, 1.58, -.246, .12, .026, .02, 0x392c20);
  for (let i = 0; i < 4; i++) {
    const p = new T.Group(); p.name = ['leftArm', 'rightArm', 'leftLeg', 'rightLeg'][i];
    p.position.set((i % 2 ? 1 : -1) * (i < 2 ? .46 : .19), i < 2 ? 1.36 : .72, 0);
    if (i < 2) { box(p, 0, -.2, 0, .22, .48, .25, color); const hand = cyl(p, 0, -.48, -.015, .12, .17, 0xf3c43b); hand.rotation.x = Math.PI / 2; }
    else { brick(p, 0, -.29, 0, .30, .58, .33, dark, false); box(p, 0, -.61, -.05, .31, .14, .46, dark); }
    g.add(p);
  }
  const gun = weaponModel(0); gun.name = 'gun'; gun.position.set(.3, 1.17, -.37); gun.scale.setScalar(.7); g.add(gun);
  return g;
}
export function humveeModel(team: number, wreck = false): T.Group {
  const g = new T.Group(), paint = wreck ? 0x666054 : team === 0 ? 0xa99864 : 0x6b7655;
  brick(g, 0, .65, 0, 2.25, .45, 4.3, paint);
  box(g, 0, 1.02, .8, 2.1, .5, 2.3, paint); brick(g, 0, 1.2, -1.35, 2.1, .5, 1.4, wreck ? 0x2d2b28 : paint);
  brick(g, 0, 2, .25, 2.15, .18, 2.45, paint);
  for (const x of [-1, 1]) {
    for (const z of [-.83, 1.34]) box(g, x, 1.65, z, .13, .7, .13, paint);
    box(g, x, 1.43, .25, .12, .55, 2.3, paint);
    for (const z of [-1.3, 1.35]) {
      if (wreck && x === 1 && z === -1.3) continue;
      const wheel = cyl(g, x * 1.17, .52, z, .54, .33, 0x252729, 16); wheel.rotation.z = Math.PI / 2; wheel.name = "wheel";
      cyl(g, x * 1.35, .52, z, .26, .02, 0x726c5b).rotation.z = Math.PI / 2;
    }
  }
  box(g, 0, 1.68, -.83, 1.76, .5, .025, 0x608182); box(g, 0, .77, -2.2, 2.3, .18, .2, 0x34393a);
  for (const x of [-.77, .77]) box(g, x, 1.05, -2.07, .3, .21, .04, 0xf5dda2);
  for (let i = 0; i < 7; i++) box(g, (i - 3) * .14, 1.02, -2.09, .055, .22, .03, 0x22262a);
  cyl(g, 0, 2.15, .1, .48, .17, paint); const turret = new T.Group(); turret.name = 'turret'; turret.position.set(0, 2.4, .1);
  const mg = weaponModel(3); mg.scale.setScalar(1.4); turret.add(mg); g.add(turret);
  if (wreck) { g.rotation.z = -.09; g.rotation.x = -.06; box(g, -.25, 1.52, -1.42, 1.8, .12, 1.4, paint).rotation.z = -.55; for (let i = 0; i < 4; i++) brick(g, .4 + i * .2, .13, -2.7, .5, .25, .4, 0x444039); }
  return g;
}
export function makeMap(id: MapId): T.Group {
  const w = createWorld(id), root = new T.Group(); root.name = 'map';
  box(root, 0, -.32, 0, 72, .64, 72, id === 'baghdad' ? 0xbaa078 : 0x334c59);
  // Thousands of molded studs share a single draw call.
  const studs = new T.InstancedMesh(studGeo, material(id === 'baghdad' ? 0xbda47e : 0x3f5964), 72 * 72); const mat = new T.Matrix4();
  for (let i = 0; i < 72; i++) for (let j = 0; j < 72; j++) studs.setMatrixAt(i * 72 + j, mat.makeTranslation(i - 35.5, .025, j - 35.5));
  studs.receiveShadow = true; root.add(studs);
  if (id === 'baghdad') {
    box(root, 0, .011, 0, 10, .025, 70, 0x797366);
    for (let z = -30; z <= 30; z += 7) box(root, 0, .035, z, .14, .02, 2.2, 0xd8c898);
    for (const x of [-5.3, 5.3]) brick(root, x, .12, 0, .45, .25, 69, 0xceba92, false);
  } else {
    for (const x of [-7, 7]) { box(root, x, .02, 0, 1.3, .08, 68, 0x678d95); for (let z = -31; z < 33; z += 2) box(root, x, .08, z, 1.4, .06, .1, 0xc2ccbd); }
    for (const s of [-1, 1]) { brick(root, s * 35, .7, 0, .45, 1.4, 70, 0x34404b, false); brick(root, 0, .7, s * 35, 70, 1.4, .45, 0x34404b, false); }
  }
  for (const s of w.solids) {
    box(root, s.x, s.h / 2, s.z, s.w, s.h, s.d, s.color);
    brick(root, s.x, s.h, s.z, s.w + .25, .24, s.d + .25, s.color);
    if (s.kind === 'building') {
      // Exposed brick courses, inset dark windows and roof parapets.
      for (let y = .6; y < s.h; y += .65) for (const z of [-1, 1]) box(root, s.x, y, s.z + z * (s.d / 2 + .012), s.w, .025, .027, 0x9c7c50);
      for (let y = 2; y < s.h - .7; y += 2.5) for (let x = -s.w / 2 + 1.5; x < s.w / 2 - .5; x += 2.2) for (const z of [-1, 1]) {
        box(root, s.x + x, y, s.z + z * (s.d / 2 + .04), .9, 1.3, .08, id === 'baghdad' ? 0x3e514c : 0x739b9f);
        box(root, s.x + x, y - .65, s.z + z * (s.d / 2 + .18), 1.18, .13, .37, 0xdfc795);
      }
      for (const a of [-1, 1]) { brick(root, s.x + a * s.w / 2, s.h + .44, s.z, .3, .7, s.d, s.color); brick(root, s.x, s.h + .44, s.z + a * s.d / 2, s.w, .7, .3, s.color); }
      if (id === 'baghdad') { cyl(root, s.x + 1, s.h + .85, s.z, .65, 1.4, 0x706c56); box(root, s.x - 1.2, s.h + .4, s.z, 1.4, .55, 1.1, 0xcec2a1); }
    } else if (s.kind === 'container') {
      for (let z = -s.d / 2 + .3; z < s.d / 2; z += .5) for (const x of [-1, 1]) box(root, s.x + x * (s.w / 2 + .025), s.h / 2, s.z + z, .08, s.h - .2, .07, s.color);
    } else if (s.kind === 'reactor') {
      const glow = new T.MeshStandardMaterial({ color: 0x69e3cf, emissive: 0x25cbb6, emissiveIntensity: 1.4, roughness: .22 });
      for (let y = 1; y < 7.5; y += 1.4) { const ring = new T.Mesh(new T.TorusGeometry(4, .12, 8, 32), glow); ring.rotation.x = Math.PI / 2; ring.position.set(0, y, 0); root.add(ring); }
      const light = new T.PointLight(0x47ffcc, 40, 20); light.position.set(0, 8, 0); root.add(light);
    }
  }
  if (id === 'baghdad') {
    for (const [x,z] of [[-16,-18],[16,22],[-16,23],[16,-24]]) {
      const trunk = cyl(root, x, 2.5, z, .22, 5, 0x8b6c40, 8);
      for (let i=0;i<7;i++) { const leaf = box(root, 0, 0, 0, .6, .14, 3.8, 0x526b37); leaf.position.set(x+Math.sin(i)*1.3,5.1,z+Math.cos(i)*1.3); leaf.rotation.set(.23,i,0); } trunk.name='palm';
    }
    const dome = new T.Mesh(new T.SphereGeometry(4, 24, 12, 0, Math.PI*2, 0, Math.PI/2), material(0x7faaaa)); dome.position.set(-25, 10.4, 13); root.add(dome);
    cyl(root, -30, 8, 9, .8, 16, 0xd6ba85); cyl(root, -30, 16.4, 9, 1.1, .45, 0xd6ba85);
    for (const [x,z] of [[-9,-18],[12,23]]) { const burned = humveeModel(0,true); burned.position.set(x,0,z); burned.rotation.y=1.1; root.add(burned); }
  } else {
    for (const x of [-26,26]) { box(root,x,8,24,.8,16,.8,0xc18b3a); box(root,x-5,15.5,24,12,.7,.7,0xe8aa42); box(root,x-8,12,24,.05,7,.05,0x949c9e); }
    for (let i=0;i<10;i++) { const cloud = new T.Mesh(new T.SphereGeometry(6,8,6),material(0xafc1cd)); cloud.position.set(Math.sin(i*3)*70,-11-i%3,Math.cos(i*3)*70); cloud.scale.set(2.5,.6,1); root.add(cloud); }
  }
  return root;
}
export function releaseGeometry(object:T.Object3D){const seen=new Set<T.BufferGeometry>();object.traverse(o=>{if(o instanceof T.Mesh&&o.geometry!==boxGeo&&o.geometry!==studGeo)seen.add(o.geometry);if(o instanceof T.InstancedMesh)o.dispose();});for(const geo of seen)geo.dispose();}
