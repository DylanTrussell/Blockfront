import { createWorld, v, distance, clamp, move, blocked, rayBox, wallDistance, type Vec, type MapId, type World } from './world';
export const WEAPONS = [
  {name:'AK-47',mag:30,damage:26,interval:.115,reload:2.1,spread:.015,rocket:false},
  {name:'M16 / M203',mag:30,damage:24,interval:.105,reload:2,spread:.009,rocket:false},
  {name:'M60',mag:100,damage:30,interval:.12,reload:4.2,spread:.022,rocket:false},
  {name:'M2 .50 CAL',mag:200,damage:39,interval:.13,reload:4,spread:.012,rocket:false},
  {name:'RPG-7',mag:1,damage:125,interval:1,reload:3.4,spread:.008,rocket:true},
  {name:'M1 BAZOOKA',mag:1,damage:115,interval:1,reload:3,spread:.008,rocket:true}
];
export const SELECTABLE = [0,1,2,4,5];
export type Input = {forward:number;strafe:number;yaw:number;pitch:number;shoot:boolean;ads:boolean;sprint:boolean;jump:boolean;reload:boolean;use:boolean;turret:boolean;patch:boolean;grenade:boolean;weapon:number};
export const emptyInput = ():Input => ({forward:0,strafe:0,yaw:0,pitch:0,shoot:false,ads:false,sprint:false,jump:false,reload:false,use:false,turret:false,patch:false,grenade:false,weapon:-1});
export type Actor = {id:string;name:string;team:number;bot:boolean;pos:Vec;yaw:number;pitch:number;hp:number;bleed:number;limbs:boolean[];weapon:number;ammo:number[];reload:number;cooldown:number;grenades:number;kits:number;kills:number;deaths:number;dead:number;vy:number;vehicle:string;seat:string;lastHit:number;killer:string;protect:number;ads:boolean;firing:number;walk:number};
export type Vehicle = {id:string;pos:Vec;yaw:number;team:number;fixed:boolean;hp:number;driver:string;gunner:string;turretYaw:number;turretPitch:number;dead:number;speed:number};
export type Projectile = {id:number;owner:string;pos:Vec;vel:Vec;life:number;grenade:boolean};
export type GameEvent = {id:number;t:number;type:'shot'|'hit'|'death'|'explosion'|'patch'|'limb';pos:Vec;end?:Vec;actor:string;target?:string;weapon?:number;part?:number};
export type State = {map:MapId;time:number;remaining:number;score:number[];actors:Actor[];vehicles:Vehicle[];projectiles:Projectile[];patches:number[];events:GameEvent[];winner:number};
export type HistoryFrame = {time:number;actors:Actor[];vehicles:Vehicle[];events:GameEvent[]};
export function lookDirection(yaw:number,pitch:number):Vec { return v(-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)); }
export function eye(a:Actor):Vec { return v(a.pos.x,a.pos.y+(a.seat==='turret'?2.55:a.seat==='driver'?1.63:!a.limbs[2]&&!a.limbs[3]?.85:1.68),a.pos.z); }
export function sanitizeInput(value:unknown):Input|null {
  if(!value||typeof value!=='object')return null; const a=value as Record<string,unknown>;
  for(const key of ['forward','strafe','yaw','pitch'])if(typeof a[key]!=='number'||!Number.isFinite(a[key]))return null;
  const out=emptyInput();out.forward=clamp(a.forward as number,-1,1);out.strafe=clamp(a.strafe as number,-1,1);out.yaw=(a.yaw as number)%(Math.PI*2);out.pitch=clamp(a.pitch as number,-1.4,1.4);
  for(const key of ['shoot','ads','sprint','jump','reload','use','turret','patch','grenade'] as const)out[key]=a[key]===true;
  if(Number.isInteger(a.weapon)&&SELECTABLE.includes(a.weapon as number))out.weapon=a.weapon as number;return out;
}
export class Simulation {
  world:World; state:State; inputs=new Map<string,Input>(); seq=0; random:()=>number; aiPaths=new Map<string,{path:Vec[];until:number}>();
  constructor(map:MapId,random:()=>number=Math.random) { this.world=createWorld(map);this.random=random;
    this.state={map,time:0,remaining:360,score:[0,0],actors:[],vehicles:[this.vehicle('green',v(-2,0,31),0),this.vehicle('rust',v(3,0,-31),1),this.vehicle('wreck',v(2,0,-4),-1,true)],projectiles:[],patches:[0,0,0,0],events:[],winner:-1};
  }
  vehicle(id:string,pos:Vec,team:number,fixed=false):Vehicle {return {id,pos,yaw:team===1?Math.PI:0,team,fixed,hp:fixed?500:300,driver:'',gunner:'',turretYaw:0,turretPitch:0,dead:0,speed:0};}
  addPlayer(id:string,name:string,team:number,bot=false,weapon=0):Actor {
    const a:Actor={id,name:name.slice(0,20),team,bot,pos:v(),yaw:team?Math.PI:0,pitch:0,hp:100,bleed:0,limbs:[true,true,true,true],weapon,ammo:WEAPONS.map(w=>w.mag),reload:0,cooldown:0,grenades:3,kits:1,kills:0,deaths:0,dead:0,vy:0,vehicle:'',seat:'',lastHit:-10,killer:'',protect:2,ads:false,firing:0,walk:0};
    this.state.actors.push(a);this.spawn(a);return a;
  }
  fillBots(){const names=['Cinder','Sprocket','Rivet','Clutch','Studs','Axle','Blockhead','Patch'];for(let team=0;team<2;team++)while(this.state.actors.filter(a=>a.team===team).length<4){const n=this.state.actors.length;this.addPlayer('bot-'+this.seq++,names[n%names.length],team,true,n%3);}}
  removePlayer(id:string){const a=this.state.actors.find(a=>a.id===id);if(a)this.dismount(a);this.state.actors=this.state.actors.filter(a=>a.id!==id);this.inputs.delete(id);}
  spawn(a:Actor){const options=this.world.spawns[a.team];a.pos={...options[Math.floor(this.random()*options.length)]};a.yaw=a.team?Math.PI:0;a.pitch=0;a.hp=100;a.bleed=0;a.dead=0;a.limbs=[true,true,true,true];a.ammo=WEAPONS.map(w=>w.mag);a.kits=1;a.grenades=3;a.reload=0;a.protect=2;a.vy=0;a.vehicle='';a.seat='';}
  event(type:GameEvent['type'],pos:Vec,actor:string,extra:Partial<GameEvent>={}){this.state.events.push({id:++this.seq,t:this.state.time,type,pos:{...pos},actor,...extra});if(this.state.events.length>90)this.state.events.shift();}
  setInput(id:string,input:Input){this.inputs.set(id,input);}
  tick(dt:number){dt=clamp(dt,0,.1);const s=this.state;if(s.winner!==-1)return;s.time+=dt;s.remaining=Math.max(0,s.remaining-dt);
    for(let i=0;i<s.patches.length;i++)s.patches[i]=Math.max(0,s.patches[i]-dt);
    for(const car of s.vehicles){if(car.dead>0){car.dead-=dt;if(car.dead<=0){Object.assign(car,this.vehicle(car.id,car.id==='green'?v(-2,0,31):car.id==='rust'?v(3,0,-31):v(2,0,-4),car.team,car.fixed));}}}
    for(const a of s.actors){if(a.dead>0){a.dead-=dt;if(a.dead<=0)this.spawn(a);continue;}
      a.protect=Math.max(0,a.protect-dt);a.cooldown=Math.max(0,a.cooldown-dt);a.firing=Math.max(0,a.firing-dt);
      if(a.reload>0){a.reload-=dt;if(a.reload<=0)a.ammo[a.seat==='turret'?3:a.weapon]=WEAPONS[a.seat==='turret'?3:a.weapon].mag;}
      if(a.bleed>0){a.hp-=a.bleed*dt;if(a.hp<=0){this.kill(a,a.killer);continue;}if(Math.floor(s.time*3)!==Math.floor((s.time-dt)*3))this.event('hit',v(a.pos.x,a.pos.y+.7,a.pos.z),a.killer,{target:a.id});}
      const input=a.bot?this.ai(a,dt):this.inputs.get(a.id)||emptyInput();this.act(a,input,dt);
      for(let i=0;i<this.world.patches.length;i++)if(s.patches[i]===0&&distance(a.pos,this.world.patches[i])<1.45&&(a.hp<100||a.bleed>0||a.kits<2)){this.heal(a);a.kits=Math.min(2,a.kits+1);s.patches[i]=18;}
    }
    for(const p of [...s.projectiles]){const old={...p.pos},len=Math.hypot(p.vel.x,p.vel.y,p.vel.z)*dt;const d=v(p.vel.x*dt/len,p.vel.y*dt/len,p.vel.z*dt/len);let hit=wallDistance(this.world,old,d);const owner=s.actors.find(a=>a.id===p.owner);
      for(const a of s.actors)if(a.id!==p.owner&&a.dead<=0&&a.team!==owner?.team)hit=Math.min(hit,rayBox(old,d,v(a.pos.x-.45,a.pos.y,a.pos.z-.45),v(a.pos.x+.45,a.pos.y+2,a.pos.z+.45)));
      for(const c of s.vehicles)if(!c.dead&&owner?.vehicle!==c.id)hit=Math.min(hit,rayBox(old,d,v(c.pos.x-1.25,0,c.pos.z-2.1),v(c.pos.x+1.25,2.1,c.pos.z+2.1)));
      p.pos.x+=p.vel.x*dt;p.pos.y+=p.vel.y*dt;p.pos.z+=p.vel.z*dt;if(p.grenade)p.vel.y-=9*dt;p.life-=dt;
      if(hit<len||p.pos.y<.1||p.life<=0||Math.abs(p.pos.x)>36||Math.abs(p.pos.z)>36){if(hit<len)p.pos=v(old.x+d.x*hit,old.y+d.y*hit,old.z+d.z*hit);this.explode(p.pos,p.owner,p.grenade?85:135,p.grenade?4:6);s.projectiles=s.projectiles.filter(q=>q.id!==p.id);}
    }
    if(s.remaining===0||s.score.some(n=>n>=50))s.winner=s.score[0]===s.score[1]?2:s.score[0]>s.score[1]?0:1;
  }
  act(a:Actor,i:Input,dt:number){a.yaw=i.yaw;a.pitch=i.pitch;a.ads=i.ads;const car=this.state.vehicles.find(v=>v.id===a.vehicle);
    if(i.use||i.turret){if(a.vehicle)this.dismount(a);else this.mount(a,i.turret?'turret':'driver');}
    if(i.patch&&a.kits>0&&(a.bleed||a.hp<100)){a.kits--;this.heal(a);}
    if(i.weapon>=0&&i.weapon!==a.weapon&&!a.vehicle){a.weapon=i.weapon;a.reload=0;}
    if(car&&a.vehicle){if(a.seat==='driver'){
      car.speed+=(i.forward*12-car.speed)*Math.min(1,dt*2);car.yaw-=i.strafe*dt*1.7*(Math.abs(car.speed)>1?Math.sign(car.speed):0);const before={...car.pos};move(this.world,car.pos,-Math.sin(car.yaw)*car.speed*dt,-Math.cos(car.yaw)*car.speed*dt,2.05);if(distance(before,car.pos)<Math.abs(car.speed*dt)*.3)car.speed*=.5;
      a.yaw=car.yaw+i.yaw*.15;
      for(const other of this.state.actors)if(other.dead<=0&&!other.vehicle&&other.team!==a.team&&distance(other.pos,car.pos)<2&&Math.abs(car.speed)>4)this.damage(other,Math.abs(car.speed)*7*dt,a.id,2);
    }else{car.turretYaw=a.yaw;car.turretPitch=a.pitch;}
      for(const rider of this.state.actors)if(rider.vehicle===car.id)rider.pos={...car.pos};
    }else{
      const legs=Number(a.limbs[2])+Number(a.limbs[3]);const speed=(i.sprint&&!i.shoot?7.5:4.4)*(i.ads?.65:1)*(legs===2?1:legs===1?.57:.22);let f=i.forward,r=i.strafe;const norm=Math.max(1,Math.hypot(f,r));f/=norm;r/=norm;
      move(this.world,a.pos,(-Math.sin(a.yaw)*f+Math.cos(a.yaw)*r)*speed*dt,(-Math.cos(a.yaw)*f-Math.sin(a.yaw)*r)*speed*dt);
      if(i.jump&&a.pos.y<=0&&legs>0)a.vy=6;a.vy-=17*dt;a.pos.y=Math.max(0,a.pos.y+a.vy*dt);if(a.pos.y===0)a.vy=0;a.walk+=Math.hypot(f,r)*dt*speed;
    }
    if(i.reload)this.reload(a);if(i.shoot&&a.seat!=='driver')this.fire(a);if(i.grenade&&a.weapon===1&&a.grenades>0&&a.cooldown===0&&a.seat!=='driver'){a.grenades--;a.cooldown=.8;this.launch(a,true);}
  }
  reload(a:Actor){const wi=a.seat==='turret'?3:a.weapon;if(a.reload<=0&&a.ammo[wi]<WEAPONS[wi].mag)a.reload=WEAPONS[wi].reload;}
  fire(a:Actor){const wi=a.seat==='turret'?3:a.weapon,w=WEAPONS[wi];if(a.dead>0||a.cooldown>0||a.reload>0)return;if(a.ammo[wi]<=0){this.reload(a);return;}a.ammo[wi]--;a.cooldown=w.interval;a.firing=.09;a.protect=0;
    if(w.rocket){this.launch(a,false);return;}
    const spread=w.spread*(a.ads?.35:1)*(a.bot?2:1)*(a.limbs[0]&&a.limbs[1]?1:2.2);const d=lookDirection(a.yaw+(this.random()-.5)*spread,a.pitch+(this.random()-.5)*spread);const o=eye(a);let dist=wallDistance(this.world,o,d),target:Actor|undefined,part=-1,car:Vehicle|undefined;
    for(const c of this.state.vehicles)if(!c.dead&&c.id!==a.vehicle){const t=rayBox(o,d,v(c.pos.x-1.15,0,c.pos.z-2.15),v(c.pos.x+1.15,2.1,c.pos.z+2.15));if(t<dist){dist=t;car=c;target=undefined;}}
    for(const other of this.state.actors){if(other.id===a.id||other.dead>0||other.team===a.team||other.seat==='driver')continue;
      const p=other.pos,low=!other.limbs[2]&&!other.limbs[3]?.6:0;
      const pieces=[[-.24,1.47-low,-.24,.24,1.98-low,.24,-2],[-.34,.76-low,-.24,.34,1.46-low,.24,-1],[-.60,.81-low,-.24,-.34,1.42-low,.24,0],[.34,.81-low,-.24,.60,1.42-low,.24,1],[-.34,0,-.24,-.02,.75,.24,2],[.02,0,-.24,.34,.75,.24,3]];
      for(const [x,y,z,X,Y,Z,partId] of pieces){if(partId>=0&&!other.limbs[partId])continue;const hit=rayBox(o,d,v(p.x+x,p.y+y,p.z+z),v(p.x+X,p.y+Y,p.z+Z));if(hit<dist){dist=hit;target=other;part=partId;car=undefined;}}
    }
    const end=v(o.x+d.x*dist,o.y+d.y*dist,o.z+d.z*dist);this.event('shot',o,a.id,{end,weapon:wi});
    if(target)this.damage(target,w.damage*(part===-2?1.8:part>=0?.75:1),a.id,part);
    if(car)this.damageVehicle(car,w.damage*.4,a.id);
  }
  launch(a:Actor,grenade:boolean){const d=lookDirection(a.yaw,a.pitch),o=eye(a);this.state.projectiles.push({id:++this.seq,owner:a.id,pos:v(o.x+d.x*.7,o.y+d.y*.7,o.z+d.z*.7),vel:v(d.x*(grenade?22:33),d.y*(grenade?22:33)+(grenade?2:0),d.z*(grenade?22:33)),life:grenade?2.5:4,grenade});this.event('shot',o,a.id,{weapon:a.weapon});}
  damage(a:Actor,amount:number,attacker:string,part=-1,explosive=false){if(a.dead>0||a.protect>0)return;const source=this.state.actors.find(p=>p.id===attacker);if(source&&source.id!==a.id&&source.team===a.team)return;
    a.hp-=amount;a.lastHit=this.state.time;a.killer=attacker;a.bleed=Math.min(4,a.bleed+amount*.018);this.event('hit',v(a.pos.x,a.pos.y+1,a.pos.z),attacker,{target:a.id});
    if(part>=0&&amount>=18&&a.limbs[part]&&(explosive||amount>=28||this.random()<.22)){a.limbs[part]=false;a.bleed=Math.min(4,a.bleed+1);this.event('limb',v(a.pos.x,a.pos.y+.8,a.pos.z),attacker,{target:a.id,part});}
    if(a.hp<=0)this.kill(a,attacker);
  }
  kill(a:Actor,killer:string){if(a.dead>0)return;a.hp=0;a.dead=5;a.deaths++;a.killer=killer;this.dismount(a);const source=this.state.actors.find(b=>b.id===killer);if(source&&source.team!==a.team){source.kills++;this.state.score[source.team]++;}this.event('death',v(a.pos.x,a.pos.y+1,a.pos.z),killer,{target:a.id,weapon:source?.seat==='turret'?3:source?.weapon});}
  heal(a:Actor){a.hp=Math.min(100,a.hp+60);a.bleed=0;this.event('patch',a.pos,a.id);}
  explode(p:Vec,owner:string,damage:number,radius:number){this.event('explosion',p,owner);
    for(const a of this.state.actors){const q=v(a.pos.x,a.pos.y+1,a.pos.z),dist=distance(p,q);if(a.dead>0||dist>radius)continue;const dir=v((q.x-p.x)/dist,(q.y-p.y)/dist,(q.z-p.z)/dist);if(wallDistance(this.world,v(p.x+dir.x*.08,p.y+dir.y*.08,p.z+dir.z*.08),dir)<dist-.3)continue;this.damage(a,damage*(1-dist/radius),owner,Math.floor(this.random()*4),true);}
    for(const car of this.state.vehicles)if(!car.dead&&distance(car.pos,p)<radius+2)this.damageVehicle(car,damage*2*(1-Math.max(0,distance(car.pos,p)-2)/radius),owner);
  }
  damageVehicle(car:Vehicle,amount:number,attacker:string){if(car.dead>0)return;car.hp-=amount;if(car.hp>0)return;car.hp=0;car.dead=30;car.speed=0;this.event('explosion',v(car.pos.x,1,car.pos.z),attacker);for(const a of this.state.actors)if(a.vehicle===car.id){this.dismount(a);a.protect=0;this.damage(a,200,attacker,-1,true);}car.driver='';car.gunner='';}
  mount(a:Actor,seat:string){if(a.dead>0)return;const car=this.state.vehicles.filter(c=>!c.dead&&distance(a.pos,c.pos)<3.9&&(c.team===-1||c.team===a.team)).sort((x,y)=>distance(a.pos,x.pos)-distance(a.pos,y.pos))[0];if(!car)return;if(seat==='driver'&&(car.fixed||car.driver))return;if(seat==='turret'&&car.gunner)return;a.vehicle=car.id;a.seat=seat;if(seat==='driver')car.driver=a.id;else car.gunner=a.id;a.pos={...car.pos};a.reload=0;}
  dismount(a:Actor){const car=this.state.vehicles.find(c=>c.id===a.vehicle);if(car){if(car.driver===a.id){car.driver='';car.speed=0;}if(car.gunner===a.id)car.gunner='';const points=[v(car.pos.x+3,0,car.pos.z),v(car.pos.x-3,0,car.pos.z),v(car.pos.x,0,car.pos.z+3),v(car.pos.x,0,car.pos.z-3)];a.pos=points.find(p=>!blocked(this.world,p))||{...car.pos};}a.vehicle='';a.seat='';}
  ai(a:Actor,dt:number):Input {const i=emptyInput();const enemies=this.state.actors.filter(b=>b.team!==a.team&&b.dead<=0).sort((b,c)=>distance(a.pos,b.pos)-distance(a.pos,c.pos));const target=enemies[0];if(!target)return i;
    const dx=target.pos.x-a.pos.x,dz=target.pos.z-a.pos.z,dist=Math.hypot(dx,dz);const desired=Math.atan2(-dx,-dz);const difference=Math.atan2(Math.sin(desired-a.yaw),Math.cos(desired-a.yaw));i.yaw=a.yaw+clamp(difference,-dt*2.4,dt*2.4);i.pitch=Math.atan2(eye(target).y-eye(a).y,dist);const dir=lookDirection(desired,i.pitch);const visible=wallDistance(this.world,eye(a),dir)>dist-.4;
    i.shoot=visible&&dist<37&&Math.abs(difference)<.18&&this.random()>.38;i.ads=dist>18;i.patch=a.bleed>1||a.hp<40;
    if(!visible||dist>15){let route=this.aiPaths.get(a.id);if(!route||route.until<this.state.time){route={path:this.path(a.pos,target.pos),until:this.state.time+1.7};this.aiPaths.set(a.id,route);}if(route.path.length){if(distance(a.pos,route.path[0])<1.5)route.path.shift();const next=route.path[0];if(next){const angle=Math.atan2(-(next.x-a.pos.x),-(next.z-a.pos.z));i.forward=Math.cos(angle-i.yaw);i.strafe=-Math.sin(angle-i.yaw);}}}else i.strafe=Math.sin(this.state.time*.8+a.id.length)*.5;
    return i;
  }
  path(start:Vec,end:Vec):Vec[]{const size=35,step=2,toCell=(p:Vec)=>[clamp(Math.round((p.x+34)/step),0,34),clamp(Math.round((p.z+34)/step),0,34)];const [sx,sz]=toCell(start),[ex,ez]=toCell(end),source=sz*size+sx,goal=ez*size+ex,queue=[source],prev=new Map<number,number>([[source,-1]]);let found=-1;
    for(let head=0;head<queue.length;head++){const n=queue[head];if(n===goal){found=n;break;}const x=n%size,z=Math.floor(n/size);for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const X=x+dx,Z=z+dz,key=Z*size+X;if(X<0||X>=size||Z<0||Z>=size||prev.has(key)||blocked(this.world,v(X*step-34,0,Z*step-34),.55))continue;prev.set(key,n);queue.push(key);}}
    if(found<0)return [];const path:Vec[]=[];for(let n=found;n!==source&&n>=0;n=prev.get(n)??-1)path.push(v(n%size*step-34,0,Math.floor(n/size)*step-34));return path.reverse();
  }
  snapshot():State {return structuredClone(this.state);}
}
export class ReplayBuffer {
  frames:HistoryFrame[]=[];last=-1;
  record(s:State,force=false){if(!force&&s.time-this.last<.075)return;this.last=s.time;this.frames.push({time:s.time,actors:structuredClone(s.actors),vehicles:structuredClone(s.vehicles),events:structuredClone(s.events.filter(e=>s.time-e.t<.15))});while(this.frames.length&&s.time-this.frames[0].time>4)this.frames.shift();}
  clip(deathTime:number){return this.frames.filter(f=>f.time>=deathTime-3.2&&f.time<=deathTime).map(f=>structuredClone(f));}
}
export function replayFrame(frames:HistoryFrame[],elapsed:number):HistoryFrame|undefined {if(!frames.length)return;const t=frames[0].time+elapsed;return frames.find(f=>f.time>=t)||frames[frames.length-1];}
