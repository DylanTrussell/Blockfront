import type { MapId } from './world';

export const ROOM_PROTOCOL = 1 as const;
export const ROOM_CAPACITY = 8;
export const validCode = (code: string) => /^[A-Z2-9]{6}$/.test(code);

/** Both invite links and a future public directory resolve to this connection. */
export type RoomConnection = {
  protocol: typeof ROOM_PROTOCOL;
  transport: 'peerjs';
  code: string;
  peerId: string;
  visibility: 'private' | 'public';
};

export function resolveInvite(rawCode: string): RoomConnection {
  const code = rawCode.trim().toUpperCase();
  if (!validCode(code)) throw new Error('Enter the 6-character room code.');
  return {
    protocol: ROOM_PROTOCOL,
    transport: 'peerjs',
    code,
    peerId: `brickfront-v${ROOM_PROTOCOL}-${code.toLowerCase()}`,
    visibility: 'private',
  };
}

export function createPrivateRoom(): RoomConnection {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return resolveInvite(Array.from(bytes, n => alphabet[n % alphabet.length]).join(''));
}

export function validateConnection(value: unknown): value is RoomConnection {
  if (!value || typeof value !== 'object') return false;
  const room = value as RoomConnection;
  return room.protocol === ROOM_PROTOCOL && room.transport === 'peerjs' &&
    typeof room.code === 'string' && validCode(room.code) &&
    room.peerId === resolveInvite(room.code).peerId &&
    (room.visibility === 'private' || room.visibility === 'public');
}

export function createInviteURL(origin: string, room: RoomConnection): string {
  if (!validateConnection(room)) throw new Error('Invalid room connection.');
  const url = new URL(origin);
  url.searchParams.set('room', room.code);
  return url.href;
}

/** Listing metadata stays out of the gameplay protocol and private invitations. */
export type PublicRoom = RoomConnection & {
  visibility: 'public';
  name: string;
  map: MapId;
  players: number;
  capacity: number;
  expiresAt: number;
};

/**
 * Future server-backed directory. Private rooms must never call publish().
 * The service authenticates host leases, validates capacity and expires stale
 * listings. Only compatible, non-full rooms belong in list() results.
 */
export interface PublicRoomDirectory {
  list(query: { map?: MapId; protocol: typeof ROOM_PROTOCOL }, signal?: AbortSignal): Promise<PublicRoom[]>;
  publish(room: Omit<PublicRoom, 'expiresAt'>, signal?: AbortSignal): Promise<PublicRoomLease>;
}

/** Opaque host lease: keep credentials inside the directory adapter. */
export interface PublicRoomLease {
  heartbeat(update: { players: number; map: MapId }, signal?: AbortSignal): Promise<void>;
  close(): Promise<void>;
}
