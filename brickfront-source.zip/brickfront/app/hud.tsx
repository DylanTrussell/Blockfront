'use client';
import type { Engine, EngineHUD } from '@/lib/engine';
import { createWorld, distance } from '@/lib/world';
import { WEAPONS } from '@/lib/simulation';
import { useRef } from 'react';
export function HUD({hud,engine,copy}:{hud:EngineHUD;engine:Engine;copy:()=>void}){
  const state=hud.state,split=hud.ids.length===2,world=createWorld(state.map),touchStart=useRef({x:0,y:0});
  const time=`${Math.floor(state.remaining/60)}:${String(Math.floor(state.remaining%60)).padStart(2,'0')}`;
  const feed=state.events.filter(e=>e.type==='death'&&state.time-e.t<6).slice(-4);
  return <><div className="hud"><div className="team-score"><b>{state.score[0]}</b><div><small>FIRST TO 50</small><time>{time}</time></div><b className="enemy">{state.score[1]}</b></div>
    {hud.ids.map((id,index)=>{const a=state.actors.find(a=>a.id===id);if(!a)return null;const car=state.vehicles.find(c=>!c.dead&&distance(a.pos,c.pos)<3.9&&(c.team===-1||c.team===a.team));const replay=hud.replays.find(r=>r.id===id);const wi=a.seat==='turret'?3:a.weapon;const injured=a.limbs.some(p=>!p);return <div key={id} style={{position:'absolute',top:0,bottom:0,left:split?`${index*50}%`:0,width:split?'50%':'100%',overflow:'hidden'}}>
      <div className="hud-name">{split?`PLAYER ${index+1} · `:''}{world.name.toUpperCase()}{hud.room.code&&<span> · ROOM {hud.room.code}</span>}</div>
      <div className="minimap">{world.solids.map((s,i)=><i key={i} className="map-solid" style={{left:`${(s.x-s.w/2+35)/70*100}%`,top:`${(s.z-s.d/2+35)/70*100}%`,width:`${s.w/70*100}%`,height:`${s.d/70*100}%`}}/>)}{state.actors.filter(p=>p.dead<=0&&(p.team===a.team||p.firing>0)).map(p=><i key={p.id} className={`map-player ${p.team!==a.team?'enemy':''} ${p.id===id?'self':''}`} style={{left:`${(p.pos.x+35)/70*100}%`,top:`${(p.pos.z+35)/70*100}%`}}/>)}</div>
      {a.dead<=0&&<div className="crosshair"/>}{hud.hit&&index===0&&<div className="hit-marker">+</div>}
      <div className="damage-vignette" style={{opacity:a.dead>0?0:Math.max(0,.75-(state.time-a.lastHit)*1.5)+(a.hp<30?.15:0)}}/>
      <div className="vitals"><div className="health">{Math.ceil(a.hp)}<small>INTEGRITY</small></div><div className="health-track"><i style={{width:`${a.hp}%`}}/></div><div style={{fontSize:11,color:'#c7d7b7'}}>PATCH KITS {a.kits} · {a.kills} K / {a.deaths} D</div>{a.bleed>0&&<div className="injury">LOSING BRICKS · {a.bleed.toFixed(1)} HP/SEC · {index?'H':'Q'} TO PATCH</div>}{injured&&<div className="injury">LAST STAND · {a.limbs.slice(0,2).some(x=>!x)?'ARM LOST ':''}{a.limbs.slice(2).some(x=>!x)?'LEG LOST':''}</div>}</div>
      <div className="ammo"><strong>{a.reload>0?'↻':a.ammo[wi]}</strong><span>/ {WEAPONS[wi].mag}</span><p>{a.seat==='driver'?'HUMVEE · E TO EXIT':WEAPONS[wi].name}</p><p>{a.reload>0?`RELOADING ${a.reload.toFixed(1)}s`:a.seat==='turret'?'MOUNTED · E TO DISMOUNT':a.weapon===1?`${a.grenades} M203 GRENADES · G`:'R TO RELOAD'}</p></div>
      {a.dead<=0&&((a.vehicle)||car)&&<div className="interaction">{a.vehicle?`${a.seat==='driver'?'W/S drive · A/D steer':'M2 .50 cal mounted'} · ${index?'U':'E'} exit`:<><kbd>{car?.fixed?(index?'Y':'F'):(index?'U':'E')}</kbd> {car?.fixed?'Mount wreck .50 cal':`Drive Humvee · ${index?'Y':'F'} gunner`}</>}</div>}
      {a.dead>0&&<div className="killcam-label"><strong>{replay?'KILL CAM':'REBUILDING'}</strong><p>{replay?`${replay.killer} · ${Math.max(0,3.2-replay.elapsed).toFixed(1)}s replay`:'Finding your spare parts…'}</p><p>RESPAWN IN {Math.ceil(a.dead)}</p></div>}
    </div>})}
    <div className="kill-feed">{feed.map(e=><p key={e.id}>{state.actors.find(a=>a.id===e.actor)?.name||'Crossfire'} <span style={{color:'#d9f779'}}> ▸ </span> {state.actors.find(a=>a.id===e.target)?.name||'Soldier'}</p>)}</div>
    <div className="game-controls">{split?'P1: WASD + MOUSE · P2: ARROWS + IJKL + ENTER':'SHIFT sprint · SPACE jump · R reload · 1–5 weapons · Q patch · ESC pause'}</div>{split&&<div className="split-divider"/>}
    </div>
    {!hud.paused&&<button className="secondary-button" style={{position:'absolute',zIndex:9,right:20,top:180,padding:'7px 10px',fontSize:11}} onClick={()=>engine.pause()}>PAUSE</button>}
    {!split&&!hud.paused&&<div className="touch-controls"><div className="touch-look" aria-label="Drag to look" onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);touchStart.current={x:e.clientX,y:e.clientY};}} onPointerMove={e=>{if(!e.currentTarget.hasPointerCapture(e.pointerId))return;engine.yaw[0]-=(e.clientX-touchStart.current.x)*.006;engine.pitch[0]=Math.max(-1.3,Math.min(1.3,engine.pitch[0]-(e.clientY-touchStart.current.y)*.006));touchStart.current={x:e.clientX,y:e.clientY};}}/>
      <div className="touch-move">{[['▲','forward',1,55,0],['▼','forward',-1,55,70],['◀','strafe',-1,0,70],['▶','strafe',1,110,70]].map(([label,key,value,left,top])=><button key={String(label)} style={{left:Number(left),top:Number(top)}} aria-label={`Move ${label}`} onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);Object.assign(engine.touch,{[String(key)]:value});}} onPointerUp={()=>Object.assign(engine.touch,{[String(key)]:0})} onPointerCancel={()=>Object.assign(engine.touch,{[String(key)]:0})}>{label}</button>)}</div>
      <button className="fire" onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);engine.touch.shoot=true;}} onPointerUp={()=>engine.touch.shoot=false} onPointerCancel={()=>engine.touch.shoot=false}>FIRE</button><button className="jump" onClick={()=>engine.touch.jump=true}>JUMP</button><button className="reload" onClick={()=>engine.touch.reload=true}>RELOAD</button><button style={{right:113,bottom:175}} onClick={()=>engine.touch.use=true}>USE</button><button style={{right:193,bottom:110}} onClick={()=>engine.touch.turret=true}>.50 CAL</button><button style={{left:28,bottom:270}} onClick={()=>engine.touch.patch=true}>PATCH</button>
    </div>}
    {(hud.paused||hud.room.error)&&<div className="pause-layer"><div className="pause-card"><div className="eyebrow" style={{justifyContent:'center'}}>BRICKFRONT</div><h2>{state.winner!==-1?(state.winner===2?'DRAW':state.winner===state.actors.find(a=>a.id===hud.ids[0])?.team?'VICTORY':'DEFEAT'):hud.room.error?'CONNECTION LOST':'HOLD FIRE.'}</h2>
      {state.winner!==-1?<p>{state.score[0]} : {state.score[1]}<br/>Every piece accounted for.</p>:<p>{hud.room.error||'Take a breath. Find your next angle.'}</p>}
      {hud.room.code&&<><p>{hud.room.status} · {hud.room.count} player{hud.room.count===1?'':'s'}</p><div className="room-code">{hud.room.code}</div><button className="secondary-button" onClick={copy}>COPY INVITE LINK</button><p style={{fontSize:12}}>The host must keep this tab open. Some restricted networks may block connections.</p></>}
      {state.winner===-1&&!hud.room.error&&<button className="deploy" onClick={()=>engine.resume()}>RESUME BATTLE <span>↗</span></button>}
      <button className="secondary-button" onClick={()=>engine.leave()}>RETURN TO LOBBY</button>
    </div></div>}
  </>;
}
