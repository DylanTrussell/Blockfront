import assert from 'node:assert/strict';
import { RTCPeerConnection } from 'werift';
import { Simulation, emptyInput } from '../lib/simulation';
Object.assign(globalThis,{window:{location:{hostname:'localhost'}},location:{protocol:'https:',hostname:'localhost'},RTCPeerConnection,RTCSessionDescription:class{type:string;sdp:string;constructor(s:{type:string;sdp:string}){this.type=s.type;this.sdp=s.sdp;}}});
const {Room}=await import('../lib/network');
const sim=new Simulation('baghdad');sim.addPlayer('host','Host',0);sim.fillBots();let code='',guestID='',gotInput=false,gotState=false;const failures:string[]=[];
const host=new Room(info=>{if(info.status==='Room open')code=info.code;if(info.error)failures.push(info.error);},id=>{guestID=id;sim.addPlayer(id,'Remote',1);return id;},id=>sim.removePlayer(id),(id,input)=>{gotInput=input.forward===1;sim.setInput(id,input);},()=>{});
const guest=new Room(info=>{if(info.error)failures.push(info.error);},()=>'',()=>{},()=>{},(state,id)=>{if(state.actors.some(a=>a.id===id))gotState=true;});
let interval:ReturnType<typeof setInterval>|null=null;
try{await host.host();const deadline=Date.now()+45000;while(!code&&Date.now()<deadline&&!failures.length)await new Promise(r=>setTimeout(r,100));assert.ok(code,failures.join(';')||'Host signaling timed out');console.log('Host registered with public signaling service');guest.join(code);interval=setInterval(()=>{host.broadcast(sim.snapshot());const input=emptyInput();input.forward=1;guest.send(input);sim.tick(1/60);},50);while((!gotInput||!gotState)&&Date.now()<deadline&&!failures.length)await new Promise(r=>setTimeout(r,100));assert.ok(gotInput,failures.join(';')||'Guest controls were not received');assert.ok(gotState,failures.join(';')||'Guest did not receive authoritative match state');assert.ok(guestID);console.log('ONLINE VERIFIED: public signaling, WebRTC connection, guest input and host match state delivered');}
finally{if(interval)clearInterval(interval);guest.close();host.close();setTimeout(()=>process.exit(gotInput&&gotState?0:1),250);}
