import assert from 'node:assert/strict';
import * as T from 'three';
import { Simulation, emptyInput, WEAPONS, ReplayBuffer, replayFrame, sanitizeInput } from '../lib/simulation';
import { createWorld, blocked, distance, v, move, rayBox } from '../lib/world';
import { makeMap, soldierModel, humveeModel, weaponModel } from '../lib/geometry';
const group=process.argv[2];
let seed=14;const rng=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
const setup=()=>{const s=new Simulation('baghdad',rng);const a=s.addPlayer('one','One',0),b=s.addPlayer('two','Two',1);a.pos=v(0,0,0);b.pos=v(0,0,-6);a.protect=b.protect=0;s.state.vehicles=[];return {s,a,b};};
if(group==='maps'){
 for(const id of ['baghdad','foundry'] as const){const world=createWorld(id),sim=new Simulation(id);assert.ok(world.solids.length>=10);assert.equal(world.patches.length,4);for(const team of world.spawns)for(const p of team){assert.equal(blocked(world,p),false,`spawn ${id}`);assert.ok(sim.path(p,world.spawns[1][0]).length||distance(p,world.spawns[1][0])<2);}
 for(const p of world.patches){assert.equal(blocked(world,p),false);assert.ok(sim.path(world.spawns[0][0],p).length);}
 const c=world.solids[0];assert.equal(blocked(world,v(c.x,0,c.z)),true);const p=v(c.x-c.w/2-1,0,c.z);move(world,p,1,0);assert.ok(p.x<c.x-c.w/2);assert.ok(world.solids.some(s=>s.kind==='cover'));}
 assert.equal(rayBox(v(0,0,0),v(0,0,-1),v(-1,-1,-6),v(1,1,-4)),4);assert.equal(rayBox(v(3,0,0),v(0,0,-1),v(-1,-1,-6),v(1,1,-4)),Infinity);
}
if(group==='combat'){
 for(let wi=0;wi<WEAPONS.length;wi++){const {s,a,b}=setup();a.weapon=wi;s.fire(a);assert.equal(a.ammo[wi],WEAPONS[wi].mag-1);if(wi<4)assert.ok(b.hp<100,WEAPONS[wi].name);else{assert.equal(s.state.projectiles.length,1);for(let k=0;k<30;k++)s.tick(1/60);assert.ok(b.hp<100,WEAPONS[wi].name);}a.ammo[wi]=0;a.cooldown=0;s.reload(a);for(let j=0;j<Math.ceil(WEAPONS[wi].reload*60)+1;j++)s.tick(1/60);assert.equal(a.ammo[wi],WEAPONS[wi].mag);}
 const {s,a,b}=setup();a.weapon=1;const input=emptyInput();input.grenade=true;s.act(a,input,1/60);assert.equal(a.grenades,2);assert.equal(s.state.projectiles[0].grenade,true);
 b.team=0;s.damage(b,50,a.id);assert.equal(b.hp,100);b.team=1;a.cooldown=0;s.world.solids.push({x:0,z:-3,w:4,d:1,h:4,color:0,kind:'cover'});s.fire(a);assert.equal(b.hp,100);s.explode(v(0,1,-2),a.id,150,10);assert.equal(b.hp,100);
}
if(group==='injury'){
 const {s,a,b}=setup();s.damage(b,32,a.id,2);assert.equal(b.limbs[2],false);assert.equal(b.hp,68);assert.ok(b.bleed>0);s.tick(.1);assert.ok(b.hp<68&&b.hp>0);s.heal(b);assert.equal(b.bleed,0);assert.equal(b.hp,100);assert.equal(b.limbs[2],false);
 const start={...b.pos};const input=emptyInput();input.forward=1;s.act(b,input,.1);assert.ok(distance(start,b.pos)<.3);s.damage(b,30,a.id,0,true);assert.equal(b.limbs[0],false);assert.ok(b.hp>0);const count=b.ammo[b.weapon];b.cooldown=0;s.fire(b);assert.equal(b.ammo[b.weapon],count-1);s.damage(b,200,a.id);assert.equal(b.hp,0);assert.ok(b.dead>0);assert.equal(s.state.score[0],1);assert.ok(s.state.events.some(e=>e.type==='death'));assert.ok(s.state.events.some(e=>e.type==='limb'));for(let i=0;i<310;i++)s.tick(1/60);assert.equal(b.hp,100);assert.ok(b.limbs.every(Boolean));
}
if(group==='vehicles'){
 const s=new Simulation('baghdad',rng),a=s.addPlayer('one','One',0),car=s.state.vehicles[0];a.pos=v(car.pos.x+2.8,0,car.pos.z);s.mount(a,'driver');assert.equal(a.seat,'driver');const z=car.pos.z;const i=emptyInput();i.forward=1;for(let n=0;n<60;n++)s.act(a,i,1/60);assert.ok(car.pos.z<z-2,'Humvee must actually move');s.dismount(a);assert.equal(car.driver,'');assert.equal(a.vehicle,'');const wreck=s.state.vehicles.find(c=>c.fixed)!;a.pos=v(wreck.pos.x+2.8,0,wreck.pos.z);s.mount(a,'driver');assert.equal(a.vehicle,'');s.mount(a,'turret');assert.equal(a.seat,'turret');assert.equal(wreck.gunner,a.id);const ammo=a.ammo[3];s.fire(a);assert.equal(a.ammo[3],ammo-1);s.dismount(a);s.damageVehicle(car,400,a.id);assert.ok(car.dead>0);assert.equal(car.hp,0);
}
if(group==='bots'){
 for(const map of ['baghdad','foundry'] as const){const s=new Simulation(map,rng);s.fillBots();const positions=s.state.actors.map(a=>({...a.pos}));for(let k=0;k<3600;k++)s.tick(1/60);assert.equal(s.state.actors.length,8);assert.ok(s.state.actors.some((a,i)=>distance(a.pos,positions[i])>5));assert.ok(s.state.score[0]+s.state.score[1]>0,`${map} bots must score`);assert.ok(s.state.actors.some(a=>a.deaths>0));s.state.remaining=.01;s.tick(.02);assert.notEqual(s.state.winner,-1);}
}
if(group==='replay'){
 const {s,a,b}=setup(),recorder=new ReplayBuffer();for(let i=0;i<240;i++){a.yaw=i*.01;s.tick(1/60);recorder.record(s.state);}s.kill(b,a.id);recorder.record(s.state);const clip=recorder.clip(s.state.time);assert.ok(clip.length>20);const early=replayFrame(clip,0)!,late=replayFrame(clip,2)!;assert.ok(late.time>early.time);assert.ok(clip.every(f=>f.actors.some(a=>a.id==='one')));a.pos.x=99;assert.notEqual(early.actors[0].pos.x,99);const {viewports,P2}=await import('../lib/engine');assert.equal(viewports(1200,800,true).length,2);assert.equal(viewports(1200,800,true)[1].x,600);assert.equal(P2.forward,'ArrowUp');const i=emptyInput();i.strafe=1;s.setInput(b.id,i);assert.notEqual(s.inputs.get(a.id),s.inputs.get(b.id));
}
if(group==='network'){
 const {isState,validCode}=await import('../lib/network');const {createPrivateRoom,resolveInvite,validateConnection,createInviteURL,ROOM_CAPACITY}=await import('../lib/room-discovery');const room=createPrivateRoom();assert.equal(room.visibility,'private');assert.equal(ROOM_CAPACITY,8);assert.deepEqual(resolveInvite('  '+room.code.toLowerCase()+'  '),room);assert.equal(validateConnection({...room,visibility:'public'}),true);assert.equal(validateConnection({...room,protocol:99}),false);assert.equal(validateConnection({...room,peerId:'unrelated-peer'}),false);assert.throws(()=>resolveInvite(''));assert.throws(()=>resolveInvite('wrong'));const invite=new URL(createInviteURL('https://example.com/?room=OLD&theme=dark',room));assert.equal(invite.searchParams.get('room'),room.code);assert.equal(invite.searchParams.get('theme'),'dark');assert.deepEqual(resolveInvite(invite.searchParams.get('room')!),room);const {s}=setup();assert.ok(isState(s.snapshot()));assert.equal(isState({map:'baghdad',time:0,actors:[{pos:{x:Infinity}}]}),false);assert.equal(sanitizeInput({forward:NaN,strafe:0,yaw:0,pitch:0}),null);const i=sanitizeInput({forward:100,strafe:-100,yaw:2,pitch:500,shoot:'true',hp:999,weapon:3})!;assert.equal(i.forward,1);assert.equal(i.strafe,-1);assert.equal(i.pitch,1.4);assert.equal(i.shoot,false);assert.equal(i.weapon,-1);assert.equal('hp' in i,false);assert.equal(validCode('ABC234'),true);assert.equal(validCode('<script>'),false);s.removePlayer('two');assert.equal(s.state.actors.length,1);
}
if(group==='geometry'){
 for(const id of ['baghdad','foundry'] as const){const map=makeMap(id);let studs=0,meshes=0;map.traverse(o=>{if(o instanceof T.InstancedMesh)studs+=o.count;if(o instanceof T.Mesh){meshes++;assert.ok(o.geometry.attributes.position.count>0);}});assert.ok(studs>5000);assert.ok(meshes>100);}
 const soldier=soldierModel(0);for(const name of ['leftArm','rightArm','leftLeg','rightLeg'])assert.ok(soldier.getObjectByName(name));const car=humveeModel(0),wreck=humveeModel(0,true);assert.ok(wreck.getObjectByName('turret'));assert.equal(car.children.filter(o=>o.name==='wheel').length,4);assert.equal(wreck.children.filter(o=>o.name==='wheel').length,3);for(let i=0;i<6;i++)assert.ok(weaponModel(i,true).children.length>5);
}
if(!['maps','combat','injury','vehicles','bots','replay','network','geometry'].includes(group))throw Error('Unknown test group');
console.log(group.toUpperCase()+' VERIFIED');
